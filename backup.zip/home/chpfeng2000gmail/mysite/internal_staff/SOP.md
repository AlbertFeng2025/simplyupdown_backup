# 🛠 SOP: Signal Delivery Engine Troubleshooting

**Objective:** Diagnose why signals are not being delivered when the task reports success.
**Target File:** `stocks/management/commands/deliver_signals.py`

---

## Phase 1: Verify Data Health (Django Shell)
Run these commands in the PythonAnywhere console to ensure the "fuel" exists for the engine:

```python
python manage.py shell

# 1. Check for signals ready to go
from stocks.models import SignalMonitor
print(SignalMonitor.objects.filter(status='Waiting', cycle='Daily').count()) 
# If 0, the midnight import failed.

# 2. Check if your test user is eligible
from django.contrib.auth.models import User
from django.db.models import Q
members = User.objects.filter(profile__tier__in=['PREM', 'PLAT'], profile__alert_cycle_daily=True)
print(members.count())

def run_delivery(self, cycle, alert_type):
    now_ny = datetime.datetime.now(NY_TZ)

    # --- TEMPORARY COMMENT OUT START ---
    # if not is_valid_delivery_day(cycle, now_ny):
    #     logger.info(f"Not a valid delivery day for {cycle}. Exiting.")
    #     return
    # --- TEMPORARY COMMENT OUT END ---
    # Around line 118
members = User.objects.filter(
    username='YOUR_ADMIN_USERNAME',  # <--- ADD THIS LINE
    profile__tier__in = ['PREM', 'PLAT'],
    **cycle_filter.get(cycle, {})
)
test:
python manage.py deliver_signals --cycle Daily --alert-type final

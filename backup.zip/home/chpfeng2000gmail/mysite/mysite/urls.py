"""
URL configuration for mysite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include, re_path
from django.contrib.auth import views as auth_views


# Import all your views from the subfolder
from stocks.views.home import home
from stocks.views.radar_all_cycle import radar_view, signal_detail_popup


from stocks.views.account import account_view

from stocks.views.auth import signup_view
from stocks.views import brevo_webhooks
from stocks.views import billing

from django.views.generic import TemplateView

from stocks.views.performance_tracker import performance_tracker_view
from stocks.views import change_email
from stocks.views.api import api_signals
from stocks.views.radar_all_cycle import refresh_news_view

from stocks.views.home import maintenance_view

urlpatterns = [

    # when want to go alive, comments out re_path. when want maintenance, just remove # at the re_path
    # This "re_path" is a master key. It matches EVERY URL someone types.
    # Because it is at the TOP, Django stops here and shows the maintenance page.
    #re_path(r'^.*$', maintenance_view),

    # 1. Admin Site
    path('admin-thaifood/', admin.site.urls),
    # 2. Main Navigation
    path('', home, name='home'),


    path('radar/daily/',   radar_view, {'cycle': 'Daily'},   name='radar_daily'),
    path('radar/weekly/',  radar_view, {'cycle': 'Weekly'},  name='radar_weekly'),
    path('radar/monthly/', radar_view, {'cycle': 'Monthly'}, name='radar_monthly'),

    path('detail/<int:signal_id>/', signal_detail_popup, name='signal_detail'),

   # --- 3. Authentication (Grouped under 'accounts/') ---
    path('accounts/login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('accounts/signup/', signup_view, name='signup'),

    # Placeholder for your future User Profile/Dashboard
    path('account/', account_view, name='account'),


   # --- Password Management ---
    # RESET — for users who forgot password (not logged in, sends email)
    path('accounts/password-reset/',
         auth_views.PasswordResetView.as_view(template_name='registration/password_reset.html'),
         name='password_reset'),
    path('accounts/password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(template_name='registration/password_reset_done.html'),
         name='password_reset_done'),
    path('accounts/password-reset-confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(template_name='registration/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('accounts/password-reset-complete/',
         auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'),
         name='password_reset_complete'),

    # CHANGE — for logged-in users who know their current password
    path('account/password-change/',
         auth_views.PasswordChangeView.as_view(
             template_name='registration/password_change.html',
             success_url='/account/'
         ),
         name='password_change'),
    path('account/password-change/done/',
         auth_views.PasswordChangeDoneView.as_view(
             template_name='registration/password_change_done.html',
         ),
         name='password_change_done'),


   # Legal Pages
    path('disclaimer/', TemplateView.as_view(template_name='disclaimer.html'), name='disclaimer'),
    path('privacy/', TemplateView.as_view(template_name='privacy.html'), name='privacy'),
    path('terms/', TemplateView.as_view(template_name='terms.html'), name='terms'),

    # other on footer
    path('contact/', TemplateView.as_view(template_name='contact.html'), name='contact'),

   # live evidence
    path('evidence/', performance_tracker_view, name='live_evidence'),

   # how it works
   path('how-it-works/', TemplateView.as_view(template_name='how_it_works.html'), name='how_it_works'),
   path('faq/', TemplateView.as_view(template_name='FAQ.html'), name='faq'),
#    ↑               ↑                        ↑                    ↑
#  browser URL   no view needed         your filename          {% url 'faq' %}

  # email unsbuscribe
  path('brevo-hook/', brevo_webhooks.brevo_webhook, name='brevo_webhook'),

   # stripe
   # This matches the 'checkout' name in your HTML buttons
  # Matches href="{% url 'checkout' plan='premium' %}"
    path('checkout/<str:plan>/', billing.checkout_redirect, name='checkout'),

    # The URL you will give to Stripe in their Dashboard
    path('stripe-webhook/', billing.stripe_webhook, name='stripe_webhook'),
    path('billing/portal/', billing.create_portal_session, name='stripe_portal'),
# change email address:
path('change-email/', change_email.change_email_view, name='change_email'),

#API
 # Platinum users call this endpoint with their X-API-Key header.
    # No login required — authentication is via the API key itself.
    #
    # GET /api/v1/signals/              → all cycles
    # GET /api/v1/signals/?cycle=Daily  → Daily only
    # GET /api/v1/signals/?cycle=Weekly
    # GET /api/v1/signals/?cycle=Monthly
    #
    # Example curl:
    #   curl -H "X-API-Key: YOUR_KEY" https://www.simplyupdown.com/api/v1/signals/
path('api/v1/signals/', api_signals, name='api_signals'),

# news and setiment
path('refresh-news/<str:ticker>/', refresh_news_view, name='refresh_news'),
]













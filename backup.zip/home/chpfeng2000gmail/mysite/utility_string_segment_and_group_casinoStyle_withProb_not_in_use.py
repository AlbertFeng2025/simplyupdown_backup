"""
Module: utility_string_segment_and_group_casinoStyle.py
Version: 2.18
Description: Segments a binary string into continuous (UpRun, DownRun) and alternating (Alternating) patterns, and counts streaks of short and long patterns. Supports a 'level' parameter to define short/long streak thresholds. For level=1, segments are bare runs of 1s (UpRun) or 0s (DownRun) with length as the number of consecutive identical characters. For level!=2, alternating patterns are ignored and return 'NA'. For level=2, includes continuous (length>=2) and alternating (length>=3) patterns. For level>=3, only continuous patterns (length>=level). Returns sequences of short ('s') and long ('L') streaks for the last 80 segments as strings (e.g., 'LLsLs'), ordered from oldest to newest. Streak counts for UpRun and DownRun are mutually exclusive: if Short_Streak>0, Longer=0, and vice versa. Used for trading pattern analysis. Added probabilities for 'L' and 's', and a new recommendation function.
Dependencies: None
Last Updated: 2026-02-22
"""

def is_continuous(s: str) -> bool:
    """Checks if a sequence is purely continuous (all '0's or all '1's)."""
    if not s:
        return False
    if len(s) == 1:
        return True
    return all(c == s[0] for c in s)

def is_alternating(s: str) -> bool:
    """Checks if a sequence is purely alternating (e.g., '010', '1010')."""
    if len(s) < 2:
        return False
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            return False
    return True

def is_significant_pattern(s: str, level: int) -> bool:
    """
    Checks if a pattern is significant for segmentation based on the level parameter.
    - For level=1: Any continuous run of 1s or 0s (length>=1).
    - For level=2: Continuous >= level, Alternating >= level+1.
    - For level>=3: Continuous >= level, no alternating patterns.
    
    Args:
        s (str): The substring to check.
        level (int): The threshold level for short streaks.
    
    Returns:
        bool: True if the pattern is significant, False otherwise.
    """
    if len(s) < (1 if level == 1 else level):
        return False
    
    if level == 1:
        return is_continuous(s)  # Any run of 1s or 0s
    
    if is_continuous(s):
        return len(s) >= level  # Continuous patterns significant if length >= level
    
    if level == 2 and is_alternating(s) and len(s) >= level + 1:
        return True  # Alternating patterns only for level=2, length >= 3
    
    return False

def classify_segment(s: str, level: int) -> str:
    """
    Classifies a valid segment into UpRun, DownRun, Alternating_A0, or Alternating_A1.
    For level=1: UpRun (all 1s), DownRun (all 0s).
    For level!=2: No alternating patterns.
    """
    if level == 1:
        if all(c == '1' for c in s):
            return "UpRun"
        if all(c == '0' for c in s):
            return "DownRun"
        return "Mixed"
    
    if is_continuous(s):
        return "UpRun" if s[0] == '1' else "DownRun"
    if level == 2 and is_alternating(s):
        return "Alternating_A1" if s[0] == '1' else "Alternating_A0"
    return "Mixed"

def segment_binary_string(input_str: str, suffix: str | None = None, level: int = 2) -> list[tuple[str, str, int]]:
    """
    Segments a binary string into runs of 1s or 0s for level=1, or using Longest Valid Pattern (LVP) with 1-char overlap for level!=1.
    For level=1, segments are bare runs of 1s (UpRun) or 0s (DownRun) with length as the number of consecutive identical characters.
    
    Args:
        input_str (str): Binary string to segment (e.g., "0101001")
        suffix (str | None): Optional suffix to append ('0' or '1'). Default: None
        level (int): Threshold for short streaks (default: 2). For level=1, uses bare runs of 1s or 0s.
    
    Returns:
        list[tuple[str, str, int]]: List of (segment, group_id, length) tuples.
    
    Rules:
    - For level=1: UpRun (1s, short=1, long>=2), DownRun (0s, short=1, long>=2), non-overlapping.
    - For level=2: Continuous >=2, Alternating >=3, 1-char overlap.
    - For level>=3: Continuous >=level, no alternating patterns, 1-char overlap.
    - Adds suffix to input string before segmentation if provided.
    """
    # Validate level
    if not isinstance(level, int) or level < 1:
        raise ValueError("Level must be a positive integer")
    
    # Validate and apply suffix
    if suffix is not None:
        if suffix not in ['0', '1']:
            raise ValueError("Suffix must be '0' or '1' if provided")
        processed_str = input_str + suffix
        print(f"Applied suffix '{suffix}': '{input_str}' → '{processed_str}'")
    else:
        processed_str = input_str
    
    n = len(processed_str)
    if n == 0:
        return []

    segments = []

    if level == 1:
        # Segment into bare runs of 1s (UpRun) or 0s (DownRun)
        i = 0
        while i < n:
            start = i
            current_char = processed_str[i]
            # Count consecutive identical characters
            while i < n and processed_str[i] == current_char:
                i += 1
            segment = processed_str[start:i]
            group_id = "UpRun" if current_char == '1' else "DownRun"
            length = len(segment)
            segments.append((segment, group_id, length))
            print(f"Selected segment: '{segment}' | {group_id} | Length: {length} | Start: {start} | End: {i}")
        
        return segments
    
    # LVP approach for level != 1
    L_pointer = 0
    iteration_count = 0
    max_iterations = n * 2

    while L_pointer < n and iteration_count < max_iterations:
        iteration_count += 1
        max_length = n - L_pointer
        longest_valid_segment = ""
        found_valid_segment = False
        
        # Try longest SIGNIFICANT patterns first
        for length in range(max_length, level - 1, -1):
            current_substring = processed_str[L_pointer:L_pointer + length]
            
            if is_significant_pattern(current_substring, level):
                longest_valid_segment = current_substring
                found_valid_segment = True
                break

        if not found_valid_segment:
            L_pointer += 1
            continue

        segment_length = len(longest_valid_segment)
        group_id = classify_segment(longest_valid_segment, level)
        segments.append((longest_valid_segment, group_id, segment_length))
        
        # Advance with 1-char overlap
        L_pointer += max(1, segment_length - 1)

    # Final cleanup: remove trailing segments shorter than minimum length
    min_length = level
    while segments and len(segments[-1][0]) < min_length:
        segments = segments[:-1]
    
    if iteration_count >= max_iterations:
        raise ValueError("Max iterations reached. Possible infinite loop.")
    
    return segments

def pattern_repeat_not_repeat(input_str: str, segments: list[tuple[str, str, int]], repeat_threshold: int = 3, not_repeat_threshold: int = 3, level: int = 2) -> dict:
    """
    Counts streaks of short and long patterns from newest to oldest.
    Returns sequences of short ('s') and long ('L') streaks for the last 80 segments as strings.
    - For level=1: UpRun/DownRun (short=1, long>=2), Alternating='NA'.
    - For level=2: UpRun/DownRun (length=2 short, >=3 long), Alternating (length=3 short, >3 long).
    - For level>=3: UpRun/DownRun (length=level short, >level long), Alternating='NA'.
    Streak counts are mutually exclusive: if Short_Streak>0, Longer=0, and vice versa.
    
    Args:
        input_str (str): Original binary string.
        segments (list[tuple[str, str, int]]): List of (segment, group_id, length) tuples.
        repeat_threshold (int): Threshold for streak counts (default: 3).
        not_repeat_threshold (int): Threshold for longer counts (default: 3).
        level (int): Threshold for short streaks (default: 2).
    
    Returns:
        dict: Counts and sequences for UpRun, DownRun, and Alternating patterns.
    """
    # Validate level
    if not isinstance(level, int) or level < 1:
        raise ValueError("Level must be a positive integer")
    
    counts = {
        "UpRun_Short_Streak": 0,
        "UpRun_Longer": 0,
        "UpRun Short Long List (last 80)": "",
        "DownRun_Short_Streak": 0,
        "DownRun_Longer": 0,
        "DownRun Short Long List (last 80)": "",
        "Alternating_Short_Streak": "NA" if level != 2 else 0,
        "Alternating_Longer": "NA" if level != 2 else 0,
        "Alternating Short Long List (last 80)": "NA" if level != 2 else ""
    }
    
    # Lists to store short/long sequences for each group type
    uprun_list = []
    downrun_list = []
    alternating_list = [] if level == 2 else None
    
    # Reverse segments to scan from newest to oldest
    segments = segments[::-1]
    
    # Build sequence lists based on level
    for i, (seq, group_id, length) in enumerate(segments):
        if level == 1:
            if group_id == "UpRun":
                label = "s" if length == 1 else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == 1 else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")
        elif level == 2:
            if group_id == "UpRun":
                label = "s" if length == 2 else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == 2 else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")
            elif group_id in ("Alternating_A0", "Alternating_A1"):
                label = "s" if length == 3 else "L"
                alternating_list.append(label)
                print(f"Alternating segment {i} ({seq}, length={length}): {label}")
        else:  # level >= 3
            if group_id == "UpRun":
                label = "s" if length == level else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == level else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")
    
    # Reverse lists to order from oldest to newest
    uprun_list = uprun_list[::-1]
    downrun_list = downrun_list[::-1]
    if level == 2:
        alternating_list = alternating_list[::-1]
    
    # Join the last 80 elements (or fewer) into strings
    counts["UpRun Short Long List (last 80)"] = "".join(uprun_list[-80:])
    counts["DownRun Short Long List (last 80)"] = "".join(downrun_list[-80:])
    if level == 2:
        counts["Alternating Short Long List (last 80)"] = "".join(alternating_list[-80:])
    
    print(f"UpRun sequence (oldest to newest): {counts['UpRun Short Long List (last 80)']}")
    print(f"DownRun sequence (oldest to newest): {counts['DownRun Short Long List (last 80)']}")
    print(f"Alternating sequence (oldest to newest): {counts['Alternating Short Long List (last 80)']}")
    
    # Add probabilities for 'L' and 's'
    min_samples = 10
    # UpRun
    uprun_total = len(uprun_list)
    if uprun_total >= min_samples:
        counts["UpRun_Prob_L"] = uprun_list.count('L') / uprun_total
        counts["UpRun_Prob_s"] = 1 - counts["UpRun_Prob_L"]
    else:
        counts["UpRun_Prob_L"] = "Insufficient Data"
        counts["UpRun_Prob_s"] = "Insufficient Data"
    # DownRun
    downrun_total = len(downrun_list)
    if downrun_total >= min_samples:
        counts["DownRun_Prob_L"] = downrun_list.count('L') / downrun_total
        counts["DownRun_Prob_s"] = 1 - counts["DownRun_Prob_L"]
    else:
        counts["DownRun_Prob_L"] = "Insufficient Data"
        counts["DownRun_Prob_s"] = "Insufficient Data"
    # Alternating
    if level == 2:
        alternating_total = len(alternating_list)
        if alternating_total >= min_samples:
            counts["Alternating_Prob_L"] = alternating_list.count('L') / alternating_total
            counts["Alternating_Prob_s"] = 1 - counts["Alternating_Prob_L"]
        else:
            counts["Alternating_Prob_L"] = "Insufficient Data"
            counts["Alternating_Prob_s"] = "Insufficient Data"
    else:
        counts["Alternating_Prob_L"] = "NA"
        counts["Alternating_Prob_s"] = "NA"
    
    # Streak counting by level
    if level == 1:
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == 1:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == 1:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length >= 2
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] >= 2:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break
        
        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == 1:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == 1:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length >= 2
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] >= 2:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break
    
    elif level == 2:
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == 2:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == 2:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length >= 3
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] >= 3:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break
        
        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == 2:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == 2:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length >= 3
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] >= 3:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break
        
        # Alternating streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id not in ("Alternating_A0", "Alternating_A1"):
                continue
            if length == 3:
                counts["Alternating_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] not in ("Alternating_A0", "Alternating_A1"):
                        continue
                    if segments[j][2] == 3:
                        counts["Alternating_Short_Streak"] += 1
                    else:
                        break
                counts["Alternating_Longer"] = 0
                break
            else:  # length > 3
                counts["Alternating_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] not in ("Alternating_A0", "Alternating_A1"):
                        continue
                    if segments[j][2] > 3:
                        counts["Alternating_Longer"] += 1
                    else:
                        break
                counts["Alternating_Short_Streak"] = 0
                break
    
    else:  # level >= 3
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == level:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == level:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length > level
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] > level:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break
        
        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == level:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == level:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length > level
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] > level:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break
    
    return counts

def generate_streak_recommendation(segments: list[tuple[str, str, int]], counts: dict, level: int, rec_threshold: float = 0.6, strong_threshold: float = 0.7) -> str:
    """
    Generates a recommendation based on the most recent segment and historical probabilities.
    Ignores alternating patterns. Only considers UpRun and DownRun.
    Recommends chasing continuation ('L') or reversal ('s') if probabilities meet thresholds.
    
    Args:
        segments (list[tuple[str, str, int]]): List of segments from segment_binary_string.
        counts (dict): Dictionary from pattern_repeat_not_repeat, including probs.
        level (int): The level used for segmentation.
        rec_threshold (float): Threshold for 'recommend' (default: 0.6).
        strong_threshold (float): Threshold for 'strong recommend' (default: 0.7).
    
    Returns:
        str: Recommendation string or "No recommendation."
    """
    if not segments:
        return "No segments available - No recommendation."
    
    last_segment, last_group, last_length = segments[-1]
    
    if last_group in ("Alternating_A0", "Alternating_A1", "Mixed"):
        return "Current pattern is alternating or mixed - No recommendation."
    
    # Determine short length threshold
    if level == 1:
        short_len = 1
    elif level == 2:
        short_len = 2
    else:
        short_len = level
    
    if last_length != short_len:
        return "Current segment not at short length - No recommendation."
    
    rec = []
    
    if last_group == "UpRun":
        prob_L = counts.get("UpRun_Prob_L")
        prob_s = counts.get("UpRun_Prob_s")
        if isinstance(prob_L, str):  # Insufficient Data
            return "Insufficient data for UpRun - No recommendation."
        
        if prob_L >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 1 (extend UpRun, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        elif prob_L >= rec_threshold:
            rec.append(f"Recommend: Chase 1 (extend UpRun, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        
        if prob_s >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 0 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
        elif prob_s >= rec_threshold:
            rec.append(f"Recommend: Chase 0 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
    
    elif last_group == "DownRun":
        prob_L = counts.get("DownRun_Prob_L")
        prob_s = counts.get("DownRun_Prob_s")
        if isinstance(prob_L, str):  # Insufficient Data
            return "Insufficient data for DownRun - No recommendation."
        
        if prob_L >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 0 (extend DownRun/short, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        elif prob_L >= rec_threshold:
            rec.append(f"Recommend: Chase 0 (extend DownRun/short, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        
        if prob_s >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 1 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
        elif prob_s >= rec_threshold:
            rec.append(f"Recommend: Chase 1 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
    
    if rec:
        return "\n".join(rec)
    else:
        return "No clear recommendation - probabilities below threshold."

def print_segmentation_results(input_str: str, segments: list[tuple[str, str, int]], suffix: str | None = None):
    """Utility function to print segmentation results."""
    original_input = input_str if suffix is None else f"{input_str}+{suffix}"
    print(f"\n--- Segmentation Results ---")
    print(f"Original Input: '{original_input}'")
    if suffix:
        print(f"Processed Input: '{input_str + suffix}'")
    print(f"Total segments: {len(segments)}")
    
    for i, (seq, group, length) in enumerate(segments):
        print(f"Segment {i+1}: '{seq}' | Group ID: {group} | Length: {length}")
    
    if segments:
        print(f"\nResulting List of Tuples: {segments}")
    else:
        print("No significant segments found.")

if __name__ == "__main__":
    # Test input string
    TEST_INPUT = "0111100101001110101111100001010010100101101011100001100101011100011110101100110111111001010101110111010100011111101101100111101011110100101110110000001011100111111111001110001111101010010101100111111"
    
    # Test without suffix, default level=2
    print("=== TESTING WITHOUT SUFFIX, LEVEL=2 ===")
    segments = segment_binary_string(TEST_INPUT, level=2)
    print_segmentation_results(TEST_INPUT, segments)
    counts = pattern_repeat_not_repeat(TEST_INPUT, segments, level=2)
    print(f"\nPattern Counts: {counts}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments, counts, level=2)}")
    
    print("\n" + "="*60 + "\n")
    
    # Test with suffix '1', level=1
    print("=== TESTING WITH SUFFIX '1', LEVEL=1 ===")
    segments1 = segment_binary_string(TEST_INPUT, suffix='1', level=1)
    print_segmentation_results(TEST_INPUT, segments1, suffix='1')
    counts1 = pattern_repeat_not_repeat(TEST_INPUT, segments1, level=1)
    print(f"\nPattern Counts: {counts1}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments1, counts1, level=1)}")
    
    print("\n" + "="*60 + "\n")
    
    # Test with suffix '0', level=3
    print("=== TESTING WITH SUFFIX '0', LEVEL=3 ===")
    segments0 = segment_binary_string(TEST_INPUT, suffix='0', level=3)
    print_segmentation_results(TEST_INPUT, segments0, suffix='0')
    counts0 = pattern_repeat_not_repeat(TEST_INPUT, segments0, level=3)
    print(f"\nPattern Counts: {counts0}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments0, counts0, level=3)}")
    
    print("\n" + "="*60 + "\n")
    
    # Test with provided segment list, level=2
    print("=== TESTING WITH PROVIDED SEGMENT LIST, LEVEL=2 ===")
    provided_segments = [
        ('1010', 'Alternating_A1', 4), ('00000', 'DownRun', 5), ('11', 'UpRun', 2), ('00', 'DownRun', 2),
        ('0101', 'Alternating_A0', 4), ('11', 'UpRun', 2), ('00', 'DownRun', 2), ('010', 'Alternating_A0', 3),
        ('00', 'DownRun', 2), ('111', 'UpRun', 3), ('000', 'DownRun', 3), ('111', 'UpRun', 3),
        ('00', 'DownRun', 2), ('010101', 'Alternating_A0', 6), ('11', 'UpRun', 2), ('1010', 'Alternating_A1', 4),
        ('000', 'DownRun', 3), ('1111111', 'UpRun', 7), ('1010', 'Alternating_A1', 4), ('00', 'DownRun', 2),
        ('111', 'UpRun', 3), ('00', 'DownRun', 2)
    ]
    provided_segments.reverse()  # Reverse to match newest-to-oldest order
    counts_provided = pattern_repeat_not_repeat("", provided_segments, level=2)
    print(f"\nPattern Counts for Provided Segments: {counts_provided}")
    print(f"\nRecommendation: {generate_streak_recommendation(provided_segments, counts_provided, level=2)}")
    
    print("\n" + "="*60 + "\n")
    
    # Test for level=1 with example input
    print("=== TESTING EXAMPLE INPUT, LEVEL=1 ===")
    example_input = "100110001110111010"
    segments_example = segment_binary_string(example_input, level=1)
    print_segmentation_results(example_input, segments_example)
    counts_example = pattern_repeat_not_repeat(example_input, segments_example, level=1)
    print(f"\nPattern Counts: {counts_example}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_example, counts_example, level=1)}")
    
    print("\n" + "="*60 + "\n")
    
    # Test for level=1 with problematic input
    print("=== TESTING LEVEL=1 WITH PROBLEMATIC INPUT ===")
    problem_input = "111011001101011011111000001010101110000010111001101111010011100011111010100101011001111101101011110"
    segments_problem = segment_binary_string(problem_input, suffix='1', level=1)
    print_segmentation_results(problem_input, segments_problem, suffix='1')
    counts_problem = pattern_repeat_not_repeat(problem_input, segments_problem, level=1)
    print(f"\nPattern Counts: {counts_problem}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_problem, counts_problem, level=1)}")
    
    print("\n" + "="*60 + "\n")
    
    # Additional test for level=3 to verify length classification
    print("=== TESTING LEVEL=3 WITH EXAMPLE INPUT ===")
    example_input_3 = "1110000101011110001111"
    segments_3 = segment_binary_string(example_input_3, level=3)
    print_segmentation_results(example_input_3, segments_3)
    counts_3 = pattern_repeat_not_repeat(example_input_3, segments_3, level=3)
    print(f"\nPattern Counts: {counts_3}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_3, counts_3, level=3)}")
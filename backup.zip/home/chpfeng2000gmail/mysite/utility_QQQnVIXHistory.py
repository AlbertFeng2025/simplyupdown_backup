import yfinance as yf
import pandas as pd

def get_aligned_qqq_vix_data(start_date, end_date):
    """
    Fetches daily data for QQQ and VIX, aligns them by date,
    and returns paired historical changes and levels within a specific date range.
    """
    print(f"Fetching and aligning data for QQQ and VIX from {start_date} to {end_date}...")

    qqq_ticker = yf.Ticker("QQQ")
    vix_ticker = yf.Ticker("^VIX")

    # 1. Fetch data.
    # We fetch starting 5 days early to ensure the first day in our target range
    # has a previous close to calculate pct_change() against.
    # We add 1 day to the end_date because yfinance's 'end' parameter is exclusive.
    fetch_start = (pd.to_datetime(start_date) - pd.Timedelta(days=5)).strftime('%Y-%m-%d')
    fetch_end = (pd.to_datetime(end_date) + pd.Timedelta(days=1)).strftime('%Y-%m-%d')

    qqq_hist = qqq_ticker.history(start=fetch_start, end=fetch_end)
    vix_hist = vix_ticker.history(start=fetch_start, end=fetch_end)

    if qqq_hist.empty or vix_hist.empty:
        print("Error: Could not retrieve data. Check your connection, dates, or tickers.")
        return [], [], [], []

    # -----------------------------------------------------------------------------------
    # CRITICAL FIX FOR GOOGLE COLAB / PANDAS TIMEZONES:
    # Strip timezone information (make timezone-naive) before performing the join.
    # This forces both DatetimeIndexes to align on standard local calendar dates.
    # -----------------------------------------------------------------------------------
    qqq_hist.index = qqq_hist.index.tz_localize(None)
    vix_hist.index = vix_hist.index.tz_localize(None)

    # 2. Calculate daily percentage changes
    qqq_hist['QQQ_Change_Pct'] = qqq_hist['Close'].pct_change() * 100
    vix_hist['VIX_Close'] = vix_hist['Close']
    vix_hist['VIX_Change_Pct'] = vix_hist['Close'].pct_change() * 100

    # 3. Align the datasets on their Date index (inner join keeps only matching dates)
    aligned_df = pd.concat([
        qqq_hist['QQQ_Change_Pct'],
        vix_hist['VIX_Close'],
        vix_hist['VIX_Change_Pct']
    ], axis=1, join='inner')

    # Rename columns for clarity
    aligned_df.columns = ['QQQ_Change_Pct', 'VIX_Close', 'VIX_Change_Pct']

    # 4. Clean up NaN values and slice to the exact user-requested date range
    aligned_df = aligned_df.dropna()
    aligned_df = aligned_df.loc[start_date:end_date]

    # 5. Format the outputs as lists
    dates = aligned_df.index.strftime('%Y-%m-%d').tolist()
    qqq_changes = [f"{val:+.2f}%" for val in aligned_df['QQQ_Change_Pct']]
    vix_closes = [f"{val:.2f}" for val in aligned_df['VIX_Close']]
    vix_changes = [f"{val:+.2f}%" for val in aligned_df['VIX_Change_Pct']]

    return dates, qqq_changes, vix_closes, vix_changes

if __name__ == "__main__":
    # Define your exact date range here (Format: YYYY-MM-DD)
    START_DATE = "2025-04-01"
    END_DATE = "2026-04-30"

    dates, qqq_chg, vix_cls, vix_chg = get_aligned_qqq_vix_data(START_DATE, END_DATE)

    print("\n" + "="*70)
    print(f" ALIGNED DAILY MARKET METRICS ({START_DATE} to {END_DATE})")
    print("="*70)

    if not dates:
        print(" No data found for this date range.")
    else:
        print(f" {'Date':<12} | {'QQQ Change':<12} | {'VIX Close':<12} | {'VIX Daily Change':<16}")
        print("-" * 70)

        for date, q_chg, v_cls, v_chg in zip(dates, qqq_chg, vix_cls, vix_chg):
            print(f" {date:<12} | {q_chg:>10}   | {v_cls:>10}   | {v_chg:>12}")

    print("=" * 70)
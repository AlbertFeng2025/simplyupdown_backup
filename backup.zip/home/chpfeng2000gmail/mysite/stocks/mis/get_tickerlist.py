import requests
import pandas as pd
import yfinance as yf
from io import StringIO

# 1. Configuration & Ticker Lists
OUTPUT_FILE = "/home/chpfeng2000gmail/mysite/market_master_list.csv"

popular_etfs = [
    'SPY', 'QQQ', 'VOO', 'IVV', 'VTI', 'IWM', 'DIA', 'VUG', 'VTV', 'QQQM', 'SPLG',
    'XLK', 'SMH', 'SOXX', 'ARKK', 'ARKW', 'IBIT', 'FBTC', 'BITO',
    'SCHD', 'VYM', 'VIG', 'DGRO', 'JEPI', 'JEPQ', 'SDY', 'NOBL', 'DVY',
    'XLF', 'XLV', 'XLE', 'XLY', 'XLP', 'XLI', 'XLB', 'XLU', 'XLRE', 'XLC',
    'VEA', 'IEFA', 'VXUS', 'VWO', 'EEM', 'IEMG', 'VGK', 'EWJ', 'FXI',
    'GLD', 'IAU', 'GLDM', 'SLV', 'GDX', 'GDXJ', 'USO', 'UNG', 'DBA',
    'BND', 'AGG', 'TLT', 'IEF', 'SHY', 'LQD', 'HYG', 'MUB'
]

popular_futures = [
    'ES=F', 'NQ=F', 'YM=F', 'RTY=F', 'GC=F', 'SI=F', 'HG=F',
    'CL=F', 'NG=F', 'RB=F', 'ZC=F', 'ZS=F', 'ZW=F',
    '6E=F', '6J=F', '6B=F', 'ZB=F', 'ZN=F', 'ZT=F', 'VX=F'
]

# Set for O(1) lookup speed
ALWAYS_KEEP = set(popular_etfs + popular_futures)

def get_sp500_tickers():
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        response = requests.get(url, headers=headers, timeout=15)
        tables = pd.read_html(StringIO(response.text))
        return tables[0]['Symbol'].tolist()
    except Exception as e:
        print(f"Wikipedia fallback: {e}")
        return ['AAPL', 'MSFT', 'NVDA', 'AMZN', 'META']

# 2. Main Execution
all_tickers = list(set(get_sp500_tickers() + list(ALWAYS_KEEP)))
final_results = []

print(f"Processing {len(all_tickers)} symbols...")

# Create a Tickers object for batch processing
tickers_obj = yf.Tickers(" ".join(all_tickers))

for symbol in all_tickers:
    try:
        # yfinance uses '-' for '.' in symbols internally
        t_clean = symbol.replace('.', '-')
        t_obj = tickers_obj.tickers[t_clean]
        
        # Use fast_info for filtering (much faster than .info)
        f_info = t_obj.fast_info
        
        # Logic: Keep if it's a manually added ETF/Future OR it meets volume criteria
        is_manual = symbol in ALWAYS_KEEP
        is_liquid = f_info.get('last_price', 0) > 5 and f_info.get('last_volume', 0) > 1000000
        
        if is_manual or is_liquid:
            # OPTIMIZATION: Only call .info if the ticker passes the filter.
            # Even better, we try to use shortName which is usually in fast_info/metadata
            name = t_obj.info.get('longName') or t_obj.info.get('shortName') or symbol
            
            final_results.append({'Ticker': symbol, 'Company Name': name})
            print(f"Added: {symbol}")
            
    except Exception as e:
        # print(f"Skipping {symbol}: {e}")
        continue

# 3. Save Results
df = pd.DataFrame(final_results)
if not df.empty:
    df.to_csv(OUTPUT_FILE, index=False)
    print(f"\nSuccess! {len(df)} tickers saved to: {OUTPUT_FILE}")
#wake up Djano
import os
import sys
import django

# 1. Add the directory ABOVE mysite to the path
# This allows 'import mysite.settings' to work
base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if base_dir not in sys.path:
    sys.path.append(base_dir)

# 2. Set the module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')

# 3. Boot Django
django.setup()

import tweepy
from django.conf import settings

def post_to_x():
    print("🚀 Starting X (Twitter) Post...")

    # 1. Setup Authentication
    # We use OAuth 1.0a for posting (User Context)
    try:
        print("🔑 Authenticating with X API...")
        client = tweepy.Client(
            consumer_key=settings.X_CONSUMER_KEY.strip(),
            consumer_secret=settings.X_CONSUMER_SECRET.strip(),
            access_token=settings.X_ACCESS_TOKEN.strip(),
            access_token_secret=settings.X_ACCESS_TOKEN_SECRET.strip()
        )
        print("✅ Authentication strings loaded.")

        # 2. Attempt the Post
        message = "simplyupdown is better than XGBoost/LightGBM !"
        print(f"📡 Sending Tweet: '{message}'")

        response = client.create_tweet(text=message)

        # 3. Success Check
        tweet_id = response.data['id']
        print(f"🎉 SUCCESS! Tweet posted.")
        print(f"Tweet ID: {tweet_id}")
        print(f"Link: https://x.com/user/status/{tweet_id}")

    except tweepy.TweepyException as e:
        print("\n❌ X API ERROR CAUGHT:")
        # This will tell us if it's a 401 (Keys), 403 (Permissions), or 429 (Rate Limit)
        print(f"Error Detail: {e}")

        if "403" in str(e):
            print("\n💡 DIAGNOSIS: Permission Issue.")
            print("Action: Go to Developer Portal > App Settings > User Authentication Settings.")
            print("Ensure 'App Permissions' is set to 'Read and Write'.")
            print("CRITICAL: If you changed this recently, you MUST regenerate your Access Tokens!")

        elif "401" in str(e):
            print("\n💡 DIAGNOSIS: Key Issue.")
            print("Action: Check for hidden spaces in your .env file or incorrect Consumer Secret.")

if __name__ == "__main__":
    post_to_x()

# working code but need pay account. x has no free account
# wake up Django
import os
import sys
import django

# 1. Add the directory ABOVE mysite to the path
base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if base_dir not in sys.path:
    sys.path.append(base_dir)

# 2. Set the module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')

# 3. Boot Django
django.setup()

import tweepy
from django.conf import settings

def post_to_x():
    print("🚀 Starting X (Twitter) Post...")

    # --- DEBUG PRINT BLOCK ---
    print("\n--- 🔍 DEBUG: KEY VERIFICATION ---")
    keys_to_check = {
        "CONSUMER_KEY": settings.X_CONSUMER_KEY,
        "CONSUMER_SECRET": settings.X_CONSUMER_SECRET,
        "ACCESS_TOKEN": settings.X_ACCESS_TOKEN,
        "ACCESS_TOKEN_SECRET": settings.X_ACCESS_TOKEN_SECRET
    }

    for name, value in keys_to_check.items():
        val = value.strip()
        if not val or val == "123":
            print(f"❌ {name}: [NOT SET OR DEFAULT]")
        else:
            # Show first 4, last 4, and total length
            print(f"✅ {name}: {val[:4]}...{val[-4:]} (Length: {len(val)})")
    print("-----------------------------------\n")
    # --------------------------

    # 1. Setup Authentication
    try:
        print("🔑 Authenticating with X API...")
        client = tweepy.Client(
            consumer_key=settings.X_CONSUMER_KEY.strip(),
            consumer_secret=settings.X_CONSUMER_SECRET.strip(),
            access_token=settings.X_ACCESS_TOKEN.strip(),
            access_token_secret=settings.X_ACCESS_TOKEN_SECRET.strip()
        )
        print("✅ Authentication strings loaded.")

        # 2. Attempt the Post
        message = "simplyupdown is better than XGBoost/LightGBM !"
        print(f"📡 Sending Tweet: '{message}'")

        response = client.create_tweet(text=message)

        # 3. Success Check
        tweet_id = response.data['id']
        print(f"🎉 SUCCESS! Tweet posted.")
        print(f"Tweet ID: {tweet_id}")
        print(f"Link: https://x.com/user/status/{tweet_id}")

    except tweepy.TweepyException as e:
        print("\n❌ X API ERROR CAUGHT:")
        print(f"Error Detail: {e}")

        if "403" in str(e):
            print("\n💡 DIAGNOSIS: Permission Issue.")
            print("Action: Ensure 'App Permissions' is set to 'Read and Write'.")
            print("CRITICAL: If you changed this recently, you MUST regenerate your Access Tokens!")

        elif "401" in str(e):
            print("\n💡 DIAGNOSIS: Key Issue.")
            print("Action: Compare the 4 characters above with the X Developer Portal.")
            print("Note: Access Token is usually MUCH longer than Consumer Key.")

if __name__ == "__main__":
    post_to_x()
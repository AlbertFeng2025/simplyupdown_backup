from django.conf import settings
import requests

# ================== CONFIGURATION ==================
# Since your token is PERMANENT and tied to this specific PAGE_ID,
# we can go straight to Step 2.
PAGE_ID = settings.FACEBOOK_PAGE_ID  # '1104695659386076'
PAGE_TOKEN = settings.FACEBOOK_ACCESS_TOKEN 
MESSAGE = "To find more of Why Cycle-Segment Probability Analysis Outperforms Modern Machine Learning in Financial Time-Series, please contact me"

VERSION = "v25.0"
# ====================================================

def publish_to_facebook():
    print("🚀 Starting Facebook Page Post...")
    
    # Direct Post URL
    post_url = f"https://graph.facebook.com/{VERSION}/{PAGE_ID}/feed"
    
    post_data = {
        "message": MESSAGE,
        "access_token": PAGE_TOKEN
    }
    
    print(f"📡 Sending request to Page ID: {PAGE_ID}...")
    
    response = requests.post(post_url, data=post_data)
    
    if response.status_code == 200:
        post_id = response.json().get("id")
        print("🎉 SUCCESS! Post published successfully!")
        print(f"Post ID: {post_id}")
        # The URL format for new pages often works better like this:
        print(f"Direct Link: https://www.facebook.com/{PAGE_ID}/posts/{post_id.split('_')[-1]}")
    else:
        print("❌ Failed to post:")
        print(response.json())

if __name__ == "__main__":
    publish_to_facebook()
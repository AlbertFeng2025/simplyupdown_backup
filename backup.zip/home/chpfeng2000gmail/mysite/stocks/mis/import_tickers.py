import requests
import pandas as pd
import yfinance as yf
from io import StringIO

# 1. Setup
OUTPUT_FILE = "/home/chpfeng2000gmail/mysite/market_master_list.csv"

def get_sp500_tickers():
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        response = requests.get(url, headers=headers, timeout=15)
        tables = pd.read_html(StringIO(response.text))
        # Keep both Symbol and Name from Wikipedia to avoid calling .info later
        return tables[0][['Symbol', 'Security']].values.tolist()
    except Exception as e:
        print(f"Wikipedia Error: {e}")
        return [['AAPL', 'Apple Inc.'], ['MSFT', 'Microsoft']]

# 2. Build the List
sp500_data = get_sp500_tickers()
sp500_symbols = [row[0] for row in sp500_data]

popular_etfs = ['SPY', 'QQQ', 'VOO', 'IVV', 'VTI', 'IWM', 'DIA', 'XLK', 'SMH', 'IBIT', 'GLD', 'TLT']
popular_futures = ['ES=F', 'NQ=F', 'YM=F', 'RTY=F', 'GC=F', 'CL=F', 'ZN=F']

# Set of tickers that bypass all filters
MUST_KEEP = set(sp500_symbols + popular_etfs + popular_futures)

final_results = []

# Add the S&P 500 stocks immediately (using names from Wikipedia)
for symbol, name in sp500_data:
    final_results.append({'Ticker': symbol, 'Company Name': name})

# Add the ETFs and Futures (fetching names in one batch)
print(f"Fetching names for ETFs and Futures...")
remaining_specials = [t for t in (popular_etfs + popular_futures) if t not in sp500_symbols]

for t in remaining_specials:
    try:
        ticker_obj = yf.Ticker(t)
        # Try to get name without a heavy .info call first
        name = ticker_obj.fast_info.get('shortName') or ticker_obj.info.get('shortName') or t
        final_results.append({'Ticker': t, 'Company Name': name})
        print(f"Added Special: {t}")
    except:
        final_results.append({'Ticker': t, 'Company Name': t})

# 3. Save
df = pd.DataFrame(final_results).drop_duplicates(subset=['Ticker'])
df.to_csv(OUTPUT_FILE, index=False)

print(f"\nSuccess! Total tickers saved: {len(df)}")
print(f"File location: {OUTPUT_FILE}")
import pytz
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class SysSymbolcandidate(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    symbol = models.CharField(db_column='Symbol', unique=True, max_length=10)
    company_name = models.TextField()
    lastscanned = models.DateTimeField(db_column='LastScanned', blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'sys_SymbolCandidate'

class SignalMonitor(models.Model):
    ticker = models.CharField(max_length=10)
    company_name = models.TextField()
    cycle = models.CharField(max_length=10, default='Daily')
    last_close_price = models.FloatField()
    last_close_date = models.DateTimeField(null=True, blank=True)
    last_monitored = models.DateTimeField(auto_now_add=True)
    recent_pos_string = models.TextField()

    RUN_CHOICES = [('UpRun', 'Up Run'), ('DownRun', 'Down Run')]
    run_direction = models.CharField(max_length=10, choices=RUN_CHOICES)
    level = models.IntegerField()
    recent_outcome = models.TextField(null=True, blank=True)
    recommendation = models.CharField(max_length=20, blank=True)
    trigger_digit = models.CharField(max_length=1)

    win_rate = models.FloatField()
    ev_pct = models.FloatField(default=0.0)
    sharpe_ratio = models.FloatField(default=0.0)
    annual_return = models.FloatField(default=0.0)
    sample_count = models.IntegerField(default=0)
    win_loss_ratio = models.FloatField(default=0.0, verbose_name="Risk Reward Ratio")
    max_consec_losses = models.IntegerField(default=0, verbose_name="Max Consecutive Losses")

    STATUS_CHOICES = [
        ('Waiting', 'Waiting for Pattern'),
        ('Triggered', 'Signal Active'),
        ('Failed', 'Pattern Broken')
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Waiting')
    missing_count = models.IntegerField(default=0)
    # AI Sentiment / Vibe Fields
    ai_vibe_score = models.FloatField(default=0.0)  # Standardized -1.0 to +1.0
    ai_vibe_label = models.CharField(max_length=30, blank=True)  # e.g., 'Supportive', 'Overheated'
    ai_vibe_reason = models.TextField(blank=True)  # Short AI summary or top headlines JSON
    last_vibe_update = models.DateTimeField(null=True, blank=True)

    @property
    def vibe_color_class(self):
        """Returns a CSS class name based on the AI Vibe Label"""
        # We use self.ai_vibe_label to look at the current record's label
        label = self.ai_vibe_label

        # Positive/Green labels
        if label in ["Supportive", "Confirming"]:
            return "text-success"

        # Cautionary/Yellow labels
        if label in ["Mixed", "Technical", "Neutral"]:
            return "text-warning"

        # Dangerous/Red labels
        if label in ["Overheated", "Panic", "Oversold", "Squeeze"]:
            return "text-danger"

        # Default Gray if nothing matches
        return "text-secondary"

    class Meta:
        db_table = 'sys_SignalMonitor'
        unique_together = ('ticker', 'cycle', 'level', 'run_direction', 'recommendation', 'last_close_date')
        ordering = ['-last_close_date', 'ticker']

    def __str__(self):
        return f"{self.ticker} | {self.recommendation} | Level {self.level} ({self.status})"

class UpDownHistPerf(models.Model):
    ticker = models.CharField(max_length=20, db_index=True)
    level = models.IntegerField(db_index=True)
    run_direction = models.CharField(max_length=10, db_index=True)
    trade_direction = models.CharField(max_length=10, db_index=True)
    cycle = models.CharField(max_length=10, db_index=True, default="Daily")
    pos_string = models.TextField()
    target_pattern = models.CharField(max_length=20)
    watch_pattern = models.CharField(max_length=20)
    win_rate = models.FloatField(null=True, blank=True)
    avg_win_pct = models.FloatField(null=True, blank=True)
    avg_lose_pct = models.FloatField(null=True, blank=True)
    win_loss_ratio = models.FloatField(null=True, blank=True)
    max_loss_pct = models.FloatField(null=True, blank=True)
    max_consec_losses = models.IntegerField(default=0)
    ev_pct = models.FloatField(null=True, blank=True)
    sharpe_ratio = models.FloatField(null=True, blank=True)
    annual_compound_pct = models.FloatField(null=True, blank=True)
    sample_count = models.IntegerField(default=0)
    trade_position_detail = models.JSONField(default=list, blank=True)
    last_scan_date = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'sys_updown_histperf'
        unique_together = ('ticker', 'level', 'run_direction', 'trade_direction', 'cycle')

    def __str__(self):
        return f"{self.ticker} - L{self.level} {self.run_direction} {self.trade_direction}"


class StrategyArchive(models.Model):
    ticker = models.CharField(max_length=10, db_index=True)
    cycle = models.CharField(max_length=10, db_index=True)
    institutional_edge = models.CharField(max_length=50)
    run_direction = models.CharField(max_length=10)
    level = models.IntegerField()
    recommendation = models.CharField(max_length=10)
    record_created_at = models.DateTimeField(auto_now_add=True)
    entry_date = models.DateField(db_index=True)
    entry_price = models.FloatField()
    expected_exit_date = models.DateField(null=True, blank=True)
    exit_date = models.DateField(null=True, blank=True)
    exit_price = models.FloatField(null=True, blank=True)
    status = models.CharField(max_length=10, default='ACTIVE')
    profit_pct = models.FloatField(null=True, blank=True)
    is_win = models.BooleanField(null=True)
    notes = models.TextField(null=True, blank=True, default='')

    def record_created_at_ny(self):
        ny_tz = pytz.timezone('America/New_York')
        return self.record_created_at.astimezone(ny_tz).strftime('%Y-%m-%d %I:%M %p')
    record_created_at_ny.short_description = 'Created At (NY Time)'

    class Meta:
        db_table = 'sys_strategy_archive'
        unique_together = ('ticker', 'entry_date', 'cycle', 'level', 'recommendation')
        indexes = [models.Index(fields=['record_created_at'])]

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    TIER_CHOICES = [('FREE', 'Free Member'), ('PREM', 'Premium Member'), ('PLAT', 'Platinum Member')]
    tier = models.CharField(max_length=4, choices=TIER_CHOICES, default='FREE')
    subscription_start = models.DateField(null=True, blank=True)
    subscription_end = models.DateField(null=True, blank=True)
    subscription_status = models.CharField(max_length=20, default='inactive')
    phone = models.CharField(max_length=20, null=True, blank=True)
    first_name = models.CharField(max_length=50, null=True, blank=True)
    last_name = models.CharField(max_length=50, null=True, blank=True)
    address_line = models.CharField(max_length=100, null=True, blank=True)
    city = models.CharField(max_length=50, null=True, blank=True)
    postal_code = models.CharField(max_length=20, null=True, blank=True)
    country = models.CharField(max_length=50, null=True, blank=True)
    timezone = models.CharField(max_length=50, default='America/New_York')
    alert_email = models.BooleanField(default=False)

    alert_telegram = models.BooleanField(default=False)
    telegram_chat_id = models.CharField(max_length=50, null=True, blank=True)
    alert_discord = models.BooleanField(default=False)
    discord_user_id = models.CharField(max_length=50, null=True, blank=True)
    alert_sms = models.BooleanField(default=False)
    alert_api = models.BooleanField(default=False)
    api_key = models.CharField(max_length=64, null=True, blank=True, unique=True)
    custom_tickers = models.JSONField(default=list, blank=True)
    include_house_alerts = models.BooleanField(default=True)
    # PLAT only — if True, receive alerts from house ticker list in addition to custom list
    alert_cycle_daily = models.BooleanField(default=False)
    alert_cycle_weekly = models.BooleanField(default=False)
    alert_cycle_monthly = models.BooleanField(default=False)
    min_win_rate_filter = models.FloatField(default=0.60)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    # Add this one line to your existing Profile class
    stripe_customer_id = models.CharField(max_length=255, blank=True, null=True)
    is_subscribed = models.BooleanField(
            default=True,
            verbose_name="Marketing Subscription",
            help_text="User's consent to receive marketing and promotional emails."
        )

    # Add these 4 fields to Profile model, after min_win_rate_filter
    # along with aboe win rate filter, we have 5 filter now.

    min_ev_filter = models.FloatField(default=0.01)          # stores 0.01 = 1% EV
    min_sharpe_filter = models.FloatField(default=0.5)      # stores 0.5 = Sharpe ratio
    min_annual_return_filter = models.FloatField(default=0.1)  # stores 0.1 = 10% annual
    min_sample_count_filter = models.IntegerField(default=20)   # stores 20 = min trades
    min_rr_filter = models.FloatField(default=1.0)           # stores raw ratio, e.g. 1.5 = winners are 1.5× losers

    @property
    def has_active_premium(self):
        """Returns True for BOTH Premium and Platinum users (if not expired)."""
        if self.tier in ['PREM', 'PLAT']:
            return self.subscription_end >= timezone.now().date()
        return False

    @property
    def has_active_platinum(self):
        """Returns True ONLY for Platinum users."""
        if self.tier == 'PLAT':
            return self.subscription_end >= timezone.now().date()
        return False


    class Meta:
        db_table = 'sys_Userprofile'

    def __str__(self):
        return f"{self.user.username} - {self.get_tier_display()}"

#@receiver(post_save, sender=User)
#def create_user_profile(sender, instance, created, **kwargs):
#    if created:
#        Profile.objects.get_or_create(user=instance)


class PaymentHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name='payments')
    PLAN_CHOICES = [('PREM_MONTHLY', 'Premium Monthly'), ('PREM_YEARLY', 'Premium Annual'), ('PLAT_MONTHLY', 'Platinum Monthly'), ('PLAT_YEARLY', 'Platinum Annual')]
    plan = models.CharField(max_length=20, choices=PLAN_CHOICES)
    amount = models.DecimalField(max_digits=8, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')
    STATUS_CHOICES = [('pending', 'Pending'), ('succeeded', 'Succeeded'), ('failed', 'Failed'), ('refunded', 'Refunded'), ('cancelled', 'Cancelled')]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    PROVIDER_CHOICES = [('stripe', 'Stripe'), ('paypal', 'PayPal'), ('manual', 'Manual')]
    provider = models.CharField(max_length=20, choices=PROVIDER_CHOICES, default='manual')
    provider_ref = models.CharField(max_length=200, null=True, blank=True)
    period_start = models.DateField(null=True, blank=True)
    period_end = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'sys_PaymentHistory'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} | {self.get_plan_display()} | ${self.amount} | {self.status}"

    def record_created_ny(self):
        ny_tz = pytz.timezone('America/New_York')
        return self.created_at.astimezone(ny_tz).strftime('%Y-%m-%d %I:%M %p ET')
    record_created_ny.short_description = 'Created (NY Time)'

class HouseTicker(models.Model):
    symbol       = models.CharField(max_length=10, unique=True)
    company_name = models.TextField(blank=True, default='')
    added_date   = models.DateField(auto_now_add=True)
    is_active    = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        # Uppercase and strip before saving
        self.symbol = self.symbol.strip().upper()
        # Save to this table first
        super().save(*args, **kwargs)
        # Then auto sync to candidate pool
        # get_or_create prevents duplicates
        SysSymbolcandidate.objects.get_or_create(
            symbol=self.symbol,
            defaults={'company_name': self.company_name}
        )

    class Meta:
        db_table = 'sys_HouseTicker'
        ordering = ['symbol']

    def __str__(self):
        return f"{self.symbol} — {self.company_name}"

# signal delivery log
class SignalAlertLog(models.Model):
    user            = models.ForeignKey(User, on_delete=models.CASCADE)
    cycle           = models.CharField(max_length=20)     # Daily/Weekly/Monthly
    alert_type      = models.CharField(max_length=20)     # watching/final
    channel         = models.CharField(max_length=20)     # email/telegram/sms
    signals_payload = models.JSONField(default=list)
    sent_at         = models.DateTimeField(auto_now_add=True)
    status          = models.CharField(max_length=20)     # sent/failed
    error_msg       = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'sys_SignalAlertLog'
        ordering = ['-sent_at']

    def __str__(self):
        return (
            f"{self.user.username} | {self.cycle} | "
            f"{self.alert_type} | {self.channel} | "
            f"{self.status} | {self.sent_at:%Y-%m-%d %H:%M}"
        )

class SiteAnnouncement(models.Model):
    message = models.TextField(help_text="Enter the announcement text here")
    is_active = models.BooleanField(default=False, help_text="Check this to show the message on the site")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Site Announcement"

    def __str__(self):
        return f"Announcement from {self.created_at.strftime('%Y-%m-%d')}"
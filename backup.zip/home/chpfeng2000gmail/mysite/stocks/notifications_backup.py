# stocks/notifications.py
#
# Signal delivery system — handles email, telegram (placeholder), sms (placeholder)
# Called by: python manage.py deliver_signals --cycle Daily --alert-type watching
#
# Flow:
#   1. get_house_symbols()          — house ticker list
#   2. build_price_cache()          — fetch live prices ONCE for all signals
#   3. get_triggered_signals()      — calculate triggered status per signal
#   4. get_member_signals()         — filter down to what each member can see
#   5. build_email_message()        — format the email content
#   6. send_email()                 — send via Brevo SMTP
#   7. send_telegram()              — placeholder
#   8. send_sms()                   — placeholder
#   9. log_alert()                  — write to SignalAlertLog
#  10. get_watching_tickers()       — read 3:30 PM log for final alert comparison
#  11. deliver_signals()            — main entry point, called by management command

import logging
import datetime
import pytz
import requests

from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.contrib.auth.models import User

from stocks.models import SignalMonitor, HouseTicker, SignalAlertLog
# Correct — matches actual file location
from stocks.views.services import MarketDataService
from django.db.models import Q

logger = logging.getLogger(__name__)
NY_TZ  = pytz.timezone('America/New_York')


# ─────────────────────────────────────────────────────────────
# SECTION 1 — Ticker & Price Engine
# ─────────────────────────────────────────────────────────────

def get_house_symbols():
    """Return active house ticker list — same source as radar_view."""
    return list(
        HouseTicker.objects.filter(is_active=True).values_list('symbol', flat=True)
    )


def build_price_cache(signals):
    """
    Fetch live price ONCE per unique ticker across all signals.
    Returns dict: {"AAPL": 182.50, "TSLA": 241.30, ...}

    This avoids fetching the same ticker price multiple times
    when multiple members watch the same ticker.
    """
    price_cache = {}
    unique_tickers = list({sig.ticker: sig for sig in signals}.items())

    for ticker, sig in unique_tickers:
        try:
            live_price, _, _, _ = MarketDataService.get_live_price(
                ticker,
                sig.last_close_price,
                force_refresh=True,
                include_news=False      # skip news — speed matters at alert time
            )
            price_cache[ticker] = live_price
            logger.info(f"Price fetched: {ticker} = {live_price}")
        except Exception as e:
            # Fallback to last close if live fetch fails
            price_cache[ticker] = float(sig.last_close_price)
            logger.warning(f"Price fetch failed for {ticker}, using last close. Error: {e}")

    return price_cache


def get_triggered_signals(cycle, price_cache):
    """
    Query SignalMonitor for the given cycle.
    Use price_cache to calculate triggered status.
    Returns list of dicts — all signals with is_triggered flag.
    """
    signals = SignalMonitor.objects.filter(
        cycle=cycle,
        status='Waiting',
    )

    result = []
    for sig in signals:
        live_price     = price_cache.get(sig.ticker, float(sig.last_close_price))
        current_digit  = "1" if live_price > float(sig.last_close_price) else "0"
        is_triggered   = (current_digit == sig.trigger_digit)

        result.append({
            'ticker'        : sig.ticker,
            'action'        : sig.recommendation,   # LONG or SHORT
            'cycle'         : cycle,
            'level'         : sig.level,
            'win_rate'      : float(sig.win_rate),
            'ev_pct'        : float(sig.ev_pct or 0),
            'sharpe_ratio'  : float(sig.sharpe_ratio or 0),
            'annual_return' : float(sig.annual_return or 0),
            'sample_count'  : sig.sample_count or 0,
            'is_triggered'  : is_triggered,
        })

    return result


# ─────────────────────────────────────────────────────────────
# SECTION 2 — Per-Member Filter
# ─────────────────────────────────────────────────────────────

def get_member_signals(profile, all_signals, cycle, house_symbols):
    """
    Filter all_signals down to what this specific member can see,
    applying their tier rules and personal filters.

    PREM  → house symbols only, floored at house minimums
    PLAT  → custom_tickers + house (if include_house_alerts=True), no floor
    """
    from django.conf import settings
    house_filters = settings.HOUSE_FILTERS.get(cycle, settings.HOUSE_FILTERS['Daily'])

    # ── Determine ticker scope ────────────────────────────────
    if profile.tier == 'PREM':
        allowed_tickers = set(house_symbols)

    elif profile.tier == 'PLAT':
        custom = set(profile.custom_tickers or [])
        if profile.include_house_alerts:
            allowed_tickers = custom | set(house_symbols)
        else:
            allowed_tickers = custom
    else:
        return []   # FREE/VISITOR — no alerts

    # ── Determine filter thresholds ───────────────────────────

    if profile.tier == 'PREM':
        min_win_rate = max(profile.min_win_rate_filter or 0, house_filters['min_win_rate'])
        min_ev       = max(profile.min_ev_filter or 0,       house_filters['min_ev'])
        min_sharpe   = max(profile.min_sharpe_filter or 0,   house_filters['min_sharpe'])
        min_samples  = max(profile.min_sample_count_filter or 0, house_filters['min_samples'])
        min_annual   = profile.min_annual_return_filter \
            if profile.min_annual_return_filter is not None else -999.0

    else:  # PLAT — full control, no floor
        min_win_rate = profile.min_win_rate_filter       if profile.min_win_rate_filter       is not None else 0
        min_ev       = profile.min_ev_filter             if profile.min_ev_filter             is not None else 0
        min_sharpe   = profile.min_sharpe_filter         if profile.min_sharpe_filter         is not None else 0
        min_samples  = profile.min_sample_count_filter   if profile.min_sample_count_filter   is not None else 0
        min_annual   = profile.min_annual_return_filter  if profile.min_annual_return_filter  is not None else -999.0


    # ── Apply filters ─────────────────────────────────────────
    filtered = []
    for sig in all_signals:
        if sig['ticker'] not in allowed_tickers:
            continue
        if sig['win_rate']      < min_win_rate:
            continue
        if sig['ev_pct']        < min_ev:
            continue
        if sig['sharpe_ratio']  < min_sharpe:
            continue
        if sig['sample_count']  < min_samples:
            continue
        if sig['annual_return'] < min_annual:
            continue
        filtered.append(sig)

    return filtered


# ─────────────────────────────────────────────────────────────
# SECTION 3 — Message Builder
# ─────────────────────────────────────────────────────────────

def build_email_message(profile, triggered_signals, alert_type, cycle, dropped_tickers=None):
    """
    Build plain-text email subject and body.

    alert_type = 'watching' → 3:30 PM warning alert
    alert_type = 'final'    → 3:55 PM final alert (includes dropped)
    """
    first_name = (
                profile.first_name or
                profile.user.username or
                profile.user.email.split('@')[0]
             )

    if alert_type == 'watching':
        subject = f"⚠️ SimplyUpDown — {cycle} Signals to Watch ({len(triggered_signals)} triggered)"
        intro   = (
            f"Hi {first_name},\n\n"
            f"The following {cycle} signals are currently triggered as of 3:30 PM ET.\n"
            f"These are NOT final — market is still open.\n"
            f"Final confirmation alert will be sent at 3:55 PM ET.\n\n"
        )
    else:
        subject = f"✅ SimplyUpDown — {cycle} Final Signals ({len(triggered_signals)} confirmed)"
        intro   = (
            f"Hi {first_name},\n\n"
            f"Final {cycle} signal status as of 3:55 PM ET.\n"
            f"Market closes at 4:00 PM ET.\n\n"
        )

    # ── Triggered signals table ───────────────────────────────
    if triggered_signals:
        lines = ["TRIGGERED SIGNALS:"]
        lines.append("-" * 40)
        for sig in triggered_signals:
            win_pct = round(sig['win_rate'] * 100)
            tag     = "🆕 NEW" if sig.get('status') == 'new' else "✅"
            lines.append(
                f"{tag} {sig['ticker']:<6} | {sig['action']:<5} | "
                f"Level {sig['level']} | Win {win_pct}%"
            )
        lines.append("")
    else:
        lines = ["No signals triggered at this time.\n"]

    # ── Dropped signals (final alert only) ───────────────────
    if alert_type == 'final' and dropped_tickers:
        lines.append("DROPPED SINCE 3:30 PM (no longer triggered):")
        lines.append("-" * 40)
        for ticker in dropped_tickers:
            lines.append(f"❌ {ticker} — signal flipped, skip today")
        lines.append("")

    # ── Footer ────────────────────────────────────────────────
    footer = (
        "\nThis alert is based on your account filter settings.\n"
        "Log in to SimplyUpDown to see full signal details.\n"
        "https://www.simplyupdown.com\n\n"
        "To manage your alert preferences, visit your account page.\n"
        "— SimplyUpDown Team"
    )

    body = intro + "\n".join(lines) + footer
    return subject, body


def build_telegram_message(profile, triggered_signals, alert_type, cycle, dropped_tickers=None):
    """
    Build Telegram message — shorter than email, markdown friendly.
    Placeholder until bot token is set up.
    """
    now_ny = datetime.datetime.now(NY_TZ)
    date_str = now_ny.strftime("%b %d, %Y")

    if alert_type == 'watching':
        header = f"⚠️ *SimplyUpDown — {cycle} Watching*\n_{date_str} | 3:30 PM ET — Not final_\n\n"
    else:
        header = f"✅ *SimplyUpDown — {cycle} Final*\n_{date_str} | 3:55 PM ET — Act now_\n\n"

    lines = []
    for sig in triggered_signals:
        win_pct = round(sig['win_rate'] * 100)
        tag     = "🆕" if sig.get('status') == 'new' else "✅"
        lines.append(
            f"{tag} *{sig['ticker']}* | {sig['action']} | "
            f"Lv{sig['level']} | Win {win_pct}%"
        )

    if alert_type == 'final' and dropped_tickers:
        lines.append("\n*Dropped:*")
        for ticker in dropped_tickers:
            lines.append(f"❌ {ticker}")

    if not triggered_signals:
        lines.append("_No signals triggered._")

    return header + "\n".join(lines)


def build_sms_message(triggered_signals, alert_type, cycle):
    """
    SMS — ultra short, Twilio placeholder.
    """
    count = len(triggered_signals)
    if alert_type == 'watching':
        return f"SimplyUpDown ⚠️ {count} {cycle} signal(s) watching. Final alert at 3:55PM ET. Login to view."
    else:
        return f"SimplyUpDown ✅ {count} {cycle} signal(s) confirmed at 3:55PM ET. Login to act now."


# ─────────────────────────────────────────────────────────────
# SECTION 4 — Senders
# ─────────────────────────────────────────────────────────────

def send_email(profile, subject, body):
    """Send email via Brevo SMTP (configured in settings.py)."""
    recipient = profile.user.email
    if not recipient:
        logger.warning(f"No email for user {profile.user.username}, skipping.")
        return False, "No email address on account"

    try:
        send_mail(
            subject      = subject,
            message      = body,
            from_email   = settings.DEFAULT_FROM_EMAIL,
            recipient_list = [recipient],
            fail_silently  = False,
        )
        logger.info(f"Email sent to {recipient} — {subject}")
        return True, None

    except Exception as e:
        logger.error(f"Email failed for {recipient}: {e}")
        return False, str(e)


def send_telegram(profile, message):
    """
    Telegram sender — placeholder until bot token is configured.
    Logs what would be sent.
    """
    if not profile.telegram_chat_id:
        return False, "No telegram_chat_id on profile"

    # This pulls the token we just saved in your settings.py file
    token = getattr(settings, 'TELEGRAM_BOT_TOKEN', None)
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN is missing from settings.")
        return False, "Bot token not configured."



    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": profile.telegram_chat_id,
        "text": message,
        "parse_mode": "Markdown"
    }

    try:
        # This actually sends the message to Telegram
        resp = requests.post(url, json=payload, timeout=10)

        if resp.status_code == 200:
            logger.info(f"Message successfully sent to {profile.telegram_chat_id}")
            return True, None
        else:
            logger.warning(f"Failed to send Telegram message: {resp.text}")
            return False, resp.text

    except requests.exceptions.RequestException as e:
        logger.error(f"Network error while connecting to Telegram API: {e}")
        return False, str(e)



def send_sms(profile, message):
    """
    SMS sender — Twilio placeholder until account verified.
    Logs what would be sent.
    """
    if not profile.phone:
        return False, "No phone number on profile"

    # ── Placeholder ───────────────────────────────────────────
    # When ready, replace this block with:
    #
    # from twilio.rest import Client
    # client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    # msg = client.messages.create(
    #     body = message,
    #     from_ = settings.TWILIO_FROM_NUMBER,
    #     to    = profile.phone
    # )
    # return True, None

    logger.info(
        f"[SMS PLACEHOLDER] Would send to {profile.phone}:\n{message}"
    )
    return True, None


# ─────────────────────────────────────────────────────────────
# SECTION 5 — Alert Log
# ─────────────────────────────────────────────────────────────

def log_alert(user, cycle, alert_type, channel, signals, status, error=None):
    """Write one log entry per channel per member per alert."""
    payload = [
        {
            'ticker'  : s['ticker'],
            'action'  : s['action'],
            'cycle'   : s['cycle'],
            'level'   : s['level'],
            'win_rate': s['win_rate'],
            'status'  : s.get('status', 'triggered'),
        }
        for s in signals
    ]
    SignalAlertLog.objects.create(
        user            = user,
        cycle           = cycle,
        alert_type      = alert_type,
        channel         = channel,
        signals_payload = payload,
        status          = status,
        error_msg       = error or '',
    )


def get_watching_tickers(user, cycle):
    """
    Read the 3:30 PM watching log for this user today.
    Returns set of ticker strings — used by final alert to find dropped signals.
    """
    today = timezone.now().astimezone(NY_TZ).date()
    log   = SignalAlertLog.objects.filter(
        user       = user,
        cycle      = cycle,
        alert_type = 'watching',
        sent_at__date = today,
    ).order_by('-sent_at').first()

    if not log:
        return set()

    return {s['ticker'] for s in log.signals_payload}


# ─────────────────────────────────────────────────────────────
# SECTION 6 — Main Entry Point
# ─────────────────────────────────────────────────────────────

def deliver_signals(cycle, alert_type):
    """
    Main delivery function — called by management command.

    Steps:
        1. Check if today is a valid delivery day for this cycle
        2. Get all signals from SignalMonitor
        3. Bulk fetch live prices once
        4. Calculate triggered status
        5. Loop through eligible members
        6. Filter signals per member
        7. Build and send messages
        8. Log results
    """
    logger.info(f"=== deliver_signals START | cycle={cycle} | alert_type={alert_type} ===")

    now_ny = datetime.datetime.now(NY_TZ)

    # ── Step 1: Check valid delivery day ─────────────────────
    if not is_valid_delivery_day(cycle, now_ny):
        logger.info(f"Not a valid delivery day for {cycle}. Exiting.")
        return

    # ── Step 2 & 3: Get signals + prices ─────────────────────
    house_symbols  = get_house_symbols()
    all_signals_qs = SignalMonitor.objects.filter(cycle=cycle, status='Waiting')

    if not all_signals_qs.exists():
        logger.info(f"No signals found in SignalMonitor for cycle={cycle}. Exiting.")
        return

    price_cache  = build_price_cache(all_signals_qs)

    # ── Step 4: Calculate triggered status for all signals ────
    all_signals = get_triggered_signals(cycle, price_cache)

    # Only exit early for watching alert
    # For final alert, continue even if nothing triggered — members need dropped info
    triggered_all = [s for s in all_signals if s['is_triggered']]
    if not triggered_all and alert_type == 'watching':
        logger.info(f"No triggered signals for {cycle} watching alert. Exiting.")
        return

    # ── Step 5: Get eligible members ─────────────────────────


    # Replace the entire member query block with this:
    cycle_filter = {
        'Daily'  : {'profile__alert_cycle_daily'  : True},
        'Weekly' : {'profile__alert_cycle_weekly' : True},
        'Monthly': {'profile__alert_cycle_monthly': True},
    }

    members = User.objects.filter(
        profile__tier__in = ['PREM', 'PLAT'],
        **cycle_filter.get(cycle, {})
    ).filter(
        Q(profile__alert_email=True)    |
        Q(profile__alert_telegram=True) |
        Q(profile__alert_sms=True)
    ).select_related('profile')
    logger.info(f"Eligible members: {members.count()}")

    # ── Step 6 & 7: Per-member filter, build, send ────────────
    for user in members:
        profile = user.profile

        try:
            # Filter signals to what this member can see
            member_signals = get_member_signals(
                profile, all_signals, cycle, house_symbols
            )

            # Only triggered ones for this member
            member_triggered = [s for s in member_signals if s['is_triggered']]

            # For final alert — find dropped tickers vs 3:30 PM
            dropped_tickers = []
            if alert_type == 'final':
                watching_set    = get_watching_tickers(user, cycle)
                current_set     = {s['ticker'] for s in member_triggered}
                dropped_tickers = list(watching_set - current_set)

                # Tag new signals (not in watching alert)
                for sig in member_triggered:
                    sig['status'] = 'new' if sig['ticker'] not in watching_set else 'triggered'

            # Skip if nothing to send
            if not member_triggered and not dropped_tickers:
                logger.info(f"Nothing to send for {user.username} — skipping.")
                continue

            # ── Send email ────────────────────────────────────
            if profile.alert_email and user.email:
                subject, body = build_email_message(
                    profile, member_triggered, alert_type, cycle, dropped_tickers
                )
                success, error = send_email(profile, subject, body)
                log_alert(
                    user       = user,
                    cycle      = cycle,
                    alert_type = alert_type,
                    channel    = 'email',
                    signals    = member_triggered,
                    status     = 'sent' if success else 'failed',
                    error      = error,
                )

            # ── Send telegram ─────────────────────────────────
            if profile.alert_telegram and profile.telegram_chat_id:
                message = build_telegram_message(
                    profile, member_triggered, alert_type, cycle, dropped_tickers
                )
                success, error = send_telegram(profile, message)
                log_alert(
                    user       = user,
                    cycle      = cycle,
                    alert_type = alert_type,
                    channel    = 'telegram',
                    signals    = member_triggered,
                    status     = 'sent' if success else 'failed',
                    error      = error,
                )

            # ── Send SMS ──────────────────────────────────────
            if profile.alert_sms and profile.phone:
                message = build_sms_message(member_triggered, alert_type, cycle)
                success, error = send_sms(profile, message)
                log_alert(
                    user       = user,
                    cycle      = cycle,
                    alert_type = alert_type,
                    channel    = 'sms',
                    signals    = member_triggered,
                    status     = 'sent' if success else 'failed',
                    error      = error,
                )
                #============================================
                # discord need to be developped in future
            #if profile.alert_discord and profile.discord_webhook_url:
                # Build Discord message (Markdown is similar to Telegram)
               # message = build_discord_message(profile, member_triggered, alert_type, cycle, dropped_tickers)
                # send_discord(profile, message) ...

        except Exception as e:
            logger.error(f"Error processing member {user.username}: {e}")
            continue

    logger.info(f"=== deliver_signals DONE | cycle={cycle} | alert_type={alert_type} ===")


def is_valid_delivery_day(cycle, now_ny):
    """
    Check if today is a valid day to send alerts for this cycle.

    Daily   → any NYSE trading day
    Weekly  → Friday only
    Monthly → last trading day of the month only
    """
    import pandas_market_calendars as mcal

    nyse     = mcal.get_calendar('NYSE')
    today    = now_ny.date()
    schedule = nyse.schedule(start_date=today, end_date=today)

    # Not a trading day at all
    if schedule.empty:
        return False

    if cycle == 'Daily':
        return True

    elif cycle == 'Weekly':
        return today.weekday() == 4    # Friday = 4

    elif cycle == 'Monthly':
        # Check if today is the last trading day of the month
        last_day_of_month = (today.replace(day=1) + datetime.timedelta(days=32)).replace(day=1) \
                            - datetime.timedelta(days=1)
        month_schedule = nyse.schedule(
            start_date = today,
            end_date   = last_day_of_month
        )
        last_trading_day = month_schedule.index[-1].date()
        return today == last_trading_day

    return False
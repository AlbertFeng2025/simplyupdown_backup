"""
File   : account.py
Purpose: User account dashboard view.

Handles:
  GET  → render account page with all profile data
  POST → save any changes the user made to their profile
"""

import json
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from stocks.models import Profile, PaymentHistory, SysSymbolcandidate , SiteAnnouncement
from django.contrib.auth import get_user_model

from django.http import JsonResponse

import pytz

import requests
from django.conf import settings
import uuid

@login_required(login_url='/login/')
def account_view(request):
    """
    GET:  Show the account dashboard.
    POST: Save profile changes submitted from the form.

    @login_required means: if the user is NOT logged in,
    redirect them to /login/ automatically.
    No need to check request.user.is_authenticated manually.

    PYTHON LEARNING — decorators (@login_required):
        A decorator wraps a function with extra behaviour.
        @login_required adds an authentication check before
        account_view() runs. If not logged in → redirect to login.
    """

    # Fetch the most recent active announcement
    announcement = SiteAnnouncement.objects.filter(is_active=True).order_by('-created_at').first()
    profile = request.user.profile
    tier    = profile.tier

    # ── Expiry check — same logic as radar view ─────────────────
    # If their subscription_end date has passed AND they are not
    # in 'cancelling' state (which means they cancelled deliberately
    # but still have paid days left), drop them to FREE.
    # This prevents someone from saving PREM/PLAT settings after
    # their payment has lapsed.
    from django.utils import timezone as tz
    sub_end    = profile.subscription_end
    sub_status = profile.subscription_status or ''
    if tier in ['PREM', 'PLAT']:
        if sub_end and sub_end < tz.now().date() and sub_status != 'cancelling':
            tier = 'FREE'

    # ── DEBUG — log every request ───────────────────────────────
    with open('/home/chpfeng2000gmail/debug_account.txt', 'a') as dbg:
        msg = 'METHOD=' + request.method + ' tier=' + str(tier) + chr(10)
        dbg.write(msg)
    # ── END DEBUG ───────────────────────────────────────────────

    # ── GET — just render the page ──────────────────────────────
    if request.method == 'GET':
        payments = PaymentHistory.objects.filter(
            user = request.user
        ).order_by('-created_at')[:12]   # last 12 payments


        context = {
            'profile'             : profile,
            'payments'            : payments,
            'custom_tickers_json' : json.dumps(list(profile.custom_tickers or [])),
            'announcement'        : announcement,
        }
        return render(request, 'account_dashboard.html', context)

    # ── POST — save changes ──────────────────────────────────────
    # 1. See what 'action' the browser sent
   # ── POST — save changes ──────────────────────────────────────
    if request.method == 'POST':
        # 1. See what 'action' the browser sent
        action = request.POST.get('action')

        # 2. If the action is our new "immediate add" command:
        # ---------------------------------------------------------
        # ACTION: ADD TICKER IMMEDIATELY
        # ---------------------------------------------------------
        if action == 'add_ticker_immediate':
            if tier != 'PLAT':
                return JsonResponse({'status': 'error', 'message': 'Platinum required.'})

            symbol = request.POST.get('symbol', '').strip().upper()

            if symbol:
                try:
                    current_data = profile.custom_tickers

                    if not current_data:
                        current_list = []
                    elif isinstance(current_data, str):
                        current_list = json.loads(current_data)
                    else:
                        current_list = list(current_data)

                    if symbol not in current_list:
                        # 1. Add to Profile
                        current_list.append(symbol)
                        profile.custom_tickers = current_list
                        profile.save()

                        # 2. Add to Candidate Table (Issue 1 Fix)
                        # We use .exists() to explicitly check the public pool first
                        if not SysSymbolcandidate.objects.filter(symbol=symbol).exists():
                            SysSymbolcandidate.objects.create(
                                symbol=symbol,
                                company_name=''
                            )

                    return JsonResponse({'status': 'success'})
                except Exception as e:
                    return JsonResponse({'status': 'error', 'message': str(e)})
                # ---------------------------------------------------------
        # ACTION: REMOVE TICKER IMMEDIATELY (Issue 2 Fix)
        # ---------------------------------------------------------
        elif action == 'remove_ticker_immediate':
            if tier != 'PLAT':
                return JsonResponse({'status': 'error', 'message': 'Platinum required.'})

            symbol = request.POST.get('symbol', '').strip().upper()

            if symbol:
                try:
                    current_data = profile.custom_tickers

                    if not current_data:
                        current_list = []
                    elif isinstance(current_data, str):
                        current_list = json.loads(current_data)
                    else:
                        current_list = list(current_data)

                    # If the ticker is in the user's profile, remove it and save
                    if symbol in current_list:
                        current_list.remove(symbol)
                        profile.custom_tickers = current_list
                        profile.save()
                        # Note: We do NOT delete from SysSymbolcandidate because
                        # it is a public shared pool for all users!

                    return JsonResponse({'status': 'success'})
                except Exception as e:
                    return JsonResponse({'status': 'error', 'message': str(e)})
        # ---------------------------------------------------------
        # ACTION: REGENERATE API KEY
        # ---------------------------------------------------------
        elif action == 'regenerate_api_key':
            if tier != 'PLAT':
                # Safety check: only Platinum users can do this
                messages.error(request, 'Platinum tier is required for API access.')
                return redirect('account')

            profile.api_key = uuid.uuid4().hex
            profile.save()
            messages.success(request, 'Your API key has been regenerated.')
            return redirect('account')

        # ── Signal delivery toggles ───────────────────────────
        # Only save alert preferences if user is on a paid tier
        if tier in ['PREM', 'PLAT']:

            # --- NEW: Brevo Unblock Logic ---
            new_alert_email = 'alert_email' in request.POST

            # If they are turning alerts ON, tell Brevo to unblock them silently
            if new_alert_email and not profile.alert_email:
                try:
                    url = f"https://api.brevo.com/v3/smtp/blockedContacts/{request.user.email}"
                    headers = {
                        "accept": "application/json",
                        "api-key": settings.BREVO_API_KEY
                    }
                    # timeout=3 ensures the page won't hang if Brevo is down
                    requests.delete(url, headers=headers, timeout=3)
                except Exception:
                    pass # Silently continue if Brevo API fails

            profile.alert_email = new_alert_email
            # --------------------------------

            profile.alert_telegram = 'alert_telegram' in request.POST


            profile.alert_cycle_daily   = 'alert_cycle_daily'   in request.POST
            profile.alert_cycle_weekly  = 'alert_cycle_weekly'  in request.POST

            # Telegram Chat ID
            tg_id = request.POST.get('telegram_chat_id', '').strip()
            if tg_id:
                profile.telegram_chat_id = tg_id


            # Win rate — user enters 60 meaning 60% → store 0.60
            try:
                wr = float(request.POST.get('min_win_rate_filter', 60))
                wr = max(0, min(100, wr))          # clamp 50–95
                profile.min_win_rate_filter = round(wr / 100, 4)  # 60 → 0.60
            except (ValueError, TypeError):
                pass


            # EV filter — user enters 5 meaning 5% → store 0.05
            try:
                ev = float(request.POST.get('min_ev_filter', 5.0))
                ev = max(-10, min(500.0, ev))
                profile.min_ev_filter = round(ev / 100, 4)  # 5.0 → 0.05
            except (ValueError, TypeError):
                pass

            # Sharpe ratio
            try:
                sh = float(request.POST.get('min_sharpe_filter', 0.5))
                sh = max(-10, min(500, sh))    # clamp 0–5
                profile.min_sharpe_filter = sh
            except (ValueError, TypeError):
                pass

            # Risk-Reward ratio — raw value (no /100 scaling, like Sharpe)
            # User enters 1.5 meaning "winners are 1.5× losers" → store 1.5
            try:
                rr = float(request.POST.get('min_rr_filter', 1.0))
                rr = max(0, min(100, rr))     # clamp 0–100 (sensible range)
                profile.min_rr_filter = round(rr, 2)
            except (ValueError, TypeError):
                pass


            # Annual return — user enters 10 meaning 10% → store 0.10
            try:
                ar = float(request.POST.get('min_annual_return_filter', 10.0))
                ar = max(-10, min(500.0, ar))
                profile.min_annual_return_filter = round(ar / 100, 4)  # 10.0 → 0.10
            except (ValueError, TypeError):
                pass

            # Min sample count
            try:
                sc = int(request.POST.get('min_sample_count_filter', 20))
                sc = max(5, min(500, sc))      # clamp 5–500
                profile.min_sample_count_filter = sc
            except (ValueError, TypeError):
                pass

        # PLAT only features
        if tier == 'PLAT':
            profile.alert_sms          = 'alert_sms'   in request.POST
            profile.alert_api          = 'alert_api'   in request.POST
            profile.alert_cycle_monthly = 'alert_cycle_monthly' in request.POST

            # Custom ticker watchlist — Full Form Save Logic
            # Include house alerts toggle — PLAT only
            profile.include_house_alerts = 'include_house_alerts' in request.POST
            raw_tickers = request.POST.get('custom_tickers', '[]').strip()
            try:
                ticker_list = json.loads(raw_tickers)
                if isinstance(ticker_list, list):
                    cleaned = sorted([
                        str(t).strip().upper()[:10]
                        for t in ticker_list
                        if str(t).strip()
                    ])[:100]

                    profile.custom_tickers = cleaned

                    for symbol in cleaned:
                        SysSymbolcandidate.objects.get_or_create(
                            symbol=symbol,
                            defaults={'company_name': ''}
                        )
            except (json.JSONDecodeError, TypeError):
                pass

        # ── Profile info — available to all tiers ────────────

        # 1. Update Core User (auth_user table)
        new_email = request.POST.get('email', '').strip()
        user_changed = False

        if new_email and new_email != request.user.email:
            User = get_user_model()
            # Check if someone else is already using this email
            if User.objects.filter(email=new_email).exclude(pk=request.user.pk).exists():
                messages.error(request, "This email is already registered to another account.")
                return redirect('account')
            else:
                # Update both username and email fields on the AUTH user
                request.user.email = new_email
                request.user.username = new_email
                user_changed = True

        # 2. Update Profile Fields (Names, Address, Phone)
        # We grab these directly from POST and assign to the profile object
        # Save marketing preference (available to all users)
        profile.is_subscribed = 'is_subscribed' in request.POST

        profile.first_name   = request.POST.get('first_name',   profile.first_name   or '').strip() or None
        profile.last_name    = request.POST.get('last_name',    profile.last_name    or '').strip() or None
        profile.phone        = request.POST.get('phone',        profile.phone        or '').strip() or None
        #address
        profile.address_line = request.POST.get('address_line', profile.address_line or '').strip() or None
        profile.city         = request.POST.get('city',         profile.city         or '').strip() or None
        profile.postal_code  = request.POST.get('postal_code',  profile.postal_code  or '').strip() or None
        profile.country      = request.POST.get('country',      profile.country      or '').strip() or None

        # Timezone (with your existing validation)
        timezone = request.POST.get('timezone', '').strip()
        if timezone in pytz.all_timezones:
           profile.timezone = timezone

        # Save the auth_user table if email changed
        if user_changed:
            request.user.save()

        # Save the sys_UserProfile table
        profile.save()

        messages.success(request, 'Your settings have been saved.')
        return redirect('account')
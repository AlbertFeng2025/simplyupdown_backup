import random
from django.conf import settings
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
import requests

@login_required(login_url='/login/')
def change_email_view(request):
    # --- STEP 2: VERIFY THE 6-DIGIT CODE ---
    if request.method == 'POST' and 'verification_code' in request.POST:
        user_code = request.POST.get('verification_code').strip()
        session_code = request.session.get('email_change_code')
        pending_email = request.session.get('pending_new_email')

        # Check if code matches (comparing as strings to be safe)
        if not session_code or user_code != str(session_code):
            messages.error(request, "Invalid or expired verification code.")
            return render(request, 'change_email.html', {'step': 2, 'email': pending_email})

        # SUCCESS: Update the Auth User model
        User = get_user_model()
        user = request.user
        user.email = pending_email
        user.username = pending_email  # Syncing Login ID
        user.save()

        # Clean up session so the code can't be used again
        del request.session['email_change_code']
        del request.session['pending_new_email']

        messages.success(request, f"Email verified! Your new login ID is {pending_email}")
        return redirect('account')

    # --- STEP 1: REQUEST CHANGE & SEND EMAIL ---
    if request.method == 'POST':
        new_email = request.POST.get('new_email', '').strip().lower()
        confirm_email = request.POST.get('confirm_email', '').strip().lower()

        if new_email != confirm_email:
            messages.error(request, "The email addresses do not match.")
            return render(request, 'change_email.html', {'step': 1})

        # Security check: Ensure email isn't already taken
        User = get_user_model()
        if User.objects.filter(email=new_email).exclude(pk=request.user.pk).exists():
            messages.error(request, "This email is already registered to another account.")
            return render(request, 'change_email.html', {'step': 1})

        # Generate a random 6-digit code
        code = random.randint(100000, 999999)
        request.session['email_change_code'] = code
        request.session['pending_new_email'] = new_email

        # --- NEW BREVO API SECTION ---
        try:
            # 1. Define the Brevo API Endpoint
            url = "https://api.brevo.com/v3/smtp/email"
            #print(f"DEBUG: API Key used: {settings.BREVO_API_KEY[:10]}...")
            #print(f"DEBUG: Sender Email: {settings.DEFAULT_FROM_EMAIL}")

            # 2. Set up the Headers (Your Secret Key)
            headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "api-key": settings.BREVO_API_KEY  # This pulls from your .env file
            }

            # 3. Create the Email Package (The Payload)
            payload = {
                "sender": {"name": "SimplyUpDown", "email": settings.DEFAULT_FROM_EMAIL},
                "to": [{"email": new_email}],
                "subject": "Your SimplyUpDown Verification Code",
                "htmlContent": f"""
                    <html>
                    <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                        <h2 style="color: #333;">Verify Your New Email</h2>
                        <p>You requested to change your email address on SimplyUpDown.</p>
                        <div style="background: #f4f4f4; padding: 20px; text-align: center; border-radius: 10px;">
                            <span style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #007bff;">{code}</span>
                        </div>
                        <p>Enter this 6-digit code on the website to complete the change.</p>
                        <p style="color: #999; font-size: 12px;">If you didn't request this, please ignore this email.</p>
                    </body>
                    </html>
                """
            }

            # 4. Physically "Push" the email to Brevo
            response = requests.post(url, json=payload, headers=headers)
            #print(f"DEBUG: Brevo Status: {response.status_code}")
            #print(f"DEBUG: Brevo Body: {response.text}")

            # 5. Check if Brevo accepted it (Status 201 means "Created/Sent")
            if response.status_code == 201:
                # Move to Step 2 (The code entry screen)
                return render(request, 'change_email.html', {'step': 2, 'email': new_email})
            else:
                # If Brevo says "No", tell the user why (e.g. Invalid API Key)
                messages.error(request, f"Email Error: {response.text}")
                return render(request, 'change_email.html', {'step': 1})

        except Exception as e:
            # If the internet connection fails
            messages.error(request, f"Connection Error: {str(e)}")
            return render(request, 'change_email.html', {'step': 1})

    # Default GET request: Show the initial email entry form
    return render(request, 'change_email.html', {'step': 1})
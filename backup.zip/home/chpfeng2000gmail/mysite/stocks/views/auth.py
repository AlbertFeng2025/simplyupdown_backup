from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages

def signup_view(request):
    """Low-friction signup using only Email and Password"""
    if request.user.is_authenticated:
        return redirect('radar_daily')

    if request.method == 'POST':
        # 1. BOT CHECK: The Honeypot
        if request.POST.get('middle_name'):
            # If the hidden field is filled, it's a bot.
            # Redirect to home silently.
            return redirect('home')

        # 2. DATA RETRIEVAL
        email = request.POST.get('email')
        password = request.POST.get('password')

        # 3. VALIDATION
        if not email or not password:
            messages.error(request, "Please provide both email and password.")
            return render(request, 'signup.html')

        # Check if email is already in use
        if User.objects.filter(username=email).exists():
            messages.error(request, "An account with this email already exists.")
            return render(request, 'signup.html')
        #---------------------------------------------
        # the username=email in auth table. the username and email is used to log in and password recovery
        # then in auth table, first name, and last name is not used
        # Then in profile table, use first name, last name, and also an notification email address
        # _________________________________________

        try:
            # 4. CREATE USER (Username = Email)
            user = User.objects.create_user(
                username=email,
                email=email,
                password=password
            )
            user.save()

            # 5. INSTANT ACCESS
            login(request, user)
            messages.success(request, "Welcome to SimplyUpDown™!")
            return redirect('radar_daily')

        except Exception as e:
            messages.error(request, "Registration failed. Please try again.")
            return render(request, 'signup.html')

    return render(request, 'registration/signup.html')

def login_view(request):
    """Simple login for existing customers"""
    if request.user.is_authenticated:
        return redirect('radar_daily')

    if request.method == 'POST':
        email = request.POST.get('username') # From the 'username' field in login.html
        password = request.POST.get('password')

        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            return redirect('radar_daily')
        else:
            messages.error(request, "Invalid email or password.")

    return render(request, 'registration/login.html')

def logout_view(request):
    """Logs the user out and redirects to the landing page"""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home') # Ensure 'home' is the name of your landing page URL
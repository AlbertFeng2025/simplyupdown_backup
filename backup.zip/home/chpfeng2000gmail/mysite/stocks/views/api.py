"""
File   : stocks/views/api.py
Purpose: REST API endpoint for Platinum users.

Endpoint : GET /api/v1/signals/
Auth     : X-API-Key header
Filters  : User's own saved profile filters (same as radar page)
Rate     : 60 calls per hour per API key

Flow (mirrors radar_view exactly):
    1. Validate API key → find user → confirm PLAT tier
    2. Rate limit check (60/hour via Django cache)
    3. Build filter values from user's saved profile settings
    4. Query SignalMonitor for user's watchlist tickers only
    5. For each signal — fetch live price, calculate trigger status
    6. Return JSON

USAGE:
    curl -H "X-API-Key: YOUR_KEY" https://www.simplyupdown.com/api/v1/signals/
    curl -H "X-API-Key: YOUR_KEY" https://www.simplyupdown.com/api/v1/signals/?cycle=Daily
    curl -H "X-API-Key: YOUR_KEY" https://www.simplyupdown.com/api/v1/signals/?cycle=Weekly
    curl -H "X-API-Key: YOUR_KEY" https://www.simplyupdown.com/api/v1/signals/?cycle=Monthly
"""

import datetime
import pytz
from django.http       import JsonResponse
from django.core.cache import cache
from django.utils      import timezone
from django.conf       import settings

from stocks.models          import SignalMonitor, HouseTicker, Profile
from stocks.views.services  import MarketDataService

# ── Constants ────────────────────────────────────────────────────────────────
RATE_LIMIT_CALLS = 60          # max calls allowed
RATE_LIMIT_WINDOW = 3600       # per hour (seconds)
VALID_CYCLES = ['Daily', 'Weekly', 'Monthly']
NY_TZ = pytz.timezone('America/New_York')


# =============================================================================
# MAIN API ENDPOINT
# =============================================================================

def api_signals(request):
    """
    GET /api/v1/signals/

    Returns current signals for the Platinum user's custom watchlist,
    filtered by their saved profile settings, with live price and
    trigger status calculated at request time — identical to the radar page.
    """

    # ── Only allow GET ────────────────────────────────────────────
    if request.method != 'GET':
        return _error(405, 'METHOD_NOT_ALLOWED', 'Only GET requests are supported.')

    # ─────────────────────────────────────────────────────────────
    # STEP 1: Authenticate via API key
    # ─────────────────────────────────────────────────────────────
    # User sends their key in the request header:
    #   X-API-Key: abc123xyz...
    # Django exposes headers as HTTP_<NAME> in request.META

    api_key = request.META.get('HTTP_X_API_KEY', '').strip()

    if not api_key:
        return _error(401, 'MISSING_KEY',
                      'No API key provided. '
                      'Include your key in the X-API-Key request header.')

    # Look up the profile that owns this key
    try:
        profile = Profile.objects.select_related('user').get(api_key=api_key)
    except Profile.DoesNotExist:
        return _error(401, 'INVALID_KEY',
                      'API key not recognised. '
                      'Check your key in your account dashboard.')

    # ─────────────────────────────────────────────────────────────
    # STEP 2: Confirm Platinum tier + subscription not expired
    # ─────────────────────────────────────────────────────────────
    # Mirrors the exact same expiry check used in radar_view

    tier       = profile.tier
    sub_end    = profile.subscription_end
    sub_status = profile.subscription_status or ''

    if tier == 'PLAT':
        if sub_end and sub_end < timezone.now().date() and sub_status != 'cancelling':
            tier = 'FREE'   # subscription lapsed

    if tier != 'PLAT':
        return _error(403, 'NOT_PLATINUM',
                      'API access requires an active Platinum subscription. '
                      'Upgrade at www.simplyupdown.com/pricing/')

    # ─────────────────────────────────────────────────────────────
    # STEP 3: Rate limiting — 60 calls per hour per API key
    # ─────────────────────────────────────────────────────────────
    # We use Django's cache framework (no extra packages needed).
    # Cache key is unique per api_key so users don't share limits.
    #
    # How it works:
    #   First call  → cache sets count=1, expires in 3600s
    #   Each call   → count increments by 1
    #   At call 61  → return 429, tell user when window resets
    #   After 3600s → cache entry expires, count resets to 0

    rate_key   = f'api_rate:{api_key}'
    call_count = cache.get(rate_key, 0)

    if call_count >= RATE_LIMIT_CALLS:
        # Tell the user roughly when they can try again
        ttl = cache.ttl(rate_key) if hasattr(cache, 'ttl') else RATE_LIMIT_WINDOW
        return _error(429, 'RATE_LIMITED',
                      f'Limit is {RATE_LIMIT_CALLS} requests per hour. '
                      f'Try again in approximately {ttl} seconds.',
                      extra={'retry_after_seconds': ttl})

    # Increment counter — set with expiry on first call, add on subsequent
    if call_count == 0:
        cache.set(rate_key, 1, RATE_LIMIT_WINDOW)
    else:
        cache.incr(rate_key)

    # ─────────────────────────────────────────────────────────────
    # STEP 4: Parse and validate ?cycle= query param
    # ─────────────────────────────────────────────────────────────
    # User can call:
    #   /api/v1/signals/              → all three cycles
    #   /api/v1/signals/?cycle=Daily  → Daily only

    cycle_param = request.GET.get('cycle', 'all').strip().capitalize()

    if cycle_param == 'All':
        cycles_to_run = VALID_CYCLES
    elif cycle_param in VALID_CYCLES:
        cycles_to_run = [cycle_param]
    else:
        return _error(400, 'INVALID_CYCLE',
                      f'cycle must be one of: Daily, Weekly, Monthly, or omit for all. '
                      f'Got: {request.GET.get("cycle")}')

    # ─────────────────────────────────────────────────────────────
    # STEP 5: Build user's ticker list
    # ─────────────────────────────────────────────────────────────
    # API returns ONLY their custom watchlist tickers.
    # If include_house_alerts is True on their profile,
    # we also include house tickers — same as the radar page.

    house_symbols  = list(
        HouseTicker.objects.filter(is_active=True).values_list('symbol', flat=True)
    )
    custom_symbols = list(profile.custom_tickers or [])

    if profile.include_house_alerts:
        # User opted in to see house tickers alongside their own
        all_symbols = list(set(house_symbols + custom_symbols))
    else:
        # Only their personal watchlist
        all_symbols = custom_symbols

    if not all_symbols:
        return JsonResponse({
            'status'       : 'ok',
            'generated_at' : _now_str(),
            'message'      : 'Your watchlist is empty. '
                             'Add tickers in your account dashboard.',
            'count'        : 0,
            'signals'      : []
        })

    # ─────────────────────────────────────────────────────────────
    # STEP 6: Build filter values from user's saved profile
    # ─────────────────────────────────────────────────────────────
    # Mirrors radar_view STEP 2 exactly.
    # PLAT users have full control — no house floor applied.

    house_filters = settings.HOUSE_FILTERS.get('Daily', {})

    min_win_rate = _safe_float(profile.min_win_rate_filter, house_filters.get('min_win_rate', 0.60))
    min_ev       = _safe_float(profile.min_ev_filter,       house_filters.get('min_ev',       0.002))
    min_sharpe   = _safe_float(profile.min_sharpe_filter,   house_filters.get('min_sharpe',   0.0))
    min_samples  = _safe_int(  profile.min_sample_count_filter, house_filters.get('min_samples', 10))
    min_annual   = _safe_float(profile.min_annual_return_filter, -999.0)

    # ─────────────────────────────────────────────────────────────
    # STEP 7: Run per cycle and collect signals
    # ─────────────────────────────────────────────────────────────

    all_signals    = []
    signals_by_cycle = {}

    for cycle in cycles_to_run:

        # Use cycle-specific house filters for min_samples baseline
        cycle_house = settings.HOUSE_FILTERS.get(cycle, house_filters)

        # Query SignalMonitor — same filter logic as radar_view STEP 7
        signals = SignalMonitor.objects.filter(
            cycle          = cycle,
            status         = 'Waiting',
            ticker__in     = all_symbols,
            win_rate__gte  = min_win_rate,
            ev_pct__gte    = min_ev,
            sharpe_ratio__gte = min_sharpe,
            sample_count__gte = min_samples,
            annual_return__gte = min_annual,
        ).order_by('-level', 'ticker')



                # === BATCH OPTIMIZATION START ===
        cycle_results = []

        if not signals:
            signals_by_cycle[cycle] = 0
            continue

        # 1. Build ticker list + last_close dict for batch call
        ticker_list = [sig.ticker for sig in signals]
        last_closes_dict = {sig.ticker: sig.last_close_price for sig in signals}

        # 2. ONE single batch call (much faster)
        batch_data = MarketDataService.get_live_prices_batch(
            symbols=ticker_list,
            last_closes=last_closes_dict,
            force_refresh=True,      # API always wants fresh prices
            include_news=False       # Keep API fast and clean
        )

        # 3. Build results using batch data
        for sig in signals:
            ticker = sig.ticker

            # Get data from batch (fallback if something fails)
            live_price, update_time, is_from_cache, _ = batch_data.get(
                ticker,
                (float(sig.last_close_price), None, None, None)
            )

            # Trigger calculation (unchanged)
            current_digit = '1' if live_price > float(sig.last_close_price) else '0'
            is_triggered = (current_digit == sig.trigger_digit)
            price_change = live_price - float(sig.last_close_price)
            percent_change = (price_change / float(sig.last_close_price)) * 100

            # Source tag (unchanged)
            if ticker in house_symbols and ticker in custom_symbols:
                source = 'both'
            elif ticker in house_symbols:
                source = 'house'
            else:
                source = 'custom'

            cycle_results.append({
                'ticker' : ticker,
                'cycle' : cycle,
                'level' : sig.level,
                'run_direction' : sig.run_direction,
                'recommendation' : sig.recommendation,
                'win_rate' : round(float(sig.win_rate) * 100, 1),
                'win_rate_raw' : round(float(sig.win_rate), 4),
                'ev_pct' : round(float(sig.ev_pct or 0) * 100, 2),
                'sharpe_ratio' : round(float(sig.sharpe_ratio or 0), 4),
                'annual_return' : round(float(sig.annual_return or 0) * 100, 2),
                'sample_count' : sig.sample_count or 0,
                'last_close_price': round(float(sig.last_close_price), 4),
                'last_close_date' : sig.last_close_date.strftime('%Y-%m-%d') if sig.last_close_date else None,
                'live_price' : round(live_price, 4),
                'price_change' : round(price_change, 4),
                'percent_change' : round(percent_change, 4),
                'trigger_digit' : sig.trigger_digit,
                'current_digit' : current_digit,
                'status' : 'Triggered' if is_triggered else 'Waiting',
                'recent_outcome' : sig.recent_outcome or '',
                'source' : source,
            })
        # === BATCH OPTIMIZATION END ===

        signals_by_cycle[cycle] = len(cycle_results)
        all_signals.extend(cycle_results)

    # ─────────────────────────────────────────────────────────────
    # STEP 8: Build and return response
    # ─────────────────────────────────────────────────────────────

    return JsonResponse({
        'status'        : 'ok',
        'generated_at'  : _now_str(),
        'cycle_filter'  : cycle_param,
        'count'         : len(all_signals),
        'count_by_cycle': signals_by_cycle,
        'filters_applied': {
            'min_win_rate' : min_win_rate,
            'min_ev'       : min_ev,
            'min_sharpe'   : min_sharpe,
            'min_samples'  : min_samples,
            'min_annual'   : min_annual if min_annual > -999 else None,
        },
        'signals'       : all_signals,
    })


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def _error(http_status, code, message, extra=None):
    """Build a consistent error JSON response."""
    body = {
        'status' : 'error',
        'code'   : code,
        'message': message,
    }
    if extra:
        body.update(extra)
    return JsonResponse(body, status=http_status)


def _now_str():
    """Return current UTC time as ISO string."""
    return datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')


def _safe_float(value, default):
    """Return value as float or fall back to default."""
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _safe_int(value, default):
    """Return value as int or fall back to default."""
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default
from django.shortcuts import render

def home(request):
    # This just tells Django to look for home.html in your templates folder
    return render(request, 'home.html')
from django.http import HttpResponse



def maintenance_view(request, *args, **kwargs):
    return HttpResponse("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Maintenance Mode</title>
        </head>
        <body style="text-align:center; padding:100px; font-family:sans-serif; background-color:#f8f9fa;">
            <div style="max-width:600px; margin:auto; border:1px solid #dee2e6; padding:40px; border-radius:10px; background:#fff; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                <h1 style="color:#343a40;">Scheduled Maintenance</h1>
                <p style="color:#6c757d; font-size:1.1em; line-height:1.6;">
                    The site is currently down for maintenance.
                    We apologize for the inconvenience and ask that you please come back later.
                </p>
                <hr style="border:0; border-top:1px solid #eee; margin:20px 0;">
                <p style="color:#adb5bd; font-size:0.9em;">&copy; 2026 SimplyUpDown Team</p>
            </div>
        </body>
        </html>
    """, status=503)
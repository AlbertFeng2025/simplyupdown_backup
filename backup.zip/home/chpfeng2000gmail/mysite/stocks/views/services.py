import yfinance as yf
import pandas as pd
import pytz
from django.utils import timezone
from django.core.cache import cache
import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

class MarketDataService:
    # Class-level variable for New York Time
    NY_TZ = pytz.timezone('America/New_York')

    # Initialize the analyzer once as a class variable to save memory
    analyzer = SentimentIntensityAnalyzer()

    # 3-30-2026 notes
    # to improve and solve API limit, we developed three new defs , process batch history, batch real time and news only
    # thus the first two def may not in use.
    # just leave here for reference
    # if change data source, we need change those as well but may be not in use

    @staticmethod
    def get_historical_data(symbol, cycle='daily', start_date=None, end_date=None):
        ticker_obj = yf.Ticker(symbol)

        # 1. SET DEFAULTS (2 years of daily data)
        if not end_date:
            # Add 1 day because yfinance end parameter is EXCLUSIVE.
            #
            # PYTHON LEARNING — exclusive end dates:
            #   ticker.history(start='Jan 1', end='Jan 5')
            #   returns Jan 1, 2, 3, 4  — Jan 5 is NOT included
            #   This is called a "half-open interval" [start, end)
            #   It is the same convention as Python's range(0, 5) = 0,1,2,3,4
            #
            # Example without fix:
            #   today = March 16
            #   end   = March 16 → last bar returned = March 13 (Friday) ❌
            #
            # Example with fix:
            #   today    = March 16
            #   tomorrow = March 17
            #   end      = March 17 → last bar returned = March 16 ✅
            tomorrow = datetime.date.today() + datetime.timedelta(days=1)
            end_date = tomorrow.strftime('%Y-%m-%d')
        if not start_date:
            two_years_ago = datetime.date.today() - datetime.timedelta(days=730)
            start_date = two_years_ago.strftime('%Y-%m-%d')

        # 2. ALWAYS FETCH DAILY DATA ('1d')
        # We need the daily "building blocks" to accurately filter by date.
        df = ticker_obj.history(start=start_date, end=end_date, interval='1d')

        if df.empty:
            return None


        # 3. USE GLOBAL NY_TZ
        # This gets today's date in New York to determine if a bar is "finished"
        now_ny = datetime.datetime.now(MarketDataService.NY_TZ)
        today_ny = datetime.datetime.now(MarketDataService.NY_TZ).date()

        current_weekday = today_ny.weekday() # 0=Mon, 5=Sat, 6=Sun

        # Define the "Safe Close" time as 4:15 PM today
        safe_close_time = now_ny.replace(hour=16, minute=15, second=0, microsecond=0)

        # 4. UNIFIED LOGIC: REMOVE INCOMPLETE PERIODS
        if cycle.lower() == 'monthly':
            # Cut off at the 1st of this month
            cutoff = today_ny.replace(day=1)
            df = df[df.index.date < cutoff]

        elif cycle.lower() == 'weekly':
            # 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun
            if current_weekday < 5:  # It is Monday through Friday
                # Market is open/unfinished: Shield back to Monday
                monday_of_this_week = today_ny - datetime.timedelta(days=current_weekday)
                df = df[df.index.date < monday_of_this_week]
            else:
                # It is Saturday or Sunday: Market is closed.
                # Just remove "today" (if there's any weird weekend data)
                df = df[df.index.date < today_ny]

        else:
            # FOR DAILY: Check the clock!
            if now_ny < safe_close_time:
                # It is before 4:15 PM. The market is still open (or hasn't opened).
                # Today's bar is incomplete, so we remove it.
                df = df[df.index.date < today_ny]

            # If now_ny >= safe_close_time, we do NOTHING!
            # This perfectly preserves today's finished bar for your midnight scan.



        # 5. RESAMPLE BASED ON CYCLE
        if cycle.lower() == 'weekly':
            # Groups by week ending Friday. If Friday was a holiday,
            # use Thursday's REAL date as the row label (not Friday).
            weekly_close = df['Close'].resample('W-FRI').last().dropna()
            real_dates = df.index.to_series().resample('W-FRI').last()
            real_dates = real_dates.loc[weekly_close.index]
            df = pd.DataFrame({'Close': weekly_close.values}, index=pd.DatetimeIndex(real_dates.values))

        elif cycle.lower() == 'monthly':
            # Groups by Month End. If the last day was a weekend/holiday,
            # use the REAL last trading date as the row label.
            monthly_close = df['Close'].resample('ME').last().dropna()
            real_dates = df.index.to_series().resample('ME').last()
            real_dates = real_dates.loc[monthly_close.index]
            df = pd.DataFrame({'Close': monthly_close.values}, index=pd.DatetimeIndex(real_dates.values))

        else:
            # For 'daily', we just keep the Close column of the filtered data.
            df = df['Close'].to_frame()

        return df

    @staticmethod
    def get_candidate_tickers():
        """Pulls your stock list from the sys_SymbolCandidate database table."""
        from stocks.models import SysSymbolcandidate
        try:
            tickers = list(SysSymbolcandidate.objects.values_list('symbol', flat=True))
            return [str(t).strip().upper() for t in tickers if t]
        except:
            return ["QQQ", "SPY"] # Fallback if database is empty


    @staticmethod
    def get_live_price(symbol, last_close=None, force_refresh=False, include_news=False):
        """
        Fetches the live stock price for a given ticker symbol.

        Parameters:
            symbol        : the stock ticker e.g. "AAPL", "QQQ"
            last_close    : the last known close price from our database
                            used as a fallback if Yahoo Finance fails
            force_refresh : True  = skip cache, always fetch fresh from Yahoo
                                    (triggered by the Refresh button)
                            False = use cache if available
                                    (triggered by F5 or new visitor)

        Returns:
            Always returns exactly 3 values as a tuple:
                price         : float  — the stock price
                update_time   : datetime in New York timezone, or None if failed
                is_from_cache : True  = price came from cache (F5 / new visitor)
                                False = price just fetched fresh (Refresh button)
                                None  = fetch failed, fallback price was used
        """

        # ── Build the cache keys for this symbol ──────────────────────
        #
        # Django cache is a key-value store — like a Python dictionary
        # but stored in your MySQL table (my_cache_table).
        #
        # We store TWO things per symbol:
        #   p_key → the price itself         e.g. 227.50
        #   t_key → when we fetched it       e.g. 1741564800.0 (Unix timestamp)
        #
        # f"lp_{symbol}" is an f-string — it inserts the variable into the string
        # Example: if symbol = "AAPL"
        #   p_key = "lp_AAPL"
        #   t_key = "lt_AAPL"
        # If symbol = "QQQ":
        #   p_key = "lp_QQQ"
        #   t_key = "lt_QQQ"
        # This ensures each ticker has its own separate cache entry
        #print(f"DEBUG: symbol={symbol}, force_refresh={force_refresh}")
        p_key = f"lp_{symbol}"

        t_key = f"lt_{symbol}"

        # ── Step 1: Try to serve from cache ───────────────────────────
        #
        # We only check the cache if force_refresh is False.
        # force_refresh=True means the user clicked the Refresh button
        # and wants the newest price — so we skip the cache entirely.
        #
        # "not force_refresh" means:
        #   force_refresh=False → not False → True  → enter this block (use cache)
        #   force_refresh=True  → not True  → False → skip this block (bypass cache)
        if not force_refresh:

            # cache.get() looks up the key in my_cache_table
            # Returns the stored value if found and not expired
            # Returns None if the key doesn't exist or has expired (after 24hrs)
            cached_price = cache.get(p_key)
            cached_ts    = cache.get(t_key)

            # Only use cache if BOTH the price AND the timestamp are available
            # If either is None, we fall through to Step 2 and fetch fresh
            if cached_price is not None and cached_ts is not None:

                # cached_ts is stored as a Unix timestamp — a plain float number
                # representing "seconds since January 1, 1970 UTC"
                # Example: 1741564800.0 = March 9, 2026 at 11:00 PM UTC
                #
                # datetime.datetime.fromtimestamp() converts that float
                # back into a real datetime object
                # tz=pytz.UTC tells Python this datetime is in UTC timezone
                dt = datetime.datetime.fromtimestamp(cached_ts, tz=pytz.UTC)

                # .astimezone() converts UTC datetime → New York datetime
                # Example: 2026-03-09 23:00:00 UTC → 2026-03-09 18:00:00 ET
                # MarketDataService.NY_TZ is defined at the top of the class
                # as pytz.timezone('America/New_York')
                return float(cached_price), dt.astimezone(MarketDataService.NY_TZ), True, None
                #      ↑ the price          ↑ when it was fetched (NY time)  ↑ True = from cache

        # ── Step 2: Fetch fresh price from Yahoo Finance ──────────────
        #
        # We reach here in two situations:
        #   A) force_refresh=True  — Refresh button was clicked
        #   B) Cache was empty     — first visit of the day, or cache expired
        #
        # We wrap this in try/except because network calls can fail:
        #   - Yahoo Finance might be down
        #   - The ticker symbol might be invalid
        #   - The internet connection might time out
        # Without try/except, any error would crash the entire page
        try:
            ticker = yf.Ticker(symbol)

            # --- THE LIVE FIX: Redirect Yahoo to a fresh ledger ---

            if force_refresh:
                # Futures (e.g. CL=F, ES=F) don't support 1m interval
                # Use daily interval instead
                if symbol.endswith('=F'):
                    df = ticker.history(period="5d", interval="1d")
                else:
                    df = ticker.history(period="1d", interval="1m")

                if not df.empty:
                    price = df['Close'].iloc[-1]
                else:
                    price = ticker.fast_info.get('last_price')
            else:
                # Standard quick snapshot for normal loads
                price = ticker.fast_info.get('last_price')

            # --- Validation & Cache Update (Same as your current logic) ---
            if price is None or pd.isna(price):
                raise ValueError(f"No valid price returned for {symbol}")
            # 2. FETCH & ANALYZE NEWS (New Logic)
            # 2.1. Initialize with "Safe Defaults"
            vibe_data = {
                "score": 0.0,
                "headlines": ["No recent headlines found."],
                "status": "No Data",
                "last_updated": timezone.now().strftime("%H:%M:%S")
            }

            if include_news:
                try:
                    news_items = ticker.news[:5] # Get top 5 headlines
                    # DEBUG 1: See the raw data from Yahoo
                    #print(f"DEBUG RAW NEWS for {symbol}: {news_items[:1]}")

                    if news_items:
                        titles = []
                        for item in news_items:
                            # 1. Try the new nested 'content' structure
                            headline = item.get('content', {}).get('title')

                            # 2. Try the old flat structure if that failed
                            if not headline:
                                headline = item.get('title') or item.get('headline')

                            # 3. Only add if we actually found text
                            if headline:
                                titles.append(headline)
                        # DEBUG 2: See what headlines we actually extracted
                        #print(f"DEBUG TITLES for {symbol}: {titles}")
                        if titles:
                            full_text = " ".join(titles)
                            # Calculate Sentiment (-1.0 to 1.0)
                            vs = MarketDataService.analyzer.polarity_scores(full_text)
                            compound_score = vs['compound']

                            vibe_data = {
                                "score": round(compound_score, 2),
                                "headlines": titles,
                                "status": "Success",
                                "last_updated": timezone.now().strftime("%H:%M:%S")
                            }
                        else:
                            vibe_data["status"] = "No Headlines Found"

                except Exception as e:
                    # 1. This sends the REAL error to your PythonAnywhere logs
                    import traceback
                    #print(f"DEBUG NEWS ERROR for {symbol}: {traceback.format_exc()}")

                    # 2. This tells the UI to stop showing the error and use old data instead
                    vibe_data = None

            live_price = round(float(price), 2)
            now = timezone.now()

            cache.set(p_key, live_price, 86400)
            cache.set(t_key, now.timestamp(), 86400)

            return live_price, now.astimezone(MarketDataService.NY_TZ), False, vibe_data

        except Exception as e:
            print(f"ERROR get_live_price({symbol}): {e}")
            return float(last_close) if last_close else 0.0, None, None, None

    @staticmethod
    def get_historical_data_batch(symbols, cycle='daily', start_date=None, end_date=None):
        """
        Batch version of get_historical_data.
        One API call for many symbols instead of one per symbol.
        Returns: dict { 'AAPL': DataFrame, 'QQQ': DataFrame, ... }
        """
        if not symbols:
            return {}

        symbols = [str(s).strip().upper() for s in symbols if s]

        # Same default logic as single version
        if not end_date:
            tomorrow = datetime.date.today() + datetime.timedelta(days=1)
            end_date = tomorrow.strftime('%Y-%m-%d')
        if not start_date:
            two_years_ago = datetime.date.today() - datetime.timedelta(days=730)
            start_date = two_years_ago.strftime('%Y-%m-%d')

        # === ONE SINGLE BATCH DOWNLOAD ===
        df_multi = yf.download(
            tickers=symbols,
            start=start_date,
            end=end_date,
            interval='1d',
            auto_adjust=True,
            progress=False,
            threads=False
        )

        if df_multi.empty:
            return {sym: None for sym in symbols}

        # Handle both single and multi-ticker return formats from yfinance
        if len(symbols) == 1:
            data_dict = {symbols[0]: df_multi}
        else:
            data_dict = {sym: df_multi.xs(sym, level=1, axis=1) for sym in symbols}

        # Common cutoff logic (same as your original)
        now_ny = datetime.datetime.now(MarketDataService.NY_TZ)
        today_ny = now_ny.date()
        current_weekday = today_ny.weekday()
        safe_close_time = now_ny.replace(hour=16, minute=15, second=0, microsecond=0)

        result = {}
        for sym, df in data_dict.items():
            if df.empty or 'Close' not in df.columns:
                result[sym] = None
                continue

            # === Exact same filtering logic as single version ===
            if cycle.lower() == 'monthly':
                cutoff = today_ny.replace(day=1)
                df = df[df.index.date < cutoff]
            elif cycle.lower() == 'weekly':
                if current_weekday < 5:  # Mon-Fri
                    monday = today_ny - datetime.timedelta(days=current_weekday)
                    df = df[df.index.date < monday]
                else:
                    df = df[df.index.date < today_ny]
            else:  # daily
                if now_ny < safe_close_time:
                    df = df[df.index.date < today_ny]


            # === Same resampling (with REAL trading date as row label) ===

            if cycle.lower() == 'weekly':
                weekly_close = df['Close'].resample('W-FRI').last().dropna()
                real_dates = df.index.to_series().resample('W-FRI').last()
                real_dates = real_dates.loc[weekly_close.index]
                df = pd.DataFrame({'Close': weekly_close.values}, index=pd.DatetimeIndex(real_dates.values))
            elif cycle.lower() == 'monthly':
                monthly_close = df['Close'].resample('ME').last().dropna()
                real_dates = df.index.to_series().resample('ME').last()
                real_dates = real_dates.loc[monthly_close.index]
                df = pd.DataFrame({'Close': monthly_close.values}, index=pd.DatetimeIndex(real_dates.values))
            else:
                df = df['Close'].to_frame()

            result[sym] = df

        return result

    @staticmethod
    def get_live_prices_batch(symbols, last_closes=None, force_refresh=False, include_news=False):
        """
        Batch version of get_live_price.
        One main API call for many symbols.
        Returns: dict { 'AAPL': (price, update_time, is_from_cache, vibe_data), ... }
        """
        if not symbols:
            return {}

        symbols = [str(s).strip().upper() for s in symbols if s]
        last_closes = last_closes or {}

        results = {}
        still_need = []

        # 1. Serve from cache when possible (very fast)
        for sym in symbols:
            if not force_refresh:
                p_key = f"lp_{sym}"
                t_key = f"lt_{sym}"
                cached_price = cache.get(p_key)
                cached_ts = cache.get(t_key)
                if cached_price is not None and cached_ts is not None:
                    dt = datetime.datetime.fromtimestamp(cached_ts, tz=pytz.UTC)
                    results[sym] = (
                        float(cached_price),
                        dt.astimezone(MarketDataService.NY_TZ),
                        True,
                        None
                    )
                    continue
            still_need.append(sym)

        if not still_need:
            return results

        # 2. ONE BATCH FETCH for remaining symbols
        try:
            tickers_obj = yf.Tickers(" ".join(still_need))

            for sym in still_need:
                ticker = tickers_obj.tickers.get(sym)
                if ticker is None:
                    raise ValueError(f"Ticker not found")

                try:
                    # Same price fetching logic as your original
                    if force_refresh:
                        if sym.endswith('=F'):
                            df = ticker.history(period="5d", interval="1d")
                        else:
                            df = ticker.history(period="1d", interval="1m")
                        price = df['Close'].iloc[-1] if not df.empty else ticker.fast_info.get('last_price')
                    else:
                        price = ticker.fast_info.get('last_price')

                    if price is None or pd.isna(price):
                        raise ValueError("No valid price")

                    live_price = round(float(price), 2)
                    now = timezone.now()

                    # Update cache (same keys as single version)
                    cache.set(f"lp_{sym}", live_price, 86400)
                    cache.set(f"lt_{sym}", now.timestamp(), 86400)

                    # === NEWS HANDLING (identical to your original code) ===
                    vibe_data = None
                    if include_news:
                        vibe_data = {
                            "score": 0.0,
                            "headlines": ["No recent headlines found."],
                            "status": "No Data",
                            "last_updated": timezone.now().strftime("%H:%M:%S")
                        }
                        try:
                            news_items = ticker.news[:5]
                            if news_items:
                                titles = []
                                for item in news_items:
                                    headline = (item.get('content', {}).get('title') or
                                               item.get('title') or item.get('headline'))
                                    if headline:
                                        titles.append(headline)
                                if titles:
                                    full_text = " ".join(titles)
                                    vs = MarketDataService.analyzer.polarity_scores(full_text)
                                    vibe_data = {
                                        "score": round(vs['compound'], 2),
                                        "headlines": titles,
                                        "status": "Success",
                                        "last_updated": timezone.now().strftime("%H:%M:%S")
                                    }
                        except:
                            pass  # Fail gracefully for news

                    results[sym] = (live_price, now.astimezone(MarketDataService.NY_TZ), False, vibe_data)

                except Exception as e:
                    fallback = last_closes.get(sym)
                    results[sym] = (
                        float(fallback) if fallback is not None else 0.0,
                        None, None, None
                    )
                    print(f"ERROR in batch for {sym}: {e}")

        except Exception as big_e:
            print(f"CRITICAL batch live price failed: {big_e}")
            for sym in still_need:
                if sym not in results:
                    fallback = last_closes.get(sym)
                    results[sym] = (float(fallback) if fallback is not None else 0.0, None, None, None)

        return results

    @staticmethod
    def get_news_sentiment(symbol):
        """
        Fetch ONLY news + sentiment for one ticker.
        Use this when user clicks to view detailed news.
        """
        try:
            ticker = yf.Ticker(symbol)
            vibe_data = {
                "score": 0.0,
                "headlines": ["No recent headlines found."],
                "status": "No Data",
                "last_updated": timezone.now().strftime("%H:%M:%S")
            }

            news_items = ticker.news[:5]
            if news_items:
                titles = []
                for item in news_items:
                    headline = (item.get('content', {}).get('title') or
                               item.get('title') or item.get('headline'))
                    if headline:
                        titles.append(headline)
                if titles:
                    full_text = " ".join(titles)
                    vs = MarketDataService.analyzer.polarity_scores(full_text)
                    vibe_data = {
                        "score": round(vs['compound'], 2),
                        "headlines": titles,
                        "status": "Success",
                        "last_updated": timezone.now().strftime("%H:%M:%S")
                    }
            return vibe_data
        except Exception as e:
            print(f"News error for {symbol}: {e}")
            return None
"""
File   : performance_tracker.py
Purpose: The "Live Evidence" page view.

BUSINESS PURPOSE:
    This page convinces visitors to subscribe by showing REAL trade results
    from our signal system. Every number shown is calculated from actual
    archived trades — not simulated, not cherry-picked.

    What visitors see:
        1. Stats cards    — overall win rate, avg return, total trades
        2. Per-cycle stats — Daily / Weekly / Monthly breakdown
        3. Active trades  — signals currently open (live proof)
        4. Trade history  — last 90 days of settled results

MEMBERSHIP NOTE:
    Paid member logic is not yet implemented.
    is_paid is left as a placeholder — always False for now.
    Will be updated when membership tiers are activated.
"""

from django.utils import timezone
from django.shortcuts import render
from django.db.models import Avg, Count    # Avg = average, Count = count rows
from datetime import timedelta
from stocks.models import StrategyArchive
import math


# ══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def get_cycle_stats(queryset, cycle):
    """
    Calculates performance statistics for one specific cycle
    from a queryset of settled trades.

    PYTHON LEARNING — why a helper function?
        We need the same calculation for Daily, Weekly, and Monthly.
        Instead of writing the same code 3 times, we write it ONCE here
        and call it 3 times with different cycle values.
        This is the DRY principle: Don't Repeat Yourself.

    Args:
        queryset : Django QuerySet of settled StrategyArchive rows
        cycle    : 'Daily', 'Weekly', or 'Monthly'

    Returns:
        dict with these keys:
            total      : int   — total number of settled trades
            wins       : int   — number of winning trades
            losses     : int   — number of losing trades
            win_rate   : float — win percentage e.g. 72.5
            avg_return : float — average return across ALL trades e.g. 2.34
            avg_win    : float — average return on WIN trades only e.g. 5.80
            avg_loss   : float — average return on LOSE trades only e.g. -3.20
            has_data   : bool  — True if at least one trade exists
    """

    # Filter to just this cycle (Daily, Weekly, or Monthly)
    qs = queryset.filter(cycle=cycle)

    # Count total trades for this cycle
    total = qs.count()

    # If no trades exist for this cycle, return a safe "empty" dict
    # This prevents division by zero and avoids template errors
    if total == 0:
        return {
            'total'      : 0,
            'wins'       : 0,
            'losses'     : 0,
            'win_rate'   : 0,
            'avg_return' : 0,
            'avg_win'    : 0,
            'avg_loss'   : 0,
            'has_data'   : False,
        }

    # Count wins and losses
    wins   = qs.filter(is_win=True).count()
    losses = total - wins

    # Win rate as percentage
    # Example: 18 wins out of 28 trades → 18/28 × 100 = 64.3%
    win_rate = round(wins / total * 100, 1)

    # Average return across ALL trades (wins + losses combined)
    # This is the most honest single number — it includes losses
    # Django's Avg() is like Excel AVERAGE() on the profit_pct column
    # ['profit_pct__avg'] extracts the result from the dict Django returns
    # "or 0" handles the edge case where aggregate returns None
    avg_return = round(
        qs.aggregate(Avg('profit_pct'))['profit_pct__avg'] or 0,
        2
    )

    # Average return on WINNING trades only
    # Shows the typical upside when a signal works
    avg_win = round(
        qs.filter(is_win=True).aggregate(Avg('profit_pct'))['profit_pct__avg'] or 0,
        2
    )

    # Average return on LOSING trades only
    # Shows the typical downside when a signal fails
    # This will be a negative number e.g. -3.48
    avg_loss = round(
        qs.filter(is_win=False).aggregate(Avg('profit_pct'))['profit_pct__avg'] or 0,
        2
    )


    # ── CAGR calculation ──────────────────────────────────────────
    # profit_pct is stored as percentage: 2.11 means 2.11%
    # r = profit_pct / 100 for the formula
    #
    # IMPORTANT: trades_per_year is capped at the maximum possible
    # trades for each cycle — you cannot trade more days than exist.
    #   Daily   → max 252 per year (one per trading day)
    #   Weekly  → max 52  per year (one per week)
    #   Monthly → max 12  per year (one per month)
    #
    # Without this cap, having 5 Daily signals on one day would
    # inflate trades_per_year to 1,253 — mathematically wrong.

    ANNUAL_UNITS = {'Daily': 252, 'Weekly': 52, 'Monthly': 12}
    MAX_TRADES   = {'Daily': 252, 'Weekly': 52, 'Monthly': 12}

    annual_units = ANNUAL_UNITS.get(cycle, 252)
    max_trades   = MAX_TRADES.get(cycle, 252)

    if total >= 10 and avg_return is not None:

        # Raw trades per year — may exceed calendar maximum
        raw_trades_per_year = (total / 90) * annual_units

        # Cap at calendar maximum — cannot trade more than time allows
        trades_per_year = min(raw_trades_per_year, max_trades)

        # r = return per trade as decimal
        r = avg_return / 100   # 2.11% → 0.0211

        try:
            cagr_decimal = math.pow(1 + r, trades_per_year) - 1
            cagr_pct     = round(cagr_decimal * 100, 1)

            # Sanity cap — anything over 10,000% shows as None
            # Protects credibility if data is still thin
            if abs(cagr_pct) > 10000:
                cagr_pct = None

        except (ValueError, OverflowError):
            cagr_pct = None

    else:
        cagr_pct        = None
        trades_per_year = 0

    return {
        'total'          : total,
        'wins'           : wins,
        'losses'         : losses,
        'win_rate'       : win_rate,
        'avg_return'     : avg_return,
        'avg_win'        : avg_win,
        'avg_loss'       : avg_loss,
        'has_data'       : True,
        'cagr_pct'       : cagr_pct,
        'trades_per_year': round(trades_per_year, 1),
    }



# ══════════════════════════════════════════════════════════════════════════════
# MAIN VIEW
# ══════════════════════════════════════════════════════════════════════════════

def performance_tracker_view(request):
    """
    Builds the Live Evidence page context.

    Gathers:
        - Overall stats (all cycles combined, last 90 days)
        - Per-cycle stats (Daily / Weekly / Monthly separately)
        - Active trades (currently open — live proof)
        - Settled trade history (last 90 days — historical proof)

    PYTHON LEARNING — what is a 'view'?
        A Django view is a function that:
          1. Receives an HTTP request (someone visiting the page)
          2. Fetches data from the database
          3. Packages the data into a 'context' dictionary
          4. Returns an HTML response using a template + context

        The template (live_evidence.html) uses {{ variable_name }}
        to display the values from the context dictionary.
    """

    # ── STEP 1: Setup dates ───────────────────────────────────────────────────
    #
    # timezone.now() returns current UTC datetime, timezone-aware.
    # .date() strips the time → gives us just YYYY-MM-DD.
    # timedelta(days=90) subtracts 90 days from today.
    #
    # WHY 90 days?
    #   30 days was too short — Monthly trades hold for ~30 days then settle,
    #   so most Monthly evidence would fall outside a 30-day window.
    #   90 days captures ~3 full Monthly cycles and ~12 Weekly cycles.
    today           = timezone.now().date()
    ninety_days_ago = today - timedelta(days=90)

    # ── STEP 2: Settled trade history (last 90 days) ──────────────────────────
    #
    # .filter() = WHERE clause in SQL
    # status='SETTLED'              → only completed trades
    # exit_date__gte=ninety_days_ago → exit date >= 90 days ago
    #   (gte = greater than or equal to)
    # .order_by('-exit_date')       → newest first (- means descending)
    settled_history = StrategyArchive.objects.filter(
        status    = 'SETTLED',
        exit_date__gte = ninety_days_ago
    ).order_by('-exit_date')

    # ── STEP 3: Overall stats (all cycles combined) ───────────────────────────
    #
    # These go in the top "headline" stats cards on the page.
    # Combined across Daily + Weekly + Monthly — the big picture.
    total_trades = settled_history.count()
    total_wins   = settled_history.filter(is_win=True).count()

    # Overall win rate — all cycles together
    overall_win_rate = round(
        (total_wins / total_trades * 100) if total_trades > 0 else 0,
        1
    )

    # Overall average return — all cycles, wins AND losses
    # This is the most honest number — do not hide the losses
    overall_avg_return = round(
        settled_history.aggregate(Avg('profit_pct'))['profit_pct__avg'] or 0,
        2
    )

    # Overall average win (for display — shows typical upside)
    overall_avg_win = round(
        settled_history.filter(is_win=True).aggregate(
            Avg('profit_pct')
        )['profit_pct__avg'] or 0,
        2
    )

    # Overall average loss (for display — shows typical downside)
    overall_avg_loss = round(
        settled_history.filter(is_win=False).aggregate(
            Avg('profit_pct')
        )['profit_pct__avg'] or 0,
        2
    )

    # ── STEP 4: Per-cycle stats ───────────────────────────────────────────────
    #
    # Each cycle has its own win rate and return profile.
    # Combining them hides important differences:
    #   Daily might be 60% win rate
    #   Monthly might be 75% win rate
    #   Combined = 67% — less meaningful than showing both
    #
    # get_cycle_stats() is our helper function defined above.
    # We call it 3 times — once per cycle.
    stats_daily   = get_cycle_stats(settled_history, 'Daily')
    stats_weekly  = get_cycle_stats(settled_history, 'Weekly')
    stats_monthly = get_cycle_stats(settled_history, 'Monthly')
    # ── Overall CAGR (Daily only — most meaningful for headline card) ──
    # The headline card shows combined stats but CAGR only makes sense
    # per-cycle. We show Daily CAGR on the headline card because
    # Daily is the most frequent cycle and the most impressive.
    # Labeled clearly as "Daily CAGR" so visitor is not misled.
    overall_cagr = stats_daily.get('cagr_pct')

    # ── STEP 5: Active trades (currently open) ────────────────────────────────
    #
    # These are trades that have been CAPTURED but not yet SETTLED.
    # Showing these proves our system is LIVE and currently generating signals.
    # Visitors can see real tickers with real entry prices and dates.
    #
    # WHY separate queries per cycle?
    #   The template will show them in separate sections:
    #   "Daily Signals" / "Weekly Signals" / "Monthly Signals"
    #   This is clearer than one mixed list.
    active_daily   = StrategyArchive.objects.filter(
        status = 'ACTIVE',
        cycle  = 'Daily'
    ).order_by('-entry_date')

    active_weekly  = StrategyArchive.objects.filter(
        status = 'ACTIVE',
        cycle  = 'Weekly'
    ).order_by('-entry_date')

    active_monthly = StrategyArchive.objects.filter(
        status = 'ACTIVE',
        cycle  = 'Monthly'
    ).order_by('-entry_date')

    # ── STEP 6: Membership check ──────────────────────────────────────────────
    #
    # NOTE: Membership logic not yet implemented.
    # is_paid is always False for now — placeholder for future use.
    # Will use request.user.profile.tier ('PREM' or 'PLAT') when ready.
    is_paid_member = False

    # ── STEP 7: Package everything for the template ───────────────────────────
    #
    # PYTHON LEARNING — context dictionary:
    #   The context is a dictionary where:
    #     key   = variable name used in the HTML template {{ key }}
    #     value = the actual data to display
    #
    #   Example in template:
    #     {{ overall_win_rate }}   → shows e.g. "72.5"
    #     {{ stats_daily.wins }}   → shows e.g. "18"
    #     {{ total_trades }}       → shows e.g. "42"
    context = {

        # ── Settled trade history ─────────────────────────────────────────
        # Full list of completed trades — used in the history table
        'history'          : settled_history,

        # ── Overall headline stats ────────────────────────────────────────
        # These go in the top stats cards — the big persuasive numbers
        'total_trades'      : total_trades,         # e.g. 42
        'total_wins'        : total_wins,           # e.g. 30
        'overall_win_rate'  : overall_win_rate,     # e.g. 72.5  (%)
        'overall_avg_return': overall_avg_return,   # e.g. 2.34  (% per trade, all trades)
        'overall_avg_win'   : overall_avg_win,      # e.g. 5.80  (% on winning trades)
        'overall_avg_loss'  : overall_avg_loss,     # e.g. -3.20 (% on losing trades)

        # ── Per-cycle stats ───────────────────────────────────────────────
        # Each is a dict with: total, wins, losses, win_rate,
        #                      avg_return, avg_win, avg_loss, has_data
        # Access in template: {{ stats_daily.win_rate }}
        #                     {{ stats_weekly.total }}
        #                     {% if stats_monthly.has_data %}
        'stats_daily'       : stats_daily,
        'stats_weekly'      : stats_weekly,
        'stats_monthly'     : stats_monthly,

        # ── Active trades (currently open) ───────────────────────────────
        # Shows visitors the system is live and generating signals RIGHT NOW
        # Access in template: {% for trade in active_daily %}
        'active_daily'      : active_daily,
        'active_weekly'     : active_weekly,
        'active_monthly'    : active_monthly,

        # ── Membership ───────────────────────────────────────────────────
        # Placeholder — always False until membership is implemented
        'is_paid'           : is_paid_member,

        # ── Utility ──────────────────────────────────────────────────────
        'today'             : today,
        'last_updated'      : timezone.now(),
        'days_shown'        : 90,   # tells template "showing last 90 days"
        'overall_cagr'      : overall_cagr,   # Daily CAGR for headline card
    }

    return render(request, 'live_evidence.html', context)


# ══════════════════════════════════════════════════════════════════════════════
# HTML TEMPLATE VARIABLE REFERENCE
# ══════════════════════════════════════════════════════════════════════════════
#
# Use these variable names in live_evidence.html:
#
# ── HEADLINE STATS CARDS ─────────────────────────────────────────────────────
#
#   {{ total_trades }}          Total settled trades in last 90 days
#   {{ overall_win_rate }}      Win rate % e.g. 72.5
#   {{ overall_avg_return }}    Avg return % across all trades e.g. 2.34
#                               ← renamed from 'avg_profit' (old name was misleading)
#                               ← show as "Avg Return per Trade" in HTML
#   {{ overall_avg_win }}       Avg % on winning trades e.g. 5.80
#                               ← show as "Avg Win" in HTML
#   {{ overall_avg_loss }}      Avg % on losing trades e.g. -3.20
#                               ← show as "Avg Loss" in HTML
#
# ── PER-CYCLE STATS ──────────────────────────────────────────────────────────
#
#   {% if stats_daily.has_data %}
#       {{ stats_daily.total }}       Number of Daily trades
#       {{ stats_daily.wins }}        Number of wins
#       {{ stats_daily.losses }}      Number of losses
#       {{ stats_daily.win_rate }}    Win rate % e.g. 68.5
#       {{ stats_daily.avg_return }}  Avg return % e.g. 1.82
#       {{ stats_daily.avg_win }}     Avg win % e.g. 4.20
#       {{ stats_daily.avg_loss }}    Avg loss % e.g. -2.80
#   {% endif %}
#
#   Same pattern for stats_weekly and stats_monthly
#
# ── ACTIVE TRADES ────────────────────────────────────────────────────────────
#
#   {% for trade in active_daily %}
#       {{ trade.ticker }}            e.g. AAPL
#       {{ trade.recommendation }}    LONG or SHORT
#       {{ trade.entry_price }}       e.g. 182.50
#       {{ trade.entry_date }}        e.g. 2026-03-16
#       {{ trade.expected_exit_date}} e.g. 2026-03-20 (next Friday)
#       {{ trade.level }}             e.g. 2
#       {{ trade.run_direction }}     UpRun or DownRun
#       {{ trade.institutional_edge}} Trend Continuation or Market Pivot
#   {% endfor %}
#
#   Same pattern for active_weekly and active_monthly
#
# ── SETTLED HISTORY TABLE ────────────────────────────────────────────────────
#
#   {% for trade in history %}
#       {{ trade.ticker }}
#       {{ trade.cycle }}
#       {{ trade.recommendation }}
#       {{ trade.entry_date }}
#       {{ trade.entry_price }}
#       {{ trade.exit_date }}
#       {{ trade.exit_price }}
#       {{ trade.profit_pct }}        e.g. 3.45 or -2.10
#       {{ trade.is_win }}            True or False
#                                     Use: {% if trade.is_win %}WIN{% else %}LOSE{% endif %}
#   {% endfor %}
#
# ── IF YOU CHANGED FROM OLD NAMES ────────────────────────────────────────────
#
#   OLD NAME              → NEW NAME
#   avg_profit            → overall_avg_return
#   win_rate              → overall_win_rate
#   active_daily          → same ✅
#   active_weekly         → same ✅
#   (missing)             → active_monthly  (NEW — add to template)
#   (missing)             → stats_daily     (NEW — add to template)
#   (missing)             → stats_weekly    (NEW — add to template)
#   (missing)             → stats_monthly   (NEW — add to template)
#
# ══════════════════════════════════════════════════════════════════════════════
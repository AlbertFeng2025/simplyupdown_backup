import pandas_market_calendars as mcal
from django.utils import timezone
import pandas as pd
import datetime
import pytz

from .services import MarketDataService
from django.shortcuts import render, get_object_or_404
from stocks.models import SignalMonitor, HouseTicker
from django.conf import settings

from django.http import JsonResponse


def get_official_anchor_date(cycle='Daily'):
    nyse   = mcal.get_calendar('NYSE')
    now_ny = datetime.datetime.now(pytz.timezone('America/New_York'))
    cutoff = now_ny.replace(hour=16, minute=15, second=0)

    if cycle == 'Daily':
        schedule = nyse.schedule(
            start_date=now_ny - datetime.timedelta(days=7),
            end_date=now_ny
        )
        last_session = schedule.index[-1].date()
        if now_ny < cutoff and last_session == now_ny.date():
            return schedule.index[-2].date()
        return last_session

    elif cycle == 'Weekly':
        schedule = nyse.schedule(
            start_date=now_ny - datetime.timedelta(days=10),
            end_date=now_ny
        )
        fridays = [d for d in schedule.index if d.weekday() == 4]
        if not fridays:
            return schedule.index[-1].date()
        last_friday = fridays[-1].date()
        if now_ny.date().weekday() == 4 and now_ny < cutoff:
            fridays_before = [d for d in fridays if d.date() < now_ny.date()]
            if fridays_before:
                return fridays_before[-1].date()
        return last_friday

    elif cycle == 'Monthly':
        first_of_this_month = now_ny.date().replace(day=1)
        last_month_end      = first_of_this_month - datetime.timedelta(days=1)
        schedule = nyse.schedule(
            start_date=last_month_end - datetime.timedelta(days=10),
            end_date=last_month_end
        )
        return schedule.index[-1].date()

    return now_ny.date()


# ── House default filters from settings.py ───────────────────────────────────
# All values are TRUE decimals: win_rate=0.60, ev=0.002, sharpe=0.0, samples=10
HOUSE_FILTERS = settings.HOUSE_FILTERS


def radar_view(request, cycle='Daily'):
    """
    Main Radar View — tier aware.

    Filter priority (server side):
        1. URL params (?win_rate=0.5&ev=0.001...) — set by Apply Filter button
        2. Profile saved settings — used on first load
        3. House defaults — floor for FREE/VISITOR, floor for PREM

    Two separate button actions:
        🔄 Refresh Price  → ?refresh=1        — fetches live prices, keeps filters
        🔍 Apply Filter   → ?win_rate=X&...   — reloads with new server filters

    JS instant filters (no reload needed):
        Level dropdown, Triggered toggle, PLAT source toggle (All/House/My List)
    """

    should_refresh = request.GET.get('refresh') == '1'

    first_update_time   = None
    first_is_from_cache = None

    # ──────────────────────────────────────────────
    # STEP 1: Determine user tier
    # ──────────────────────────────────────────────

    if request.user.is_authenticated:
        profile      = request.user.profile
        tier         = profile.tier

        # ── Expiry check — close the subscription leak ──────────
        # If paid tier but subscription_end has passed AND they are
        # not in a 'cancelling' grace window, drop them to FREE.
        # 'cancelling' means they deliberately cancelled but still
        # have paid days remaining — they keep access until end date.
        if tier in ['PREM', 'PLAT']:
            from django.utils import timezone as tz
            sub_end    = profile.subscription_end
            sub_status = profile.subscription_status or ''
            if sub_end and sub_end < tz.now().date() and sub_status != 'cancelling':
                tier = 'FREE'

        blur_tickers = False
    else:
        profile      = None
        tier         = 'VISITOR'
        blur_tickers = True

    house_filters = HOUSE_FILTERS.get(cycle, HOUSE_FILTERS['Daily'])

    # ──────────────────────────────────────────────
    # STEP 2: Determine filter values
    # Priority: URL params → profile saved → house defaults
    # All values are TRUE decimals matching DB format
    # ──────────────────────────────────────────────

    def get_filter(param_name, profile_val, house_val, as_int=False):
        """Read filter: URL param first, then profile, then house default."""
        url_val = request.GET.get(param_name)
        if url_val is not None:
            try:
                return int(url_val) if as_int else float(url_val)
            except (ValueError, TypeError):
                pass
        if profile_val is not None:
            return profile_val
        return house_val

    if tier in ('VISITOR', 'FREE'):
        # House defaults only — cannot be changed
        min_win_rate = house_filters['min_win_rate']
        min_ev       = house_filters['min_ev']
        min_sharpe   = house_filters['min_sharpe']
        min_samples  = house_filters['min_samples']
        min_annual   = -999.0
        min_rr = 1.0

    elif tier == 'PREM':
        # URL params or profile, floored at house minimum
        min_win_rate = max(
            get_filter('win_rate', profile.min_win_rate_filter, house_filters['min_win_rate']),
            house_filters['min_win_rate']
        )
        min_ev = max(
            get_filter('ev', profile.min_ev_filter, house_filters['min_ev']),
            house_filters['min_ev']
        )
        min_sharpe = max(
            get_filter('sharpe', profile.min_sharpe_filter, house_filters['min_sharpe']),
            house_filters['min_sharpe']
        )
        min_samples = max(
            get_filter('samples', profile.min_sample_count_filter, house_filters['min_samples'], as_int=True),
            house_filters['min_samples']
        )
        min_annual = get_filter('annual', profile.min_annual_return_filter, -999.0)
        min_rr = max(
            get_filter('rr_val', getattr(profile, 'min_rr_filter', None), 1.0),
            1.0
        )

    else:  # PLAT — full control, no floor
        min_win_rate = get_filter('win_rate', profile.min_win_rate_filter, house_filters['min_win_rate'])
        min_ev       = get_filter('ev',       profile.min_ev_filter,       house_filters['min_ev'])
        min_sharpe   = get_filter('sharpe',   profile.min_sharpe_filter,   house_filters['min_sharpe'])
        min_samples  = get_filter('samples',  profile.min_sample_count_filter, house_filters['min_samples'], as_int=True)
        min_annual   = get_filter('annual',   profile.min_annual_return_filter, -999.0)
        min_rr = get_filter('rr_val', profile.min_rr_filter if hasattr(profile, 'min_rr_filter') else None, 1.0)

    # Were URL filter params present? (Apply Filter was clicked)
    filter_applied = any(
        request.GET.get(p) is not None
        for p in ['win_rate', 'ev', 'sharpe', 'samples', 'annual', 'rr_val']
    )

    # ──────────────────────────────────────────────
    # STEP 3: Build ticker lists per tier
    # ──────────────────────────────────────────────
    house_symbols = list(
        HouseTicker.objects.filter(is_active=True).values_list('symbol', flat=True)
    )

    custom_symbols  = []
    missing_tickers = []

    if tier == 'PLAT':
        custom_symbols = list(profile.custom_tickers or [])
        if custom_symbols:
            scanned = set(
                SignalMonitor.objects.filter(
                    ticker__in=custom_symbols,
                    cycle=cycle
                ).values_list('ticker', flat=True)
            )
            missing_tickers = [t for t in custom_symbols if t not in scanned]

    # ──────────────────────────────────────────────
    # STEP 4: Get official anchor date
    # ──────────────────────────────────────────────
    official_day = get_official_anchor_date(cycle=cycle)

    # ──────────────────────────────────────────────
    # STEP 5: Check DB date vs official date
    # ──────────────────────────────────────────────
    sample_sig = SignalMonitor.objects.filter(cycle=cycle).first()

    is_out_of_sync = False
    db_day         = None

    if sample_sig and sample_sig.last_close_date:
        db_day = sample_sig.last_close_date.date()
        if db_day < official_day:
            is_out_of_sync = True

    # ──────────────────────────────────────────────
    # STEP 6: Check if market is open
    # ──────────────────────────────────────────────
    ny_time  = timezone.now().astimezone(pytz.timezone('America/New_York'))
    schedule = mcal.get_calendar('NYSE').schedule(
        start_date=ny_time.date(),
        end_date=ny_time.date()
    )

    if schedule.empty:
        is_market_open = False
    else:
        market_open  = schedule.iloc[0]['market_open']
        market_close = schedule.iloc[0]['market_close']
        is_market_open = market_open <= ny_time <= market_close

    if cycle == 'Daily':
        is_locked = is_out_of_sync or (not is_market_open)
    else:
        is_locked = is_out_of_sync

    # ──────────────────────────────────────────────
    # STEP 7: Query SignalMonitor with server filters
    # ──────────────────────────────────────────────
    selected_level = request.GET.get('level', 'All')

    base_query = SignalMonitor.objects.filter(
        cycle=cycle,
        status='Waiting',
        win_rate__gte      = min_win_rate,
        ev_pct__gte        = min_ev,
        sharpe_ratio__gte  = min_sharpe,
        sample_count__gte  = min_samples,
        annual_return__gte = min_annual,
        win_loss_ratio__gte = min_rr,
    )

    # Ticker list filter by tier
    if tier in ('VISITOR', 'FREE', 'PREM'):
        base_query = base_query.filter(ticker__in=house_symbols)
    elif tier == 'PLAT':
        all_plat_symbols = list(set(house_symbols + custom_symbols))
        base_query = base_query.filter(ticker__in=all_plat_symbols)

    # Level filter (also available as JS instant filter on page)
    if selected_level != 'All':
        base_query = base_query.filter(level=selected_level)

    signals = base_query.order_by('-level', 'ticker')

    trigger_time_labels = {
        'Daily'  : '3:50 PM ET',
        'Weekly' : 'Friday Close',
        'Monthly': 'Month-End Close',
    }
    trigger_time_label = trigger_time_labels.get(cycle, '3:50 PM ET')



    # ──────────────────────────────────────────────
    # STEP 8: Build radar list — NOW USING BATCH (much faster!)
    # ──────────────────────────────────────────────
    radar_list = []

    # 1. Build the list of tickers we actually need (already filtered by tier)
    ticker_list = [sig.ticker for sig in signals]

    # 2. Build a dictionary of last_close prices for fallback (exactly like before)
    last_closes_dict = {sig.ticker: sig.last_close_price for sig in signals}

    # 3. ONE single batch call instead of one call per ticker
    #    include_news = True only when the user clicked the Refresh button
    batch_data = MarketDataService.get_live_prices_batch(
        symbols=ticker_list,
        last_closes=last_closes_dict,
        force_refresh=should_refresh,
        include_news=should_refresh   # ← fresh news only on Refresh
    )

    # 4. Now loop through the signals (almost identical to your old loop)
    for sig in signals:
        ticker = sig.ticker

        # Source tag for PLAT toggle (All/House/My List) — unchanged

        if tier == 'PLAT':
            # Create clean lists of just thelse:
            # For everyone else (Free/Prem), the source is always 'house'

            clean_house = [str(s).strip().upper() for s in house_symbols]
            clean_custom = [str(s).strip().upper() for s in custom_symbols]

            # Clean the current ticker name
            current_ticker = str(ticker).strip().upper()

            # Check if it exists in those clean lists
            is_in_house = current_ticker in clean_house
            is_in_custom = current_ticker in clean_custom

            if is_in_house and is_in_custom:
                list_source = 'both'
            elif is_in_house:
                list_source = 'house'
            else:
                list_source = 'custom'
        else:
            # For everyone else (Free/Prem), the source is always 'house'
            list_source = 'house'
        # ←←← THIS IS THE NEW PART ←←←
        # Pull the data from the batch instead of calling get_live_price again
        live_price, update_time, is_from_cache, vibe_data = batch_data.get(
            ticker,
            (float(sig.last_close_price), None, None, None)  # fallback if something goes wrong
        )

        # The rest of your original code stays 100% the same
        current_vibe_score = 0.0
        current_vibe_label = "Technical"
        current_vibe_reason = "No recent news context found."
        current_vibe_status = "Initializing"
        current_vibe_time = "--:--"

        if vibe_data:
            current_vibe_score = vibe_data['score']
            current_vibe_reason = " | ".join(vibe_data['headlines'])
            current_vibe_label = get_vibe_label(sig.recommendation, current_vibe_score)
            current_vibe_status = vibe_data['status']
            current_vibe_time = vibe_data['last_updated']
        else:
            if sig.ai_vibe_label:
                current_vibe_score = sig.ai_vibe_score
                current_vibe_reason = sig.ai_vibe_reason
                current_vibe_label = sig.ai_vibe_label
                current_vibe_status = "From History"
                current_vibe_time = "Previous"

        # Record the first ticker's timing (for the "Last fetched / Refreshed" label)
        if first_is_from_cache is None:
            first_is_from_cache = is_from_cache
        if first_update_time is None and update_time is not None:
            first_update_time = update_time

        # Everything below here is exactly your old code — no changes
        current_digit = "1" if live_price > float(sig.last_close_price) else "0"
        is_triggered = (current_digit == sig.trigger_digit)
        price_change = live_price - float(sig.last_close_price)
        percent_change = (price_change / float(sig.last_close_price)) * 100
        display_prob = f"{round(float(sig.win_rate) * 100)}%"
       # why text
        is_continuation = (
            (sig.recommendation == 'LONG' and sig.run_direction == 'UpRun') or
            (sig.recommendation == 'SHORT' and sig.run_direction == 'DownRun')
        )
        dna_type = "Trend Continuation" if is_continuation else "Market Pivot (Reversal)"
        bar_word = {'Daily': 'day', 'Weekly': 'week', 'Monthly': 'month'}
        bar = bar_word.get(cycle, 'bar')
        bar_plural = bar if sig.level == 1 else bar + 's'
        direction = 'UP' if sig.run_direction == 'UpRun' else 'DOWN'
        next_bar = {'Daily': 'next day', 'Weekly': 'next week', 'Monthly': 'next month'}.get(cycle, 'next bar')

        # Build the "action" phrase based on BOTH run direction and recommendation.
        # "also" only fits when the recommendation continues the existing run.
        if sig.recommendation == 'LONG':
            action = 'also closes UP' if is_continuation else 'reverses and closes UP'
        else:  # SHORT
            action = 'also closes DOWN' if is_continuation else 'reverses and closes DOWN'

        why_text = (
            f"{sig.ticker} has had {sig.level} consecutive {direction} "
            f"{bar_plural} in a row. "
            f"History shows a {display_prob} chance the {next_bar} {action}. "
            f"({dna_type})"
        )
        display_ticker = '████' if blur_tickers else ticker
        display_company = '████████' if blur_tickers else (sig.company_name if sig.company_name else ticker)

        radar_list.append({
            'signal_id' : sig.id,
            'ticker' : display_ticker,
            'ticker_real' : ticker,
            'company_name' : display_company,
            'level' : sig.level,
            'run_direction' : sig.run_direction,
            'last_close_date' : sig.last_close_date.strftime('%Y-%m-%d'),
            'last_close' : sig.last_close_price,
            'live_price' : round(live_price, 2),
            'price_change' : round(price_change, 2),
            'percent_change' : round(percent_change, 2),
            'trigger_digit' : sig.trigger_digit,
            'current_digit' : current_digit,
            'recommendation' : sig.recommendation,
            'win_rate' : display_prob,
            'win_rate_raw' : round(float(sig.win_rate), 4),
            'ev_pct' : round(float(sig.ev_pct or 0), 4),
            'sharpe_ratio' : round(float(sig.sharpe_ratio or 0), 4),
            'annual_return' : round(float(sig.annual_return or 0), 4),
            'sample_count' : sig.sample_count or 0,
            'win_loss_ratio': round(float(getattr(sig, 'win_loss_ratio', 0.0)), 4),
            'max_consec_losses': int(getattr(sig, 'max_consec_losses', 0)),
            'is_triggered' : is_triggered,
            'why_text' : why_text,
            'recent_pos_string': sig.recent_pos_string[-20:],
            'recent_outcome' : sig.recent_outcome,
            'missing_count' : sig.missing_count,
            'ai_score' : round(current_vibe_score * 5, 1),
            'ai_label' : current_vibe_label,
            'ai_headlines' : current_vibe_reason,
            'ai_status' : current_vibe_status,
            'ai_updated_at' : current_vibe_time,
            'vibe_color' : sig.vibe_color_class,
            'list_source' : list_source,
        })

    # ──────────────────────────────────────────────
    # STEP 9: Build display time label
    # ──────────────────────────────────────────────
    ny_tz = pytz.timezone('America/New_York')

    if first_update_time is None:
        display_time = timezone.now().astimezone(ny_tz)
        time_label   = "As of"
    elif first_is_from_cache is True:
        display_time = first_update_time
        time_label   = "Last fetched"
    elif first_is_from_cache is False:
        display_time = first_update_time
        time_label   = "Refreshed"
    else:
        display_time = timezone.now().astimezone(ny_tz)
        time_label   = "As of"

    # ──────────────────────────────────────────────
    # STEP 10: Build context for template
    # ──────────────────────────────────────────────
    context = {
        'radar_data'         : radar_list,
        'is_out_of_sync'     : is_out_of_sync,
        'is_market_open'     : is_market_open,
        'is_locked'          : is_locked,
        'official_day'       : official_day,
        'db_day'             : sample_sig.last_close_date.date() if sample_sig and sample_sig.last_close_date else "None",
        'last_updated'       : display_time,
        'time_label'         : time_label,
        'cycle'              : cycle,
        'selected_level'     : selected_level,
        'trigger_time_label' : trigger_time_label,

        # User/tier
        'user_tier'          : tier,
        'blur_tickers'       : blur_tickers,

        # Active filter values (true decimals) — pre-fill Apply Filter form
        'filter_win_rate'    : min_win_rate,
        'filter_ev'          : min_ev,
        'filter_sharpe'      : min_sharpe,
        'filter_annual'      : min_annual if min_annual > -999 else 0,
        'filter_samples'     : min_samples,

        # House floor values for PREM display
        'house_min_win_rate' : house_filters['min_win_rate'],
        'house_min_ev'       : house_filters['min_ev'],
        'house_min_sharpe'   : house_filters['min_sharpe'],
        'house_min_samples'  : house_filters['min_samples'],
        'filter_rr' : min_rr,

        # Was Apply Filter used this load?
        'filter_applied'     : filter_applied,

        # PLAT specific
        'missing_tickers'    : missing_tickers,
        'custom_symbols'     : custom_symbols,
        'house_symbols'      : house_symbols,
    }
    return render(request, 'radar_all_cycle.html', context)


def signal_detail_popup(request, signal_id):
    signal = get_object_or_404(SignalMonitor, id=signal_id)

    is_continuation = (
        (signal.recommendation == 'LONG'  and signal.run_direction == 'UpRun') or
        (signal.recommendation == 'SHORT' and signal.run_direction == 'DownRun')
    )

    if is_continuation:
        prob_label  = "Trend Continuation"
        target_type = "L"
    else:
        prob_label  = "Market Pivot (Reversal)"
        target_type = "s"

    context = {
        'signal'         : signal,
        'company_name'   : signal.company_name if signal.company_name else signal.ticker,
        'level'          : signal.level,
        'run_type'       : "Up Run" if signal.run_direction == 'UpRun' else "Down Run",
        'prob_label'     : prob_label,
        'display_prob'   : round(float(signal.win_rate) * 100, 1) if signal.win_rate else 0,
        'history_display': signal.recent_pos_string[-20:],
        'recent_outcome' : signal.recent_outcome,
        'target_type'    : target_type,
        'missing_count'  : signal.missing_count,
        'win_loss_ratio': round(float(getattr(signal, 'win_loss_ratio', 0.0)), 4),
        'max_consec_losses': int(getattr(signal, 'max_consec_losses', 0)),
    }
    return render(request, 'signal_detail_modal.html', context)


def get_market_timing():
    nyse = mcal.get_calendar('NYSE')
    now  = timezone.now()
    schedule = nyse.schedule(start_date=now, end_date=now)
    if schedule.empty:
        return "Market Closed", None
    market_close = schedule.iloc[0]['market_close']
    trigger_time = market_close - datetime.timedelta(minutes=10)
    return trigger_time.strftime('%H:%M'), trigger_time


def get_vibe_label(recommendation, score):
    if score == 0: return "Technical"
    s = score * 5
    if recommendation == 'LONG':
        if s >= 4:  return "Overheated"
        if s >= 1:  return "Supportive"
        if s <= -4: return "Panic"
        return "Mixed" if s < 0 else "Supportive"
    if recommendation == 'SHORT':
        if s <= -4: return "Oversold"
        if s <= -1: return "Confirming"
        if s >= 4:  return "Squeeze"
        return "Mixed" if s > 0 else "Confirming"
    return "Neutral"




def refresh_news_view(request, ticker):
    """Refresh news for one ticker only"""
    if not request.user.is_authenticated:
        return JsonResponse({'success': False, 'error': 'Please log in.'})

    ticker = ticker.upper().strip()

    try:
        vibe_data = MarketDataService.get_news_sentiment(ticker)

        if not vibe_data:
            return JsonResponse({
                'success': False,
                'error': 'No news data available.'
            })

        signal = SignalMonitor.objects.filter(ticker=ticker).first()
        recommendation = signal.recommendation if signal else 'LONG'

        vibe_label = get_vibe_label(recommendation, vibe_data['score'])

        return JsonResponse({
            'success': True,
            'score': round(vibe_data['score'] * 5, 1),
            'label': vibe_label,
            'headlines': " | ".join(vibe_data.get('headlines', ["No recent headlines"])),
            'status': vibe_data.get('status', 'Success'),
            'updated_at': vibe_data['last_updated']
        })

    except Exception as e:
        print(f"ERROR refresh_news_view({ticker}): {str(e)}")
        return JsonResponse({'success': False, 'error': 'Server error'})
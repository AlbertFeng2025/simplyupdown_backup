import json
import sys
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from stocks.models import Profile

BREVO_SECRET_TOKEN = "MySuperSecret123"

@csrf_exempt
def brevo_webhook(request):
    # 1. IMMEDIATE LOG: Did the request even arrive?
    print("\n--- [DEBUG] BREVO WEBHOOK TRIGGERED ---", flush=True)
    print(f"Method: {request.method}", flush=True)
    
    provided_token = request.GET.get('token')
    if provided_token != BREVO_SECRET_TOKEN:
        print(f"!!! [AUTH ERROR] Token mismatch: {provided_token}", flush=True)
        return HttpResponse("Unauthorized", status=401)

    if request.method == 'POST':
        try:
            # 2. CAPTURE RAW DATA: This tells us exactly what Brevo sent
            raw_data = request.body.decode('utf-8')
            print(f"RAW DATA RECEIVED: {raw_data}", flush=True)

            data = json.loads(raw_data)
            
            # Brevo Transactional webhooks often send a list [ {} ]
            events = data if isinstance(data, list) else [data]
            
            for item in events:
                event_type = item.get('event')
                email = item.get('email')
                
                print(f"Processing Event: '{event_type}' for Email: '{email}'", flush=True)

                if event_type in ['unsubscribe', 'unsubscribed']:
                    # 3. DB LOG: Try to find the user
                    profiles = Profile.objects.filter(user__email__iexact=email)
                    count = profiles.count()
                    
                    if count > 0:
                        updated = profiles.update(is_subscribed=False)
                        print(f"SUCCESS: Updated {updated} profile(s) for {email}", flush=True)
                    else:
                        print(f"WARNING: No Profile found in DB for email '{email}'", flush=True)

            return JsonResponse({"status": "received"}, status=200)

        except Exception as e:
            print(f"CRITICAL ERROR: {str(e)}", flush=True)
            return HttpResponse("Internal Error", status=500)

    return HttpResponse("OK", status=200)
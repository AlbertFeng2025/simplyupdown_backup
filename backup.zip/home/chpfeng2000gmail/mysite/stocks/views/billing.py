import stripe
from django.utils import timezone
from datetime import timedelta
from django.conf import settings
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from ..models import Profile, PaymentHistory

# Use the Secret Key from settings.py
stripe.api_key = settings.STRIPE_SECRET_KEY


@login_required
def create_portal_session(request):
    """Creates a Stripe Customer Portal session and redirects the user."""
    profile = request.user.profile

    # FIX: If they have never paid, they won't have an ID yet.
    # We must create a blank customer in Stripe 'on the fly' so the portal doesn't crash.
    if not profile.stripe_customer_id:
        customer = stripe.Customer.create(
            email=request.user.email,
            name=request.user.username,
        )
        profile.stripe_customer_id = customer.id
        profile.save()

    try:
        checkout_session = stripe.billing_portal.Session.create(
            customer=profile.stripe_customer_id,
            return_url=request.build_absolute_uri('/account/'),
        )
        return redirect(checkout_session.url)
    except Exception as e:
        print(f"Error creating portal: {e}")
        return redirect('account')


@login_required
def checkout_redirect(request, plan):
    """Redirects user to the Stripe Payment Link with their User ID tagged."""
    STRIPE_LINKS = {
        'premium': 'https://buy.stripe.com/test_dRm00kgfugQmePh87Z4gg00',
        'platinum': 'https://buy.stripe.com/test_28EcN61kAeIedLd5ZR4gg01'
    }

    target_url = STRIPE_LINKS.get(plan)
    if target_url:
        # Tagging the user ID so we know who they are when they finish paying
        return redirect(f"{target_url}?client_reference_id={request.user.id}")

    # FIX: Changed 'dashboard' to 'account' to match your urls.py
    return redirect('account')


@csrf_exempt
def stripe_webhook(request):
    """
    The 'Ear' of your server. It listens for messages from Stripe
    and updates your User Profile and Payment History in real-time.
    """
    payload = request.body
    sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')

    # Securely get your endpoint secret from settings.py
    endpoint_secret = getattr(settings, 'STRIPE_ENDPOINT_SECRET', '')

    try:
        # Verify that this message actually came from Stripe (Security check)
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
    except Exception as e:
        # If the signature is invalid, we reject the request immediately
        print(f"Webhook Signature Error: {e}")
        return HttpResponse(status=400)

    # -----------------------------------------------------------------
    # CASE 1: INITIAL PURCHASE (User just finished the Checkout page)
    # -----------------------------------------------------------------
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']

        # client_reference_id was passed in your checkout_redirect view
        user_id        = session['client_reference_id']
        stripe_cust_id = session['customer']

        # PRECISION LOGIC: Ask Stripe exactly what was in the 'cart'
        line_items = stripe.checkout.Session.list_line_items(session['id'], limit=1)
        price_id = line_items['data'][0]['price']['id']

        if user_id:
            try:
                user = User.objects.get(id=user_id)
                profile = user.profile

                # Save the Stripe Customer ID so we can use the Billing Portal later
                profile.stripe_customer_id = stripe_cust_id

                # Use your Price IDs from settings to determine the user's new tier
                if price_id == settings.STRIPE_PRICE_PLATINUM:
                    new_tier = 'PLAT'
                    history_plan = 'PLAT_MONTHLY'
                elif price_id == settings.STRIPE_PRICE_PREMIUM:
                    new_tier = 'PREM'
                    history_plan = 'PREM_MONTHLY'
                else:
                    print(f"Warning: Unknown price_id {price_id} — no tier update.")
                    return HttpResponse(status=200)

                # Update the database
                profile.tier = new_tier
                profile.subscription_status = 'active'

                # Set expiration for 30 days from today
                profile.subscription_end = timezone.now().date() + timedelta(days=30)
                profile.save()

                # Record the transaction in your PaymentHistory table
                PaymentHistory.objects.create(
                    user=user,
                    plan=history_plan,
                    amount=session['amount_total'] / 100, # Convert cents to dollars
                    status='succeeded',
                    provider='stripe',
                    provider_ref=session['id'],
                    period_start=timezone.now().date(),
                    period_end=profile.subscription_end,
                    notes=f"Initial purchase successful via checkout session."
                )
            except User.DoesNotExist:
                print(f"CRITICAL: User ID {user_id} not found during checkout completion.")

    # -----------------------------------------------------------------
    # CASE 2: CANCELLATION (Subscription was fully deleted/ended)
    # -----------------------------------------------------------------
    elif event['type'] == 'customer.subscription.deleted':
        subscription = event['data']['object']
        cust_id = subscription['customer']

        # Find the profile by Stripe ID and kick them back to the Free tier
        Profile.objects.filter(stripe_customer_id=cust_id).update(
            tier='FREE',
            subscription_status='inactive'
        )

    # -----------------------------------------------------------------
    # CASE 3: UPDATES (Downgrades, Upgrades, or "Pending Cancellation")
    # -----------------------------------------------------------------
    elif event['type'] == 'customer.subscription.updated':
        subscription = event['data']['object']
        cust_id = subscription['customer']

        # Get the current Price ID the user is on after the update
        new_price_id = subscription['items']['data'][0]['price']['id']

        try:
            profile = Profile.objects.get(stripe_customer_id=cust_id)

            # If user clicked 'Cancel' in your portal, they stay Premium until the end of the month.
            # Stripe sends 'cancel_at_period_end = True' in this case.
            # Stripe new API uses 'cancel_at' timestamp instead of cancel_at_period_end
            # We check BOTH to be safe across API versions
            is_cancelling = (
                subscription['cancel_at_period_end'] or
                subscription['cancel_at'] is not None
            )

            if is_cancelling:
                # Customer has cancelled but keeps access until cancel_at date
                profile.subscription_status = 'cancelling'

                # Also update subscription_end to match Stripe's cancel_at date
                # so our expiry check knows exactly when to drop them to FREE
                import datetime
                cancel_timestamp = subscription['cancel_at']
                profile.subscription_end = datetime.date.fromtimestamp(cancel_timestamp)

            else:
                # Customer switched plans (upgrade or downgrade)
                if new_price_id == settings.STRIPE_PRICE_PLATINUM:
                    profile.tier = 'PLAT'
                elif new_price_id == settings.STRIPE_PRICE_PREMIUM:
                    profile.tier = 'PREM'

                profile.subscription_status = 'active'

            profile.save()
        except Profile.DoesNotExist:
            print(f"Warning: Update received for unknown customer ID: {cust_id}")

    # Tell Stripe we received the message successfully
    return HttpResponse(status=200)
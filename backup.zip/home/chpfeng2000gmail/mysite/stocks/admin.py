from django.contrib import admin, messages
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import Profile, SysSymbolcandidate, SignalMonitor, UpDownHistPerf, StrategyArchive, HouseTicker, SiteAnnouncement
from django.utils.html import format_html
from django import forms
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.mail import send_mail

from django.utils import timezone
from datetime import timedelta

import csv
from django.http import HttpResponse

def export_as_csv_universal(modeladmin, request, queryset):
    meta = modeladmin.model._meta
    # Get all field names for this specific model
    field_names = [field.name for field in meta.fields]

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename={meta.model_name}.csv'
    writer = csv.writer(response)

    # Write header row
    writer.writerow(field_names)
    # Write data rows
    for obj in queryset:
        writer.writerow([getattr(obj, field) for field in field_names])

    return response

# This sets the text in the "Actions" dropdown
export_as_csv_universal.short_description = "Export Selected to CSV"


# --- EMAIL TOOLS ---
class SendEmailForm(forms.Form):
    subject = forms.CharField(widget=forms.TextInput(attrs={'style': 'width: 100%;'}))
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 10, 'style': 'width: 100%;'}))

@admin.action(description="Send custom notice to selected users")
def send_custom_notice(modeladmin, request, queryset):
    # If the user clicked "Send Emails Now" in the custom form
    if 'apply' in request.POST:
        form = SendEmailForm(request.POST)

        # Manually grab the IDs from the POST data
        selected_ids = request.POST.getlist('_selected_action')
        # Re-fetch the users based on those IDs
        users_to_email = queryset.model.objects.filter(id__in=selected_ids)

        if form.is_valid():
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            count = 0

            for user in users_to_email:
                if user.email and user.profile.alert_email: # Only email if they want alerts
                    # Note: We use fail_silently=False so we see any Brevo/SMTP errors
                    send_mail(
                        subject,
                        f"Hi {user.username},\n\n{message}",
                        'support@simplyupdown.com',
                        [user.email],
                        fail_silently=False
                    )
                    count += 1

            modeladmin.message_user(request, f"Successfully sent '{subject}' to {count} users.")
            return HttpResponseRedirect(request.get_full_path())

    # If it's the first time landing on the page (GET request)
    form = SendEmailForm()
    return render(request, 'admin/send_email_form.html', {
        'items': queryset,
        'form': form,
        'title': 'Compose Message',
        # Hardcode this name so it matches our HTML exactly
        'action_checkbox_name': '_selected_action'
    })
# --- USER PROFILE ---
class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False


class CustomUserAdmin(BaseUserAdmin):
    inlines = (ProfileInline,)
    actions = [send_custom_notice, 'make_staff', 'remove_staff', 'make_superuser', 'remove_superuser']

    readonly_fields = ('is_staff', 'is_superuser')



    # --- hide ---
    def get_actions(self, request):
        actions = super().get_actions(request)
        # If the logged-in user is NOT a superuser, hide the power-user actions
        if not request.user.is_superuser:
            sensitive_actions = ['make_staff', 'remove_staff', 'make_superuser', 'remove_superuser']
            for action_name in sensitive_actions:
                if action_name in actions:
                    del actions[action_name]
        return actions
    # ── Columns shown in the User list ──────────────────────
    list_display = (
        'username',
        'email',
        'get_tier',           # membership level  ← NEW
        'get_sub_status',     # active / inactive ← NEW
        'get_sub_end',        # expiry date       ← NEW
        'is_active',
        'date_joined',
        'is_staff',
        'is_superuser'
    )

    # ── Filter sidebar on the right ──────────────────────────
    list_filter = (
        'profile__tier',              # filter by FREE/PREM/PLAT
        'profile__subscription_status',
        'is_active',
        'is_staff',      # Added for easy filtering
        'is_superuser',  # Added for easy filtering
    )

    search_fields = ('username', 'email')

    # ── Custom column: Tier badge ────────────────────────────
    def get_tier(self, obj):
        tier = obj.profile.tier
        colors = {
            'FREE': ('#78788a', '#f0f0f0'),   # (text_color, bg_color)
            'PREM': ('#7a5c00', '#fff3cd'),   # gold-ish
            'PLAT': ('#5b3fa0', '#ede7f6'),   # purple-ish
        }
        labels = {'FREE': 'Free', 'PREM': 'Premium', 'PLAT': 'Platinum'}
        text_color, bg_color = colors.get(tier, ('#000', '#eee'))
        return format_html(
            '<span style="background:{}; color:{}; padding:2px 10px;'
            'border-radius:10px; font-size:11px; font-weight:700;">{}</span>',
            bg_color, text_color, labels.get(tier, tier)
        )
    get_tier.short_description = 'Tier'
    get_tier.admin_order_field = 'profile__tier'  # makes column sortable

    # ── Custom column: Subscription status ──────────────────
    def get_sub_status(self, obj):
        status = obj.profile.subscription_status or 'inactive'
        color = '#28a745' if status == 'active' else '#6c757d'
        return format_html(
            '<span style="color:{}; font-size:11px;">{}</span>',
            color, status.title()
        )
    get_sub_status.short_description = 'Status'
    get_sub_status.admin_order_field = 'profile__subscription_status'

    # ── Custom column: Expiry date ───────────────────────────
    def get_sub_end(self, obj):
        end = obj.profile.subscription_end
        return end.strftime('%Y-%m-%d') if end else '—'
    get_sub_end.short_description = 'Expires'
    get_sub_end.admin_order_field = 'profile__subscription_end'

    # ──  Safety Toggle Actions ───────────────────────────
    @admin.action(description="Grant Staff Status")
    def make_staff(self, request, queryset):
        queryset.update(is_staff=True)

    @admin.action(description="Revoke Staff Status")
    def remove_staff(self, request, queryset):
        queryset.update(is_staff=False)

    @admin.action(description="Grant Superuser Status")
    def make_superuser(self, request, queryset):
        queryset.update(is_superuser=True, is_staff=True)

    @admin.action(description="Revoke Superuser Status")
    def remove_superuser(self, request, queryset):
        queryset.update(is_superuser=False)


admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

# --- SIGNAL MONITOR (LIVE RADAR) ---
@admin.register(SignalMonitor)
class SignalMonitorAdmin(admin.ModelAdmin):
    list_display = ('ticker', 'cycle', 'level_badge', 'strategy_label', 'win_rate_display', 'status_pill', 'performance_snapshot')
    list_filter = ('cycle', 'status', 'level', 'recommendation')
    search_fields = ('ticker',)
    actions = [export_as_csv_universal]

    def performance_snapshot(self, obj):
        # 1. Get the value and ensure it's a float
        try:
            raw_ev = float(obj.ev_pct) if obj.ev_pct is not None else 0.0
        except (ValueError, TypeError):
            raw_ev = 0.0

        # 2. MANUALLY format the number into a string here
        # This bypasses the 'SafeString' conflict in format_html
        formatted_ev = "{:.2f}".format(raw_ev)

        # 3. Determine color
        color = "#28a745" if raw_ev > 0 else "#6c757d"

        # 4. Get the last 6 outcomes
        outcomes = str(obj.recent_outcome or "")[-6:]

        # 5. Pass the already-formatted string {} instead of using :.2f here
        return format_html(
            '<div style="font-size:10px; line-height:1.2;">'
            '<b>EV:</b> <span style="color:{};">{}</span><br>'
            '<b>Seq:</b> <span style="font-family:monospace;">{}</span>'
            '</div>',
            color,
            formatted_ev,
            outcomes
        )
    performance_snapshot.short_description = "Stats"
    performance_snapshot.short_description = "Stats"

    def level_badge(self, obj):
        colors = {2: '#6c757d', 3: '#17a2b8', 4: '#fd7e14', 5: '#dc3545'}
        return format_html('<span style="color: white; background-color: {}; padding: 2px 8px; border-radius: 4px; font-weight: bold;">L{}</span>', colors.get(obj.level, '#000'), obj.level)
    level_badge.short_description = "Lvl"

    def strategy_label(self, obj):
        color = "#28a745" if obj.recommendation == "LONG" else "#dc3545"
        return format_html('<b>{} <span style="color: {};">{}</span></b>', obj.run_direction, color, obj.recommendation)

    def win_rate_display(self, obj):
        val = obj.win_rate if obj.win_rate is not None else 0
        return f"{val * 100:.1f}%"
    win_rate_display.short_description = "Win %"

    def status_pill(self, obj):
        colors = {'Waiting': '#ffc107', 'Triggered': '#28a745', 'Failed': '#dc3545'}
        status = obj.status or 'Waiting'
        return format_html('<span style="background-color: {}; color: {}; padding: 3px 10px; border-radius: 12px; font-size: 10px; font-weight: bold;">{}</span>', colors.get(status, '#ddd'), 'black' if status == 'Waiting' else 'white', status.upper())

# --- OTHER TABLES ---
@admin.register(UpDownHistPerf)
class UpDownHistPerfAdmin(admin.ModelAdmin):
    list_display = ('ticker','run_direction', 'cycle', 'level', 'trade_direction', 'win_rate_pct', 'ev_pct', 'sharpe_ratio', 'sample_count')
    list_filter = ('ticker','cycle', 'level', 'trade_direction')
    search_fields =['=ticker']
    actions = [export_as_csv_universal]

    def win_rate_pct(self, obj):
        val = obj.win_rate or 0
        return f"{val * 100:.1f}%"
    win_rate_pct.short_description = "Win Rate"

@admin.register(StrategyArchive)
class StrategyArchiveAdmin(admin.ModelAdmin):
    list_display = ('ticker', 'entry_date', 'recommendation', 'profit_pct', 'is_win', 'status', 'record_created_at_ny')
    list_filter = ('status', 'is_win', 'recommendation')
    search_fields = ('ticker',)
    actions = [export_as_csv_universal]

@admin.register(SysSymbolcandidate)
class SysSymbolcandidateAdmin(admin.ModelAdmin):
    list_display = ('symbol', 'company_name', 'lastscanned')
    search_fields = ('symbol',)



@admin.register(HouseTicker)
class HouseTickerAdmin(admin.ModelAdmin):
    list_display  = ('symbol', 'company_name', 'is_active', 'added_date')
    list_filter   = ('is_active',)
    search_fields = ('symbol', 'company_name')
    ordering      = ('symbol',)
    # When you save in admin → model's save() auto-syncs to SysSymbolCandidate

@admin.action(description="Grant 1 Year Free Platinum")
def grant_free_platinum(modeladmin, request, queryset):
    # This runs on every profile you "check" in the list
    one_year_later = timezone.now().date() + timedelta(days=365)

    # Update all selected profiles at once
    queryset.update(
        tier='PLAT',
        subscription_status='active',
        subscription_end=one_year_later
    )

class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'tier', 'subscription_status', 'subscription_end']
    list_filter = ['tier', 'subscription_status']
    # Add our new action to the dropdown menu!
    actions = [grant_free_platinum]

# Register your Profile with the custom Admin class
admin.site.register(Profile, ProfileAdmin)

#site annocement
@admin.register(SiteAnnouncement)
class SiteAnnouncementAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'is_active', 'message')
    list_editable = ('is_active',) # Allows you to turn it on/off quickly from the list view
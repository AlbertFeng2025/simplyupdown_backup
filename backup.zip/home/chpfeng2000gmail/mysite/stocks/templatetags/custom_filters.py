from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    # If the previous step returned None, return None immediately
    if dictionary is None:
        return None
    # Use .get() safely; if key doesn't exist, it returns None
    return dictionary.get(key)

@register.filter
def multiply(value, arg):
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return 0
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from stocks.models import UpDownHistPerf
from stocks.views.services import MarketDataService
import utility_string_segment_and_group_casinoStyle as utility
import math

# sampe use: python manage.py run_hist_scan --tickers AAPL TSLA MSFT --cycle monthly --levels 1 2 3 4 5
"""
WARNING / DATA INTEGRITY NOTE:
This module uses an 'update_or_create' logic based on Ticker, Cycle, and Level.
If a ticker was previously a 'candidate' but has since been removed from the
candidate list, its historical performance data will persist in the
UpDownHistPerf table as 'obsolete' data.

To ensure the Radar only shows active candidates, users should occasionally
clear the table or filter by 'is_active' and 'last_scan_date'.
"""
class Command(BaseCommand):
    help = "Finalized Historical Scanner: Supports Level 1-5 across all Cycles."

    def add_arguments(self, parser):
        parser.add_argument('--tickers', nargs='+', type=str)
        # LEVEL LOGIC: Now defaults to include Level 1 for 'State-Change' monitoring
        parser.add_argument('--levels', nargs='+', type=int, default=[1, 2, 3, 4, 5])
        parser.add_argument('--cycle', type=str, default='daily')
        parser.add_argument('--start', type=str, help='Start date YYYY-MM-DD')
        parser.add_argument('--end', type=str, help='End date YYYY-MM-DD')

    def handle(self, *args, **options):
        # 1. PREPARATION
        tickers = options['tickers'] or MarketDataService.get_candidate_tickers()
        cycle_type = options['cycle'].lower()
        db_cycle_name = cycle_type.capitalize()

        # 2. DYNAMIC DATE RANGE (Enhanced for Monthly context)
        end = options.get('end') or str(timezone.now().date())
        start = options.get('start')
        if not start:
            # Monthly cycles need a deeper history (10 years) to find Level 5 patterns
            if cycle_type == 'monthly':
                days_to_subtract = 3650
            elif cycle_type == 'weekly':
                days_to_subtract = 1825
            else:
                days_to_subtract = 730
            start = str(timezone.now().date() - timedelta(days=days_to_subtract))



                # === BATCH OPTIMIZATION - Fetch all historical data in ONE call ===
        self.stdout.write(f"Fetching historical data for {len(tickers)} tickers (batch mode)...")

        # Get all data in one single Yahoo call
        historical_batch = MarketDataService.get_historical_data_batch(
            symbols=tickers,
            cycle=cycle_type,
            start_date=start,
            end_date=end
        )

        # Now process each ticker using the pre-fetched data
        for symbol in tickers:
            self.stdout.write(f"--- Analyzing {symbol} ---")

            df = historical_batch.get(symbol)

            if df is None or df.empty:
                self.stdout.write(self.style.WARNING(f"  → No data for {symbol}"))
                continue

            # 3. DNA ENCODING (Close vs Previous Close) — unchanged
            data_list = []
            closes = df['Close']
            total_rows = len(closes)

            # Week-End Safety
            if cycle_type == 'weekly':
                last_bar_date = df.index[-1].date()
                if last_bar_date >= (timezone.now().date() - timedelta(days=2)):
                    total_rows -= 1

            for i in range(1, total_rows):
                digit = "1" if float(closes.iloc[i]) > float(closes.iloc[i-1]) else "0"
                data_list.append({
                    'date': str(df.index[i].date()),
                    'price': round(float(closes.iloc[i]), 2),
                    'digit': digit
                })

            # 4. PATTERN SCANNING ENGINE — unchanged
            for lvl in options['levels']:
                for run_dir in ["UpRun", "DownRun"]:
                    for trade_dir in ["LONG", "SHORT"]:
                        stats = utility.calculate_metrics(
                            data_list, level=lvl, run_type=run_dir,
                            trade_type=trade_dir, cycle=cycle_type
                        )

                        if stats and stats.get('sample_count', 0) > 0:
                            target = self._make_pat(lvl, run_dir)
                            watch = self._make_pat(lvl - 1, run_dir)

                            try:
                                UpDownHistPerf.objects.update_or_create(
                                    ticker=symbol,
                                    level=lvl,
                                    run_direction=run_dir,
                                    trade_direction=trade_dir,
                                    cycle=db_cycle_name,
                                    defaults={
                                        'pos_string': "".join([d['digit'] for d in data_list]),
                                        'target_pattern': target,
                                        'watch_pattern': watch,
                                        'win_rate': stats.get('win_rate', 0),
                                        'ev_pct': stats.get('ev', 0),
                                        'avg_win_pct': stats.get('avg_win_pct', 0),
                                        'avg_lose_pct': stats.get('avg_lose_pct', 0),
                                        'win_loss_ratio': stats.get('win_loss_ratio', 0),
                                        'max_loss_pct': stats.get('max_loss_pct', 0),
                                        'max_consec_losses': stats.get('max_consec_losses', 0),
                                        'sample_count': stats['sample_count'],
                                        'sharpe_ratio': stats.get('sharpe_ratio', 0),
                                        'annual_compound_pct': stats.get('annual_compound_pct', 0),
                                        'trade_position_detail': self._sanitize_for_json(
                                            stats.get('trade_position_detail', [])
                                        ),
                                        'last_scan_date': timezone.now().date(),
                                        'is_active': True
                                    }
                                )
                            except Exception as e:
                                self.stdout.write(
                                    self.style.ERROR(f" [!] DB SAVE FAILED: {symbol} | level={lvl} | error={str(e)}")
                                )
                                continue

            self.stdout.write(self.style.SUCCESS(f"Finished {symbol}"))

    def _make_pat(self, length, run_dir):
        """
        LEARNING POINT: HELPER METHOD FOR PATTERN BUILDING
        A 'Fresh Start' pattern always begins with the OPPOSITE state.

        Example (UpRun, Level 1):
        1. char = '1'
        2. prefix = '0'
        3. result = '0' + ('1' * 1) = '01'

        Example (UpRun, Level 0 - for the 'Watch'):
        1. result = '0' + ('1' * 0) = '0'
        """
        char = "1" if run_dir == "UpRun" else "0"
        prefix = "0" if char == "1" else "1"
        return prefix + (char * length)

    def _sanitize_for_json(self, obj):
        """
        Recursively walk through any dict/list and replace
        values that are not JSON-serializable:
            float('nan')  → None
            float('inf')  → None
            numpy types   → Python native types
        MySQL JSON columns reject all of these.
        """


        if isinstance(obj, dict):
            return {k: self._sanitize_for_json(v) for k, v in obj.items()}

        elif isinstance(obj, list):
            return [self._sanitize_for_json(i) for i in obj]

        elif isinstance(obj, float):
            if math.isnan(obj) or math.isinf(obj):
                return None          # null in JSON — MySQL accepts this ✅
            return round(obj, 6)     # clean float

        # Handle numpy types if present
        elif type(obj).__module__ == 'numpy':
            import numpy as np
            if isinstance(obj, (np.integer,)):
                return int(obj)
            elif isinstance(obj, (np.floating,)):
                val = float(obj)
                return None if (math.isnan(val) or math.isinf(val)) else val
            elif isinstance(obj, np.ndarray):
                return self._sanitize_for_json(obj.tolist())

        return obj
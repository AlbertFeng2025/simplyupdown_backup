# ==============================================================================
# File: reconstruct_archive.py
# Purpose: Acts as a "Historical Auditor". It scans past market data to find
#          trades that WOULD have happened based on your proven strategies,
#          and safely records them into your StrategyArchive.
# ==============================================================================

import datetime
from django.core.management.base import BaseCommand
from stocks.models import UpDownHistPerf, StrategyArchive
from stocks.views.services import MarketDataService

from stocks.management.commands.archive_engine import (
    get_next_friday,
    get_next_month_end,
)

class Command(BaseCommand):
    # This help text appears if you run `python manage.py help reconstruct_archive`
    help = "Reconstructs StrategyArchive by simulating live capture/settle logic over history."

    # --------------------------------------------------------------------------
    # 1. THE FILTER THRESHOLDS (Your Strategy Rules)
    # We only want to reconstruct trades for high-quality setups. If a strategy
    # didn't meet these numbers during your 10-year scan, we ignore it here.
    # --------------------------------------------------------------------------
    # CYCLE_PARAMS now imported from settings.py — single source of truth
    # This ensures reconstruct_archive uses identical filters as archive_engine
    @property
    def CYCLE_PARAMS(self):
        from django.conf import settings
        return settings.HOUSE_FILTERS

    def add_arguments(self, parser):
        # This allows you to type `--start 2026-01-01` in your terminal
        parser.add_argument('--start', type=str, default="2026-01-01",
                            help='Date to start looking for trades (YYYY-MM-DD)')

    def handle(self, *args, **options):
        # This is the main function that runs when you execute the command.
        start_date = options['start']
        today_str = str(datetime.date.today())

        self.stdout.write(f"\n--- Initiating Historical Audit from {start_date} ---")

        # ----------------------------------------------------------------------
        # STEP 1: Identify "Tradable" Strategies from the History Table
        # We query UpDownHistPerf because it contains the 'DNA' (target_pattern)
        # of the strategies that proved to be profitable.
        # ----------------------------------------------------------------------

        # --- STEP 1: Filter strategies & get unique tickers ---
        all_candidates = UpDownHistPerf.objects.filter(is_active=True)
        valid_strategies = []
        unique_tickers = set()

        for cand in all_candidates:
            p = self.CYCLE_PARAMS.get(cand.cycle)
            if p and (cand.win_rate     >= p['min_win_rate'] and
                      cand.ev_pct       >= p['min_ev']        and
                      cand.sharpe_ratio >= p['min_sharpe']   and
                      cand.sample_count >= p['min_samples']  and
                      p['min_level'] <= cand.level <= p['max_level']):
                valid_strategies.append(cand)
                unique_tickers.add(cand.ticker)

        self.stdout.write(f"Fetching batch data for {len(unique_tickers)} tickers...")

        # --- STEP 2: ONE BATCH FETCH FOR EVERYTHING ---
        # This replaces the 500 individual API calls with 1 or 2 big ones.
        master_data = {}
        ticker_list = list(unique_tickers)

        # We fetch Daily, Weekly, and Monthly separately because the
        # service handles resampling differently for each.
        for cycle_type in ['Daily', 'Weekly', 'Monthly']:
            self.stdout.write(f"Downloading {cycle_type} batch...")
            batch = MarketDataService.get_historical_data_batch(
                ticker_list, cycle=cycle_type, start_date=start_date, end_date=today_str
            )
            master_data[cycle_type] = batch

        self.stdout.write(f"Auditing {len(valid_strategies)} qualified strategies...")
        total_skipped = 0

        # --- STEP 3: Loop through strategies using the PRE-LOADED data ---
        for strat in valid_strategies:
            # Look up the data we already downloaded in Step 2
            df = master_data.get(strat.cycle, {}).get(strat.ticker)

            if df is None or len(df) < (strat.level + 2):
                total_skipped += 1
                continue

            # ... [KEEP ALL THE 'STEP 3: Bar-by-Bar' LOGIC BELOW THIS POINT] ...

            run_desc = "price goes up" if strat.run_direction == 'UpRun' else "price goes down"
            win_rate_pct = float(strat.win_rate or 0) * 100
            ev_percentage = float(strat.ev_pct or 0) * 100
            rr_ratio = float(strat.win_loss_ratio or 0)
            sharpe = float(strat.sharpe_ratio or 0)

            entry_note = (
                f"{strat.ticker} in the past, if consecutive {run_desc} Level {strat.level} {strat.cycle}, "
                f"then next {strat.cycle} has {strat.trade_direction} win rate is {win_rate_pct:.2f}%, "
                f"ev is {ev_percentage:.2f}%, risk reward is {rr_ratio:.2f}, sharpe is {sharpe:.2f}."
            )

            # ------------------------------------------------------------------
            # STEP 3: The "Bar-by-Bar" Time Walk
            # We loop through the price history. 'i' represents the current bar.
            # ------------------------------------------------------------------
            for i in range(strat.level + 1, len(df)):

                # Build the binary string (e.g., "1001") for the bars leading up to 'i'
                window = []
                for j in range(i - strat.level, i + 1):
                    # .iloc accesses rows by their integer position (0, 1, 2...)
                    # If this bar closed higher than the previous bar, digit is "1". Else "0".
                    digit = "1" if float(df['Close'].iloc[j]) > float(df['Close'].iloc[j-1]) else "0"
                    window.append(digit)

                # Join the list into a single string
                current_pattern = "".join(window)

                # --------------------------------------------------------------
                # STEP 4: DID WE FIND A TRADE?
                # Check if the history at this date matches our winning 'target_pattern'
                # --------------------------------------------------------------
                if current_pattern == strat.target_pattern:
                    entry_price = float(df['Close'].iloc[i])
                    entry_date = df.index[i].date()

                    # Determine the "Institutional Edge" (Continuation vs Pivot)
                    is_cont = (
                        (strat.trade_direction == 'LONG' and strat.run_direction == 'UpRun') or
                        (strat.trade_direction == 'SHORT' and strat.run_direction == 'DownRun')
                    )
                    edge = "Trend Continuation" if is_cont else "Market Pivot"

                    # ----------------------------------------------------------
                    # STEP 5A: THE "IN-FLIGHT" CHECK (Active Trades)
                    # If 'i' is the very last row in our data, the trade is still
                    # running right now! It hasn't finished yet.
                    # ----------------------------------------------------------
                    if i == len(df) - 1:

                        # Calculate when we expect this trade to close
                        if strat.cycle == 'Daily':
                            expected_exit = entry_date + datetime.timedelta(days=1)
                        elif strat.cycle == 'Weekly':
                            # Math trick to find the next Friday
                            #days_ahead = (4 - entry_date.weekday()) % 7
                           # days_ahead = 7 if days_ahead == 0 else days_ahead
                            #expected_exit = entry_date + datetime.timedelta(days=days_ahead)
                            expected_exit = get_next_friday(entry_date)
                        else: # Monthly
                            # Math trick to find the last day of the current month
                           # next_month = entry_date.replace(day=28) + datetime.timedelta(days=4)
                            #expected_exit = next_month - datetime.timedelta(days=next_month.day)
                            expected_exit = get_next_month_end(entry_date)

                        # Save it to the database as an 'ACTIVE' trade
                        # get_or_create ensures we don't save duplicates if we run this twice
                        StrategyArchive.objects.get_or_create(
                            ticker=strat.ticker,
                            cycle=strat.cycle,
                            entry_date=entry_date,
                            defaults={
                                'institutional_edge': edge,
                                'run_direction': strat.run_direction,
                                'level': strat.level,
                                'recommendation': strat.trade_direction,
                                'entry_price': entry_price,
                                'status': 'ACTIVE',              # <--- Running trade
                                'expected_exit_date': expected_exit,
                                'notes': entry_note,
                                # These are blank because the trade isn't done
                                'exit_date': None,
                                'exit_price': None,
                                'profit_pct': None,
                                'is_win': None
                            }
                        )
                        self.stdout.write(f"  [RECONSTRUCTED ACTIVE] {strat.ticker} entered {entry_date}")

                    # ----------------------------------------------------------
                    # STEP 5B: THE HISTORICAL CHECK (Settled Trades)
                    # If it's not the last row, the trade finished in the past.
                    # ----------------------------------------------------------
                    else:
                        # Grab the price of the very next bar (Bar N+1)
                        exit_price = float(df['Close'].iloc[i+1])
                        exit_date = df.index[i+1].date()

                        # Calculate profit based on LONG or SHORT
                        if strat.trade_direction == "LONG":
                            diff = exit_price - entry_price
                        else:
                            diff = entry_price - exit_price

                        profit_pct = round((diff / entry_price) * 100, 2)

                        # Save it to the database as a 'SETTLED' trade
                        StrategyArchive.objects.get_or_create(
                            ticker=strat.ticker,
                            cycle=strat.cycle,
                            entry_date=entry_date,
                            defaults={
                                'institutional_edge': edge,
                                'run_direction': strat.run_direction,
                                'level': strat.level,
                                'recommendation': strat.trade_direction,
                                'entry_price': entry_price,
                                'exit_date': exit_date,
                                'exit_price': exit_price,
                                'status': 'SETTLED',            # <--- Finished trade
                                'profit_pct': profit_pct,
                                'is_win': profit_pct > 0,
                                'expected_exit_date': exit_date,
                                'notes': entry_note,
                            }
                        )
                        self.stdout.write(f"  [RECONSTRUCTED SETTLED] {strat.ticker} {strat.cycle} L{strat.level} on {entry_date}")

        self.stdout.write(self.style.SUCCESS("\n--- Reconstruction Complete ---"))
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from stocks.models import UpDownHistPerf
from stocks.views.services import MarketDataService
import utility_string_segment_and_group_casinoStyle as utility

class Command(BaseCommand):
    help = "Runs historical backtests to fill the UpDownHistPerf table."

    def add_arguments(self, parser):
        parser.add_argument('--tickers', nargs='+', type=str)
        parser.add_argument('--levels', nargs='+', type=int, default=[2, 3, 4, 5])
        parser.add_argument('--cycle', type=str, default='daily')
        # ADD THESE TWO NEW ARGUMENTS:
        parser.add_argument('--start', type=str, help='Start date YYYY-MM-DD')
        parser.add_argument('--end', type=str, help='End date YYYY-MM-DD')

    def handle(self, *args, **options):
        """
        The main entry point for the 'run_hist_scan' command.
        """
        # 1. IDENTIFY THE TICKERS TO PROCESShttps://www.pythonanywhere.com/user/chpfeng2000gmail/webapps/
        # Python's 'or' logic: If options['tickers'] has a value, use it.
        # If it's None or empty, call the database fetcher.
        tickers = options['tickers'] or MarketDataService.get_candidate_tickers()

        # 2. DEFINE THE TIME CYCLE
        # Example: 'daily' -> 'Daily' (for the database column)
        cycle_type = options['cycle']
        db_cycle_name = cycle_type.capitalize()

        # 3. SET DATE RANGE (Automatic if not provided)
        end = options.get('end')
        if not end:
            # If no end date is given, use today
            end = str(timezone.now().date())

        start = options.get('start')
        if not start:
            if cycle_type == 'monthly':
                days_to_subtract = 3650  # 10 years for Monthly
            elif cycle_type == 'weekly':
                days_to_subtract = 1825  # 5 years for Weekly
            else:
                days_to_subtract = 730   # 2 years for Daily

            calculated_start = timezone.now().date() - timedelta(days=days_to_subtract)
            start = str(calculated_start)

        self.stdout.write(f"Running {cycle_type} scan from {start} to {end}")

        for symbol in tickers:
            self.stdout.write(f"--- Scanning {symbol} ({db_cycle_name}) ---")

            # 3. FETCH HISTORICAL DATA
            # We use our 'Portable' service so we aren't locked into yfinance here
            df = MarketDataService.get_historical_data(symbol, cycle_type, start, end)

            # If the service returns None (e.g. ticker not found), skip to next symbol
            if df is None:
                self.stdout.write(self.style.WARNING(f"No data found for {symbol}"))
                continue

            # 4. DATA TRANSFORMATION: DATAFRAME -> LIST OF DICTIONARIES
            # We start the range at 1 so we can compare index [i] to [i-1] (yesterday)
            data_list = []
            closes = df['Close']
            total_rows = len(closes)

            if cycle_type == 'weekly':
                last_bar_date = df.index[-1].date()
                today_date = timezone.now().date()

                # If the last bar is from 'Today' or 'Yesterday' and it's a weekday,
                # we treat it as an unconfirmed 'Open Bar' and skip it.
                if last_bar_date >= (today_date - timedelta(days=2)) and today_date.weekday() < 5:
                    total_rows = len(closes) - 1  # This stops the loop 1 row early
                    self.stdout.write(f"  - {symbol}: Skipping open week bar.")

            for i in range(1, total_rows):
                prev_price = float(closes.iloc[i-1])
                curr_price = float(closes.iloc[i])

                # Digit is '1' if price went up, '0' if it went down or stayed flat
                digit = "1" if curr_price > prev_price else "0"

                data_list.append({
                    'date': str(df.index[i].date()),
                    'price': round(curr_price, 2),
                    'digit': digit
                })

            # 5. THE ANALYSIS ENGINE
            # We loop through every combination of Level, Direction, and Trade Type
            for lvl in options['levels']:
                for run_dir in ["UpRun", "DownRun"]:
                    for trade_dir in ["LONG", "SHORT"]:

                        # Call the 'Fresh Start' logic in your utility module
                        stats = utility.calculate_metrics(
                            data_list,
                            level=lvl,
                            run_type=run_dir,
                            trade_type=trade_dir
                        )

                        # Only save if we found at least one trade (sample_count > 0)
                        if stats and stats.get('sample_count', 0) > 0:

                            # CREATE THE PATTERNS:
                            # If Level is 2 and UpRun, target is '011', watch is '01'
                            target = self._make_pat(lvl, run_dir)
                            watch = self._make_pat(lvl - 1, run_dir)

                            # 6. DATABASE SYNC (Create or Update)
                            # This finds the specific row for this ticker/level combo
                            # and updates the statistics.
                            UpDownHistPerf.objects.update_or_create(
                                ticker=symbol,
                                level=lvl,
                                run_direction=run_dir,
                                trade_direction=trade_dir,
                                cycle=db_cycle_name,
                                defaults={
                                        'pos_string': "".join([d['digit'] for d in data_list]),
                                        'target_pattern': target,
                                        'watch_pattern': watch,
                                        'win_rate': stats['win_rate'],
                                        'ev_pct': stats.get('ev', 0),            # CHANGED: 'ev' instead of 'ev_pct'
                                        'avg_win_pct': stats.get('avg_win_pct', 0), # ADDED: now it will save
                                        'avg_lose_pct': stats.get('avg_lose_pct', 0), # ADDED: now it will save
                                        'sample_count': stats['sample_count'],
                                        'win_loss_ratio': stats.get('win_loss_ratio', 0),
                                        'max_loss_pct': stats.get('max_loss_pct', 0),
                                        'sharpe_ratio': stats.get('sharpe_ratio', 0),
                                        'annual_compound_pct': stats.get('annual_compound_pct', 0),
                                        'trade_position_detail': stats['trade_position_detail'],
                                        'last_scan_date': timezone.now().date(),
                                        'is_active': True
                                    }
                            )

            self.stdout.write(self.style.SUCCESS(f"Finished {symbol}"))
    def _make_pat(self, length, run_dir):
        """
        HELPER METHOD: Generates a binary pattern for a 'Fresh Start'.
        Example: length=2, run_dir='UpRun' -> '011'

        Python Concepts:
        - Conditional Assignment: Using 'if/else' on a single line.
        - String Multiplication: Using '*' to repeat characters.
        """

        # 1. Determine the 'Signal' character based on direction.
        # In Python, we can assign variables based on a condition in one line.
        char = "1" if run_dir == "UpRun" else "0"

        # 2. Determine the 'Prefix' (the opposite digit).
        # If the signal is 1, the prefix must be 0 (Fresh UpRun start).
        # If the signal is 0, the prefix must be 1 (Fresh DownRun start).
        prefix = "0" if char == "1" else "1"

        # 3. Build the pattern.
        # Python allows 'string multiplication'. "1" * 3 results in "111".
        # We add the single prefix digit to the repeated signal digits.
        full_pattern = prefix + (char * length)

        return full_pattern
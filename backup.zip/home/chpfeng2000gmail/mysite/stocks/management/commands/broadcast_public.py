# ==============================================================================
# stocks/management/commands/broadcast_public.py
# ==============================================================================
# PUBLIC SIGNAL BROADCASTER
# This is a Django Management Command.
# It broadcasts trading signals to Discord, Facebook, and X (Twitter).
#
# How it runs:
#   python manage.py broadcast_public --channel allchannel --cycle Daily --alert-type final
#
# Learning Note: No "if __name__ == '__main__'" needed because Django calls
# the handle() method automatically.
# ==============================================================================

# facebood may work but x need a payment account


import logging
import datetime
import pytz
import requests
from django.core.management.base import BaseCommand
from django.conf import settings
from stocks.models import SignalMonitor, HouseTicker
from stocks.views.services import MarketDataService

logger = logging.getLogger(__name__)
NY_TZ = pytz.timezone('America/New_York')


class Command(BaseCommand):
    help = 'Broadcast triggered public signals to Discord, Facebook & X'

    def add_arguments(self, parser):
        """
        Define the command-line arguments.
        These allow you to control where and what to broadcast.
        """
        parser.add_argument(
            '--channel',
            type=str,
            default='allchannel',
            choices=['allchannel', 'discord', 'facebook', 'x'],
            help='Target channel: allchannel, discord, facebook, or x'
        )

        parser.add_argument(
            '--cycle',
            type=str,
            default='Daily',
            choices=['allcycle', 'Daily', 'Weekly', 'Monthly'],
            help='Which cycle to broadcast: Daily, Weekly, Monthly, or allcycle'
        )

        parser.add_argument(
            '--alert-type',
            type=str,
            default='watching',
            choices=['watching', 'final'],
            help='watching = 3:30 PM teaser | final = 3:55 PM final alert'
        )

    def handle(self, *args, **options):
        """
        Main entry point of the command.
        Django automatically calls this method.
        """
        channel_arg = options['channel']
        cycle_arg = options['cycle']
        alert_type = options['alert_type']

        now_ny = datetime.datetime.now(NY_TZ)
        weekday = now_ny.weekday()   # Monday=0, ..., Friday=4, Sunday=6

        # ====================== FRIDAY ONLY LOGIC ======================
        # Since PythonAnywhere only allows daily scheduling, we add this check.
        # The task can run every day, but the code will exit early if not Friday.
        if weekday != 4:   # 4 = Friday
            self.stdout.write(self.style.WARNING(
                f"[{now_ny.date()}] Today is not Friday (weekday={weekday}). Broadcast skipped."
            ))
            return
        # ================================================================

        self.stdout.write(self.style.NOTICE(
            f"=== Starting Broadcast | Date: {now_ny.date()} | Channel: {channel_arg} | "
            f"Cycle: {cycle_arg} | Type: {alert_type} ==="
        ))

        # If user chooses 'allcycle', run all three cycles
        cycles_to_run = ['Daily', 'Weekly', 'Monthly'] if cycle_arg == 'allcycle' else [cycle_arg]

        for cycle in cycles_to_run:
            self.process_cycle(cycle, alert_type, channel_arg)

        self.stdout.write(self.style.SUCCESS("=== Broadcast Process Completed ==="))

    def process_cycle(self, cycle, alert_type, channel_arg):
        """Process one specific cycle (Daily / Weekly / Monthly)"""
        now_ny = datetime.datetime.now(NY_TZ)

        # Step 1: Check if today is valid trading day for this cycle
        if not self.is_valid_delivery_day(cycle, now_ny):
            self.stdout.write(f"Skipping {cycle}: Not a valid delivery day.")
            return

        # Step 2: Get active House Tickers
        house_symbols = list(HouseTicker.objects.filter(is_active=True).values_list('symbol', flat=True))
        if not house_symbols:
            self.stdout.write("No active house symbols found.")
            return

        # Step 3: Get waiting signals
        signals = SignalMonitor.objects.filter(
            cycle=cycle,
            status='Waiting',
            ticker__in=house_symbols
        )

        if not signals.exists():
            self.stdout.write(f"No waiting signals found for {cycle} cycle.")
            return

        # Step 4: Apply filters + check which ones are triggered
        triggered_signals = self.get_triggered_house_signals(signals, cycle)
        if not triggered_signals:
            self.stdout.write(f"No signals triggered after filters for {cycle}.")
            return

        # Step 5: Send to selected channels
        if channel_arg in ['allchannel', 'discord']:
            self.broadcast_to_discord(triggered_signals, cycle, alert_type)

        if channel_arg in ['allchannel', 'facebook']:
            self.broadcast_to_facebook(triggered_signals, cycle, alert_type)

        if channel_arg in ['allchannel', 'x']:
            self.broadcast_to_x(triggered_signals, cycle, alert_type)

    # ====================== CORE LOGIC ======================
    def get_triggered_house_signals(self, signals, cycle):
        """Apply House Filters and check live price trigger"""
        house_filters = settings.HOUSE_FILTERS.get(cycle, settings.HOUSE_FILTERS['Daily'])
        triggered_list = []

        for sig in signals:
            # Apply quality filters first (save API calls)
            if float(sig.win_rate or 0) < house_filters['min_win_rate']:
                continue
            if float(sig.ev_pct or 0) < house_filters['min_ev']:
                continue
            if float(sig.sharpe_ratio or 0) < house_filters['min_sharpe']:
                continue
            if (sig.sample_count or 0) < house_filters['min_samples']:
                continue

            # Get current live price
            try:
                live_price, _, _, _ = MarketDataService.get_live_price(
                    sig.ticker, sig.last_close_price, force_refresh=True, include_news=False
                )
            except Exception as e:
                logger.warning(f"Price fetch failed for {sig.ticker}: {e}")
                live_price = float(sig.last_close_price)

            # Check trigger condition (1 = price went up, 0 = price went down)
            current_digit = "1" if live_price > float(sig.last_close_price) else "0"

            if current_digit == sig.trigger_digit:
                triggered_list.append({
                    'ticker': sig.ticker,
                    'action': sig.recommendation,
                    'level': sig.level,
                    'win_rate': float(sig.win_rate),
                    'price': live_price
                })

        return triggered_list

    # ====================== BROADCAST FUNCTIONS ======================
def broadcast_to_x(self, signals, cycle, alert_type):
        """Send to X (Twitter) - Safe version when keys are missing or fake"""

        # === Safety Check: Skip if keys are not properly set ===
        required_keys = [
            settings.X_CONSUMER_KEY,
            settings.X_CONSUMER_SECRET,
            settings.X_ACCESS_TOKEN,
            settings.X_ACCESS_TOKEN_SECRET
        ]

        if any(key is None or key == "" or key.startswith("paste_") or len(key) < 10 for key in required_keys):
            self.stdout.write(self.style.WARNING(
                "⚠️  X (Twitter) keys are missing or placeholder. Skipping X broadcast."
            ))
            return

        # If keys look okay, try to post
        try:
            import tweepy
        except ImportError:
            self.stdout.write(self.style.ERROR("tweepy not installed. Run: pip install tweepy"))
            return

        try:
            client = tweepy.Client(
                consumer_key=settings.X_CONSUMER_KEY,
                consumer_secret=settings.X_CONSUMER_SECRET,
                access_token=settings.X_ACCESS_TOKEN,
                access_token_secret=settings.X_ACCESS_TOKEN_SECRET,
            )

            date_str = datetime.datetime.now(NY_TZ).strftime("%b %d")
            title = f"{cycle} {'Watching' if alert_type == 'watching' else 'Final'} Signals - {date_str}"

            message = f"{title}\n\n"
            for sig in signals[:4]:   # Limit to avoid too long message
                emoji = "🟢" if sig['action'].upper() == "LONG" else "🔴"
                line = f"{emoji} ${sig['ticker']} {sig['action']} | {int(sig['win_rate']*100)}%\n"
                message += line

            message += "\nPlatinum alerts → www.simplyupdown.com"

            # Safety truncate
            if len(message) > 280:
                message = message[:257].rstrip() + "...\nPlatinum → www.simplyupdown.com"

            client.create_tweet(text=message)
            self.stdout.write(self.style.SUCCESS(f"✅ X posted successfully"))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f"X (Twitter) failed: {e}"))
            logger.error(f"X broadcast error: {e}")
import datetime
import math
from django.utils import timezone
from django.core.management.base import BaseCommand
from stocks.models import SysSymbolcandidate, SignalMonitor, UpDownHistPerf
from stocks.views.services import MarketDataService

# ==========================================================
# INSTITUTIONAL PARAMETERS
# ==========================================================
CYCLE_PARAMS = {
    'Daily': {
        'backdays': 730,
        'min_win_rate': 0.65,
        'min_samples': 15,
        'min_ev': 0.01,
        'min_sharpe': 1.0,
        'min_level': 2,
        'max_level': 5,
    },
    'Weekly': {
        'backdays': 1825,
        'min_win_rate': 0.65,
        'min_samples': 8,
        'min_ev': 0.02,
        'min_sharpe': 0.8,
        'min_level': 2,
        'max_level': 5,
    }
}

class Command(BaseCommand):
    help = 'Midnight Scan: Pivot-based Detection with Binary Outcome Logic'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("--- DEEP TRACE START ---"))

        candidates = SysSymbolcandidate.objects.all()
        current_cycle = 'Daily' 
        params = CYCLE_PARAMS[current_cycle]
        
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=params['backdays'])

        for cand in candidates:
            ticker = cand.symbol.strip().upper()
            try:
                # 1. FETCH DATA
                df = MarketDataService.get_historical_data(
                    ticker, 
                    cycle=current_cycle.lower(),
                    start_date=start_date.strftime('%Y-%m-%d'),
                    end_date=end_date.strftime('%Y-%m-%d')
                )
                
                if df is None or df.empty:
                    continue

                # Create digit list for matching
                data_list = []
                for idx, row in df.iterrows():
                    data_list.append({
                        'digit': "1" if row['Close'] > row['Open'] else "0",
                        'price': row['Close'],
                        'date': idx.date() if hasattr(idx, 'date') else idx
                    })

                full_pos_string = "".join([d['digit'] for d in data_list])
                last_digit = full_pos_string[-1]

                # 2. BACK-LOOK (Determine Watch Pattern)
                pivot_digit = '0' if last_digit == '1' else '1'
                pivot_idx = full_pos_string.rfind(pivot_digit)
                
                if pivot_idx == -1: continue

                current_watch_pattern = full_pos_string[pivot_idx:]
                level = len(current_watch_pattern)

                if level < params['min_level'] or level > params['max_level']:
                    continue

                # 3. DB MATCHING
                qs = UpDownHistPerf.objects.filter(
                    ticker=ticker,
                    cycle=current_cycle,
                    watch_pattern=current_watch_pattern,
                    win_rate__gte=params['min_win_rate'],
                    ev_pct__gte=params['min_ev']
                )

                for strat in qs:
                    # 4. TRIGGER & OUTCOME LOGIC
                    # The trigger is the last digit of the target pattern (e.g., '011' -> '1')
                    trigger_digit = strat.target_pattern[-1]

                    # Use your target_pattern from DB to find historical Wins/Losses
                    outcome_str, m_count = self.calculate_recent_outcomes(
                        data_list, 
                        strat.target_pattern, 
                        strat.trade_direction
                    )

                    # 5. SAVE
                    SignalMonitor.objects.update_or_create(
                        ticker=ticker,
                        cycle=current_cycle,
                        watch_pattern=current_watch_pattern,
                        defaults={
                            'company_name': getattr(cand, 'company_name', ticker),
                            'last_close_price': data_list[-1]['price'],
                            'last_close_date': data_list[-1]['date'],
                            'recent_pos_string': full_pos_string[-15:],
                            'run_direction': strat.run_direction,
                            'level': level,
                            'trigger_digit': trigger_digit,
                            'recommendation': strat.trade_direction,
                            'win_rate': strat.win_rate,
                            'expected_value': strat.ev_pct,
                            'recent_outcome': outcome_str,
                            'missing_count': m_count,
                            'status': 'Waiting'
                        }
                    )
                    self.stdout.write(f"  [+] {ticker} matched {strat.target_pattern} -> {strat.trade_direction}")

            except Exception as e:
                self.stdout.write(self.style.ERROR(f"  [!] ERROR {ticker}: {str(e)}"))

    def calculate_recent_outcomes(self, data_list, target_pattern, trade_direction):
        """
        Scans data_list for target_pattern. 
        If LONG: next digit '1' = win. 
        If SHORT: next digit '0' = win.
        """
        outcomes = []
        t_len = len(target_pattern)

        for i in range(0, len(data_list) - t_len):
            segment = "".join([data_list[j]['digit'] for j in range(i, i + t_len)])
            
            if segment == target_pattern:
                # The digit IMMEDIATELY after the pattern completes
                next_digit = data_list[i + t_len]['digit']
                
                is_win = (trade_direction == "LONG" and next_digit == "1") or \
                         (trade_direction == "SHORT" and next_digit == "0")
                
                outcomes.append('s' if is_win else 'f')

        res_str = "".join(outcomes[-15:])
        
        # Count consecutive failures at the end
        missing = 0
        for char in reversed(res_str):
            if char == 'f': missing += 1
            else: break
            
        return res_str, missing
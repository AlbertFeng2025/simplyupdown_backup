"""
=============================================================================
DJANGO TASK UNIVERSAL WRAPPER (FOR PYTHONANYWHERE)
=============================================================================
Goal: Automatically handle the 1-hour Winter/Summer time shift in New York
so your stock signals always run at the exact same LOCAL New York time
regardless of EST (winter) or EDT (summer).

WHY THIS IS NEEDED:
-------------------
PythonAnywhere scheduled tasks run in UTC only.
New York is UTC-5 in Winter (EST) and UTC-4 in Summer (EDT).
This 1-hour shift means a fixed UTC time hits different NY local times
depending on the season.

This wrapper detects which season we are in and waits 1 hour if needed,
so the actual Django command always fires at the correct NY local time.

HOW TO USE IN PYTHONANYWHERE TASKS TAB:
----------------------------------------
Step 1: Go to the 'Tasks' tab in your PythonAnywhere dashboard.
Step 2: Set the UTC time in the task scheduler.
Step 3: In the 'Command' box paste the wrapper call in this format:

    python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py [NY_TARGET_HOUR] "python /home/chpfeng2000gmail/mysite/manage.py [command] [--args]"

PARAMETERS:
-----------
    [NY_TARGET_HOUR]  : The target hour in New York time, 24-hour format.
                        e.g. 15 = 3 PM NY,  16 = 4 PM NY,  22 = 10 PM NY
    "[FULL_COMMAND]"  : The full Django manage.py command in double quotes.
                        Always use the full absolute path to manage.py.

=============================================================================
LIVE EXAMPLES (copy and paste directly into PythonAnywhere Tasks):
=============================================================================

1. MIDNIGHT SCAN — All Cycles (10:00 PM NY Time)
   UTC Time to set in scheduler : 03:00 (next day, winter) / 02:00 (summer)
   Use wrapper target hour       : 22
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 22 "python /home/chpfeng2000gmail/mysite/manage.py midnight_scan --cycle all"

2. DAILY HISTORY SCAN (6:00 PM NY Time — after market settled)
   UTC Time to set in scheduler : 23:00 (winter) / 22:00 (summer)
   Use wrapper target hour       : 18
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 18 "python /home/chpfeng2000gmail/mysite/manage.py run_hist_scan --cycle daily"

3. SETTLE PHASE — Archive Engine (3:50 PM NY Time)
   UTC Time to set in scheduler : 20:50 (winter) / 19:50 (summer)
   Use wrapper target hour       : 15
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 15 "python /home/chpfeng2000gmail/mysite/manage.py archive_engine --phase settle"

4. CAPTURE PHASE — Archive Engine (4:10 PM NY Time)
   UTC Time to set in scheduler : 21:10 (winter) / 20:10 (summer)
   Use wrapper target hour       : 16
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 16 "python /home/chpfeng2000gmail/mysite/manage.py archive_engine --phase capt"

5. WEEKLY HISTORY SCAN — All Cycles (Sunday 8:00 PM NY Time)
   UTC Time to set in scheduler : 01:00 Monday (winter) / 00:00 Monday (summer)
   Use wrapper target hour       : 20
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 20 "python /home/chpfeng2000gmail/mysite/manage.py run_hist_scan --cycle daily"

6. PUBLIC BROADCAST — Discord Final Alert (3:55 PM NY Time)
   UTC Time to set in scheduler : 20:55 (winter) / 19:55 (summer)
   Use wrapper target hour       : 15
   PythonAnywhere Command box:
   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 15 "python /home/chpfeng2000gmail/mysite/manage.py broadcast_public --channel discord --cycle Daily --alert-type final"

=============================================================================
TIPS:
=============================================================================
- ALWAYS use the full absolute path:
      /home/chpfeng2000gmail/mysite/manage.py
  Never use a relative path like ./manage.py — PythonAnywhere
  tasks do not have a working directory set.

- ALWAYS wrap your Django command in "double quotes" as the second argument.

- [NY_TARGET_HOUR] is just the hour integer — no minutes, no quotes.
  e.g.  15  not  "15"  and not  15:50

- The wrapper only handles whole-hour shifts (EST vs EDT = exactly 1 hour).
  It does NOT handle sub-hour offsets — those do not apply to New York time.

- To verify pytz is available on PythonAnywhere:
      python -c "import pytz; print(pytz.__version__)"
  If missing: pip install --user pytz

=============================================================================
"""
import sys
import os
import time
import pytz
from datetime import datetime


def main():
    # ─────────────────────────────────────────────────────────────
    # STEP 1 — READ ARGUMENTS
    # ─────────────────────────────────────────────────────────────
    # sys.argv is the list of words you typed after 'python script.py'
    #
    # sys.argv[0] = the script file itself (ignored)
    # sys.argv[1] = NY target hour you passed  (e.g. 22)
    # sys.argv[2] = the full Django command     (e.g. "python ...manage.py midnight_scan --cycle all")
    #
    # Example full call:
    #   python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 22 "python /home/chpfeng2000gmail/mysite/manage.py midnight_scan --cycle all"
    #
    #   sys.argv[1] = '22'
    #   sys.argv[2] = 'python /home/chpfeng2000gmail/mysite/manage.py midnight_scan --cycle all'

    try:
        target_hour    = int(sys.argv[1])
        command_to_run = sys.argv[2]
    except IndexError:
        print("ERROR: Missing arguments.")
        print("Usage:")
        print('  python task_universal_wrapper.py [NY_TARGET_HOUR] "[FULL_COMMAND]"')
        print("Example:")
        print('  python /home/chpfeng2000gmail/mysite/stocks/management/commands/task_universal_wrapper.py 22 "python /home/chpfeng2000gmail/mysite/manage.py midnight_scan --cycle all"')
        return

    # ─────────────────────────────────────────────────────────────
    # STEP 2 — GET CURRENT NEW YORK TIME
    # ─────────────────────────────────────────────────────────────
    # pytz handles the EST/EDT switch automatically.
    # We never need to manually add or subtract hours.
    #
    # America/New_York:
    #   Winter (EST) = UTC - 5
    #   Summer (EDT) = UTC - 4

    ny_tz      = pytz.timezone('America/New_York')
    now_in_ny  = datetime.now(ny_tz)

    print(f"[WRAPPER] Current NY time : {now_in_ny.strftime('%Y-%m-%d %H:%M:%S %Z')}")
    print(f"[WRAPPER] Target NY hour  : {target_hour}:00")
    print(f"[WRAPPER] Command         : {command_to_run}")

    # ─────────────────────────────────────────────────────────────
    # STEP 3 — WINTER SHIFT DETECTION
    # ─────────────────────────────────────────────────────────────
    # PythonAnywhere always runs tasks at a fixed UTC time.
    # In Summer (EDT, UTC-4) the NY local hour is already correct.
    # In Winter (EST, UTC-5) NY local time is 1 hour behind UTC-4,
    # so the task fires 1 hour too early in local NY terms.
    #
    # DETECTION RULE:
    #   If NY local hour == target_hour - 1
    #   → we are 1 hour early → it is Winter → wait 3600 seconds
    #
    # EXAMPLE:
    #   Task set at 03:00 UTC to hit 22:00 NY (EDT, summer)
    #   In Winter (EST):  03:00 UTC = 22:00 - 1 = 21:00 NY  ← 1 hour early
    #   Wrapper detects:  now_in_ny.hour (21) == target_hour - 1 (21) → wait
    #   After 3600s wait: NY time is now 22:00 → fires correctly  ✅
    #
    #   In Summer (EDT):  03:00 UTC = 23:00 NY  ← wait, this would be wrong
    #   Better to set UTC 02:00 for summer target 22:00 NY
    #   → now_in_ny.hour (22) == target_hour (22) → no wait needed  ✅

    if now_in_ny.hour == (target_hour - 1):
        print(f"[WRAPPER] Winter shift detected (EST). "
              f"NY is at {now_in_ny.hour}:xx, target is {target_hour}:00.")
        print(f"[WRAPPER] Waiting 3600 seconds (1 hour) to reach target time...")
        time.sleep(3600)
        print(f"[WRAPPER] Wait complete. Proceeding to execute command.")
    else:
        print(f"[WRAPPER] No shift needed. "
              f"NY hour {now_in_ny.hour} matches target {target_hour}. Running now.")

    # ─────────────────────────────────────────────────────────────
    # STEP 4 — EXECUTE THE DJANGO COMMAND
    # ─────────────────────────────────────────────────────────────
    # os.system() runs the string as a terminal command, exactly as
    # if you typed it yourself in the PythonAnywhere bash console.
    #
    # It returns an exit code:
    #   0  = success
    #   1+ = something went wrong (check the task log for details)

    print(f"[WRAPPER] Executing: {command_to_run}")
    exit_code = os.system(command_to_run)

    if exit_code == 0:
        print("[WRAPPER] Task completed successfully. ✅")
    else:
        print(f"[WRAPPER] Task FAILED with exit code: {exit_code} ❌")
        print("[WRAPPER] Check the task log above for the full error traceback.")


if __name__ == "__main__":
    main()
# ==============================================================================
# PRIVATE MEMBER SIGNAL DELIVERY ENGINE (Unified)
# ==============================================================================
# This module processes and delivers stock signals to PREM and PLAT members
# via Email and Telegram. It automatically handles signal filtering based on
# House Filters and individual member preferences.
#
# HOW TO USE (Parameters are CASE-SENSITIVE):
#
# 1. --cycle      : 'allcycle' (Recommended), 'Daily', 'Weekly', 'Monthly'
#    - 'allcycle' : Automatically detects if today is Friday (Weekly) or
#                   Month-End (Monthly) and runs all applicable cycles.
#
# 2. --alert-type : 'watching' (default), 'final'
#    - 'watching' : The 3:30 PM ET "heads up" alert.
#    - 'final'    : The 3:55 PM ET "act now" confirmation alert.
#
# ------------------------------------------------------------------------------
# PYTHONANYWHERE SCHEDULED TASKS (Recommended Setup):
# ------------------------------------------------------------------------------
# 1. Watching Alert (Set for 3:30 PM ET / 20:30 UTC):
#    python manage.py deliver_signals --cycle allcycle --alert-type watching
#
# 2. Final Alert (Set for 3:55 PM ET / 20:55 UTC):
#    python manage.py deliver_signals --cycle allcycle --alert-type final
#
# NOTE: Using 'allcycle' ensures that on a Friday, both Daily and Weekly
# The Weekly and Monthly only trigered on Fri and end of month.
# signals are processed in one go without needing extra task slots.
# ==============================================================================


# ... (rest of the imports and code remain the same)
# ==============================================================================

import logging
import datetime
import pytz
import requests

from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models import Q

from stocks.models import SignalMonitor, HouseTicker, SignalAlertLog
from stocks.views.services import MarketDataService

logger = logging.getLogger(__name__)
NY_TZ  = pytz.timezone('America/New_York')


class Command(BaseCommand):
    help = 'Deliver triggered signals to PREM and PLAT members'

    def add_arguments(self, parser):
        parser.add_argument(
            '--cycle',
            type    = str,
            default = 'Daily',
            choices = ['allcycle','Daily', 'Weekly', 'Monthly'],
            help    = 'Signal cycle to deliver'
        )
        parser.add_argument(
            '--alert-type',
            type    = str,
            default = 'watching',
            choices = ['watching', 'final'],
            help    = 'watching = 3:30 PM alert, final = 3:55 PM alert'
        )

    def handle(self, *args, **options):
        cycle_arg  = options['cycle']
        alert_type = options['alert_type']

        self.stdout.write(self.style.NOTICE(f"=== Starting Signal Delivery: cycle={cycle_arg}, alert_type={alert_type} ==="))
        # Determine which cycles to actually process
        if cycle_arg == 'allcycle':
            # Run all three; the internal is_valid_delivery_day check handles the calendar logic
            cycles_to_process = ['Daily', 'Weekly', 'Monthly']
        else:
            cycles_to_process = [cycle_arg]

        for cycle in cycles_to_process:
            self.stdout.write(f"Checking cycle: {cycle}...")
            # Call the main delivery logic
            self.run_delivery(cycle, alert_type)

        self.stdout.write(self.style.SUCCESS("=== All Processed ==="))





    # ─────────────────────────────────────────────────────────────
    # MAIN CORE LOGIC
    # ─────────────────────────────────────────────────────────────
    def run_delivery(self, cycle, alert_type):
        now_ny = datetime.datetime.now(NY_TZ)

        # 1. Check calendar
        if not is_valid_delivery_day(cycle, now_ny):
            logger.info(f"Not a valid delivery day for {cycle}. Exiting.")
            return

        # 2. Fetch Base Signals
        house_symbols  = get_house_symbols()
        all_signals_qs = SignalMonitor.objects.filter(cycle=cycle, status='Waiting')
        self.stdout.write(f"  [DEBUG] Found {all_signals_qs.count()} 'Waiting' signals for {cycle}")

        if not all_signals_qs.exists():
            logger.info(f"No signals found in SignalMonitor for cycle={cycle}. Exiting.")
            return

        # 3. Cache Prices & Calculate Triggers
        price_cache  = build_price_cache(all_signals_qs)
        all_signals = get_triggered_signals(cycle, price_cache, all_signals_qs)

        triggered_all = [s for s in all_signals if s['is_triggered']]
        self.stdout.write(f"  [DEBUG] Signals that actually triggered: {len(triggered_all)}")
        if not triggered_all and alert_type == 'watching':
            logger.info(f"No triggered signals for {cycle} watching alert. Exiting.")
            return

        # 4. Fetch Eligible Members
        cycle_filter = {
            'Daily'  : {'profile__alert_cycle_daily'  : True},
            'Weekly' : {'profile__alert_cycle_weekly' : True},
            'Monthly': {'profile__alert_cycle_monthly': True},
        }

        members = User.objects.filter(
            #username='chpfeng2000@gmail.com', # <-- Add this for ONE user test only
            profile__tier__in = ['PREM', 'PLAT'],
            **cycle_filter.get(cycle, {})
        ).filter(
            Q(profile__alert_email=True)    |
            Q(profile__alert_telegram=True) |
            Q(profile__alert_sms=True)
        ).select_related('profile')
        self.stdout.write(f"  [DEBUG] Eligible members found in database: {members.count()}")
        logger.info(f"Eligible members: {members.count()}")

        # 5. Process Members and Broadcast (FAULT TOLERANT)
        for user in members:
            profile = user.profile

            try:
                # Filter specific to this user
                member_signals = get_member_signals(profile, all_signals, cycle, house_symbols)
                member_triggered = [s for s in member_signals if s['is_triggered']]
                self.stdout.write(f"    [USER: {user.username}] {len(member_signals)} passed filters, {len(member_triggered)} triggered.")

                # Find dropped tickers (For final alert)
                dropped_tickers = []
                if alert_type == 'final':
                    watching_set    = get_watching_tickers(user, cycle)
                    current_set     = {s['ticker'] for s in member_triggered}
                    dropped_tickers = list(watching_set - current_set)

                    for sig in member_triggered:
                        sig['status'] = 'new' if sig['ticker'] not in watching_set else 'triggered'

                if not member_triggered and not dropped_tickers:
                    continue  # Nothing to send this user

                # --- FAULT TOLERANT SENDING BLOCKS ---

                # EMAIL
                if profile.alert_email and user.email:
                    try:
                        self.stdout.write(f"      [EMAIL] Attempting send to {user.email}...")
                        subject, body = build_email_message(profile, member_triggered, alert_type, cycle, dropped_tickers)
                        success, error = send_email(profile, subject, body)
                        log_alert(user, cycle, alert_type, 'email', member_triggered, 'sent' if success else 'failed', error)
                    except Exception as e:
                        logger.error(f"FATAL Email error for {user.username}: {e}")

                # TELEGRAM
                if profile.alert_telegram and profile.telegram_chat_id:
                    try:
                        message = build_telegram_message(profile, member_triggered, alert_type, cycle, dropped_tickers)
                        success, error = send_telegram(profile, message)
                        log_alert(user, cycle, alert_type, 'telegram', member_triggered, 'sent' if success else 'failed', error)
                    except Exception as e:
                        logger.error(f"FATAL Telegram error for {user.username}: {e}")

                # SMS
                if profile.alert_sms and profile.phone:
                    try:
                        message = build_sms_message(member_triggered, alert_type, cycle)
                        success, error = send_sms(profile, message)
                        log_alert(user, cycle, alert_type, 'sms', member_triggered, 'sent' if success else 'failed', error)
                    except Exception as e:
                        logger.error(f"FATAL SMS error for {user.username}: {e}")

            except Exception as e:
                # If the filtering itself fails, we catch it here so it doesn't break the loop for OTHER users.
                logger.error(f"Failed to process entire profile for {user.username}: {e}")
                continue


# ─────────────────────────────────────────────────────────────
# HELPER FUNCTIONS (Moved from notifications.py)
# ─────────────────────────────────────────────────────────────

def is_valid_delivery_day(cycle, now_ny):
    import pandas_market_calendars as mcal
    nyse     = mcal.get_calendar('NYSE')
    today    = now_ny.date()
    schedule = nyse.schedule(start_date=today, end_date=today)

    if schedule.empty: return False
    if cycle == 'Daily': return True
    elif cycle == 'Weekly': return today.weekday() == 4
    elif cycle == 'Monthly':
        last_day_of_month = (today.replace(day=1) + datetime.timedelta(days=32)).replace(day=1) - datetime.timedelta(days=1)
        month_schedule = nyse.schedule(start_date=today, end_date=last_day_of_month)
        return today == month_schedule.index[-1].date()
    return False

def get_house_symbols():
    return list(HouseTicker.objects.filter(is_active=True).values_list('symbol', flat=True))

def build_price_cache(signals):
    """
    Build a {ticker: live_price} dict for all signals.

    OLD: get_live_price() called once per ticker in a loop
         100 tickers = 100 API calls  ❌

    NEW: get_live_prices_batch() fetches all tickers in ONE call
         100 tickers = 1 API call     ✅

    The returned dict shape is identical to the old version —
    everything that calls price_cache[ticker] works unchanged.
    """

    # Build two things the batch function needs:
    #   symbols     — list of ticker strings
    #   last_closes — dict of {ticker: last_close_price} for fallback

    unique_tickers = {sig.ticker: sig for sig in signals}  # dedup by ticker
    symbols        = list(unique_tickers.keys())
    last_closes    = {
        ticker: float(sig.last_close_price)
        for ticker, sig in unique_tickers.items()
    }

    # ONE batch API call instead of N individual calls
    batch_results = MarketDataService.get_live_prices_batch(
        symbols       = symbols,
        last_closes   = last_closes,
        force_refresh = True,
        include_news  = False
    )

    # batch_results shape: { 'AAPL': (price, update_time, is_from_cache, vibe), ... }
    # We only need the price (index 0) — same as old version
    price_cache = {}
    for ticker, result in batch_results.items():
        if result is not None and result[0] is not None:
            price_cache[ticker] = result[0]           # ← price only
        else:
            price_cache[ticker] = last_closes.get(ticker, 0.0)  # ← fallback

    return price_cache




def get_triggered_signals(cycle, price_cache, signals):
    result = []
    for sig in signals:
        live_price     = price_cache.get(sig.ticker, float(sig.last_close_price))
        current_digit  = "1" if live_price > float(sig.last_close_price) else "0"
        is_triggered   = (current_digit == sig.trigger_digit)

        result.append({
            'ticker'        : sig.ticker,
            'action'        : sig.recommendation,
            'cycle'         : cycle,
            'level'         : sig.level,
            'win_rate'      : float(sig.win_rate),
            'ev_pct'        : float(sig.ev_pct or 0),
            'win_loss_ratio': float(sig.win_loss_ratio or 0),
            'sharpe_ratio'  : float(sig.sharpe_ratio or 0),
            'annual_return' : float(sig.annual_return or 0),
            'sample_count'  : sig.sample_count or 0,
            'is_triggered'  : is_triggered,
        })
    return result

def get_member_signals(profile, all_signals, cycle, house_symbols):
    house_filters = settings.HOUSE_FILTERS.get(cycle, settings.HOUSE_FILTERS['Daily'])

    if profile.tier == 'PREM': allowed_tickers = set(house_symbols)
    elif profile.tier == 'PLAT':
        custom = set(profile.custom_tickers or [])
        allowed_tickers = custom | set(house_symbols) if profile.include_house_alerts else custom
    else: return []

    if profile.tier == 'PREM':
        min_win_rate = max(profile.min_win_rate_filter or 0, house_filters['min_win_rate'])
        min_ev       = max(profile.min_ev_filter or 0,       house_filters['min_ev'])
        min_sharpe   = max(profile.min_sharpe_filter or 0,   house_filters['min_sharpe'])
        min_samples  = max(profile.min_sample_count_filter or 0, house_filters['min_samples'])
        min_annual   = profile.min_annual_return_filter if profile.min_annual_return_filter is not None else -999.0
    else:
        min_win_rate = profile.min_win_rate_filter if profile.min_win_rate_filter is not None else 0
        min_ev       = profile.min_ev_filter if profile.min_ev_filter is not None else 0
        min_sharpe   = profile.min_sharpe_filter if profile.min_sharpe_filter is not None else 0
        min_samples  = profile.min_sample_count_filter if profile.min_sample_count_filter is not None else 0
        min_annual   = profile.min_annual_return_filter if profile.min_annual_return_filter is not None else -999.0

    filtered = []
    for sig in all_signals:
        if sig['ticker'] not in allowed_tickers: continue
        if sig['win_rate'] < min_win_rate: continue
        if sig['ev_pct'] < min_ev: continue
        if sig['sharpe_ratio'] < min_sharpe: continue
        if sig['sample_count'] < min_samples: continue
        if sig['annual_return'] < min_annual: continue
        filtered.append(sig)

    return filtered

def build_email_message(profile, triggered_signals, alert_type, cycle, dropped_tickers=None):
    first_name = profile.first_name or profile.user.username or profile.user.email.split('@')[0]
    if alert_type == 'watching':
        subject = f"⚠️ SimplyUpDown — {cycle} Signals to Watch ({len(triggered_signals)} triggered)"
        intro   = f"Hi {first_name},\n\nThe following {cycle} signals are currently triggered as of 3:30 PM ET.\nThese are NOT final — market is still open.\nFinal confirmation alert will be sent at 3:55 PM ET.\n\n"
    else:
        subject = f"✅ SimplyUpDown — {cycle} Final Signals ({len(triggered_signals)} confirmed)"
        intro   = f"Hi {first_name},\n\nFinal {cycle} signal status as of 3:55 PM ET.\nMarket closes at 4:00 PM ET.\n\n"

    if triggered_signals:
        lines = ["TRIGGERED SIGNALS:\n" + "-" * 55]
        for sig in triggered_signals:
            win_pct = round(sig['win_rate'] * 100)
            rr      = round(sig['win_loss_ratio'], 2)
            ev      = round(sig['ev_pct'] * 100, 1) # Multiply by 100 for % display
            tag     = "🆕 NEW" if sig.get('status') == 'new' else "✅"
            lines.append(f"{tag} {sig['ticker']:<6} | {sig['action']:<5} | Win {win_pct}% | RR {rr} | EV {ev}%")
        lines.append("")
    else: lines = ["No signals triggered at this time.\n"]

    if alert_type == 'final' and dropped_tickers:
        lines.append("DROPPED SINCE 3:30 PM (no longer triggered):\n" + "-" * 40)
        for ticker in dropped_tickers: lines.append(f"❌ {ticker} — signal flipped, skip today")
        lines.append("")

    glossary = (
        "GLOSSARY:\n"
        "• RR (Reward-to-Risk): Average profit vs average loss per trade.\n"
        "• EV (Expected Value): The average expected % return per trade based on historical performance.\n"
    )

    footer = f"\n{glossary}\nThis alert is based on your account filter settings.\n"
    return subject, intro + "\n".join(lines) + footer

def build_telegram_message(profile, triggered_signals, alert_type, cycle, dropped_tickers=None):
    date_str = datetime.datetime.now(NY_TZ).strftime("%b %d, %Y")
    if alert_type == 'watching':
        header = f"⚠️ *SimplyUpDown — {cycle} Watching*\n_{date_str} | 3:30 PM ET — Not final_\n\n"
    else:
        header = f"✅ *SimplyUpDown — {cycle} Final*\n_{date_str} | 3:55 PM ET — Act now_\n\n"

    lines = []
    for sig in triggered_signals:
        win_pct = round(sig['win_rate'] * 100)
        rr      = round(sig['win_loss_ratio'], 2)
        ev      = round(sig['ev_pct'] * 100, 1)
        tag     = "🆕" if sig.get('status') == 'new' else "✅"
        lines.append(f"{tag} *{sig['ticker']}* | {sig['action']} | Win {win_pct}% | RR {rr} | EV {ev}%")

    if alert_type == 'final' and dropped_tickers:
        lines.append("\n*Dropped:*")
        for ticker in dropped_tickers: lines.append(f"❌ {ticker}")

    glossary = "\n\n_RR: Reward-to-Risk ratio_\n_EV: Expected % return per trade_"

    if not triggered_signals:
        lines.append("_No signals triggered._")

    return header + "\n".join(lines) + glossary

def build_sms_message(triggered_signals, alert_type, cycle):
    count = len(triggered_signals)
    if alert_type == 'watching': return f"SimplyUpDown ⚠️ {count} {cycle} signal(s) watching. Final alert at 3:55PM ET. Login to view."
    else: return f"SimplyUpDown ✅ {count} {cycle} signal(s) confirmed at 3:55PM ET. Login to act now."

def send_email(profile, subject, body):
    recipient = profile.user.email
    if not recipient: return False, "No email address on account"
    try:
        send_mail(subject=subject, message=body, from_email=settings.DEFAULT_FROM_EMAIL, recipient_list=[recipient], fail_silently=False)
        return True, None
    except Exception as e: return False, str(e)

def send_telegram(profile, message):
    if not profile.telegram_chat_id: return False, "No telegram_chat_id on profile"
    token = getattr(settings, 'TELEGRAM_BOT_TOKEN', None)
    if not token: return False, "Bot token not configured."
    try:
        resp = requests.post(f"https://api.telegram.org/bot{token}/sendMessage", json={"chat_id": profile.telegram_chat_id, "text": message, "parse_mode": "Markdown"}, timeout=10)
        if resp.status_code == 200: return True, None
        else: return False, resp.text
    except Exception as e: return False, str(e)

def send_sms(profile, message):
    if not profile.phone: return False, "No phone number on profile"
    return True, None # Placeholder

def log_alert(user, cycle, alert_type, channel, signals, status, error=None):
    payload = [{
    'ticker': s['ticker'],
    'action': s['action'],
    'win_rate': s['win_rate'],
    'rr': s.get('win_loss_ratio', 0), # Store the RR
    'ev': s.get('ev_pct', 0),          # Store the raw EV
    'status': s.get('status', 'triggered')
    } for s in signals]
    SignalAlertLog.objects.create(user=user, cycle=cycle, alert_type=alert_type, channel=channel, signals_payload=payload, status=status, error_msg=error or '')

def get_watching_tickers(user, cycle):
    today = timezone.now().astimezone(NY_TZ).date()
    log = SignalAlertLog.objects.filter(user=user, cycle=cycle, alert_type='watching', sent_at__date=today).order_by('-sent_at').first()
    if not log: return set()
    return {s['ticker'] for s in log.signals_payload}
# stocks/management/commands/deliver_signals.py

from django.core.management.base import BaseCommand
from stocks.notifications import deliver_signals


class Command(BaseCommand):
    help = 'Deliver triggered signals to PREM and PLAT members'

    def add_arguments(self, parser):
        parser.add_argument(
            '--cycle',
            type    = str,
            default = 'Daily',
            choices = ['Daily', 'Weekly', 'Monthly'],
            help    = 'Signal cycle to deliver'
        )
        parser.add_argument(
            '--alert-type',
            type    = str,
            default = 'watching',
            choices = ['watching', 'final'],
            help    = 'watching = 3:30 PM alert, final = 3:55 PM alert'
        )

    def handle(self, *args, **options):
        cycle      = options['cycle']
        alert_type = options['alert_type']

        self.stdout.write(
            self.style.NOTICE(
                f"Starting signal delivery: cycle={cycle}, alert_type={alert_type}"
            )
        )

        deliver_signals(cycle=cycle, alert_type=alert_type)

        self.stdout.write(self.style.SUCCESS("Done."))
 

''' 

## Step 4 — PythonAnywhere Scheduled Tasks

Add these four tasks in the PA dashboard:

# Daily watching alert — 3:30 PM ET (19:30 UTC winter / 20:30 UTC summer)
/home/yourusername/venv/bin/python /home/yourusername/mysite/manage.py deliver_signals --cycle Daily --alert-type watching

# Daily final alert — 3:55 PM ET (19:55 UTC winter / 20:55 UTC summer)
/home/yourusername/venv/bin/python /home/yourusername/mysite/manage.py deliver_signals --cycle Daily --alert-type final

# Friday only — Weekly (same times)
/home/yourusername/venv/bin/python /home/yourusername/mysite/manage.py deliver_signals --cycle Weekly --alert-type watching
/home/yourusername/venv/bin/python /home/yourusername/mysite/manage.py deliver_signals --cycle Weekly --alert-type final
'''
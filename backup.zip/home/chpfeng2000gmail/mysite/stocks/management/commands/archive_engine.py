"""
File   : archive_engine.py
Purpose: Permanently records triggered signals and settles completed trades.
         Cycle-aware: Daily, Weekly, and Monthly each have correct
         entry and exit timing rules.

THE CORE RULE — SAME FOR ALL CYCLES:
  Enter at bar N close   (the trigger bar)
  Exit  at bar N+1 close (the very next bar of the same cycle)

  Daily:   Bar N = today,        Bar N+1 = tomorrow
  Weekly:  Bar N = this Friday,  Bar N+1 = next Friday
  Monthly: Bar N = this month end, Bar N+1 = next month end

SCHEDULING ON PYTHONANYWHERE — add TWO tasks:
  Task 1: python manage.py archive_engine   at 3:50 PM ET  (CAPTURE)
  Task 2: python manage.py archive_engine   at 4:15 PM ET  (SETTLE)
"""

import datetime
import pandas_market_calendars as mcal
import pytz
from django.core.management.base import BaseCommand
from django.utils import timezone
from stocks.models import SignalMonitor, StrategyArchive
from stocks.views.services import MarketDataService
from django.conf import settings

# ── Module-level constants ────────────────────────────────────────────────────
# Build the NYSE calendar once — reused by all helper functions below
NYSE = mcal.get_calendar('NYSE')
NY_TZ = pytz.timezone('America/New_York')


# ══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_nyse_schedule(start, end):
    """Returns NYSE trading schedule DataFrame between start and end dates."""
    return NYSE.schedule(
        start_date=start.strftime('%Y-%m-%d'),
        end_date=end.strftime('%Y-%m-%d')
    )


def is_trading_day(today):
    """Returns True if today is an NYSE trading day."""
    schedule = get_nyse_schedule(today, today)
    return not schedule.empty


def is_friday(today):
    """
    Returns True if today is Friday.
    PYTHON LEARNING: weekday() → Mon=0, Tue=1, Wed=2, Thu=3, Fri=4, Sat=5, Sun=6
    """
    return today.weekday() == 4


def is_last_trading_day_of_month(today):
    """
    Returns True if today is the last NYSE trading day of its calendar month.

    HOW IT WORKS:
        1. Find the last calendar day of this month.
        2. Get NYSE schedule from today to that last calendar day.
        3. If today == last session in that schedule → True.

    This correctly handles months where the last calendar day is a weekend
    or holiday — e.g. if March 31 is Saturday, last trading day = March 29.
    """
    # Find last calendar day of this month
    # Trick: go to 1st of next month, subtract 1 day
    if today.month == 12:
        last_cal_day = datetime.date(today.year + 1, 1, 1) - datetime.timedelta(days=1)
    else:
        last_cal_day = datetime.date(today.year, today.month + 1, 1) - datetime.timedelta(days=1)

    schedule = get_nyse_schedule(today, last_cal_day)
    if schedule.empty:
        return False

    return today == schedule.index[-1].date()


def get_next_friday(from_date):
    """
    Returns the next Friday AFTER from_date (not including from_date).

    Example:
        from_date = Friday March 14 → returns Friday March 21
        from_date = Monday March 17 → returns Friday March 21
        from_date = Thursday March 20 → returns Friday March 21
    """
    # How many days until Friday?
    # (4 - weekday) % 7 gives days until next Friday
    # If today IS Friday, % 7 gives 0 → we add 7 to get NEXT Friday
    days_ahead = (4 - from_date.weekday()) % 7
    if days_ahead == 0:
        days_ahead = 7
    return from_date + datetime.timedelta(days=days_ahead)


def get_next_month_end(from_date):
    """
    Returns the last NYSE trading day of the NEXT calendar month.

    Example:
        from_date = March 31 → returns last trading day of April
        from_date = March 15 → returns last trading day of April
    """
    # Step 1: first day of next month
    if from_date.month == 12:
        next_month_start = datetime.date(from_date.year + 1, 1, 1)
    else:
        next_month_start = datetime.date(from_date.year, from_date.month + 1, 1)

    # Step 2: last calendar day of next month
    if next_month_start.month == 12:
        next_month_last = datetime.date(next_month_start.year + 1, 1, 1) - datetime.timedelta(days=1)
    else:
        next_month_last = datetime.date(next_month_start.year, next_month_start.month + 1, 1) - datetime.timedelta(days=1)

    # Step 3: last TRADING day of next month
    schedule = get_nyse_schedule(next_month_start, next_month_last)
    if schedule.empty:
        return None
    return schedule.index[-1].date()


def is_capture_day(cycle, today):
    """
    Returns True if today is the correct day to CAPTURE an entry for this cycle.

    Daily   → any NYSE trading day
    Weekly  → only Friday (and must be a trading day — some Fridays are holidays)
    Monthly → only last NYSE trading day of the month
    """
    if cycle == 'Daily':
        return is_trading_day(today)
    elif cycle == 'Weekly':
        return is_friday(today) and is_trading_day(today)
    elif cycle == 'Monthly':
        return is_last_trading_day_of_month(today)
    return False


def is_settle_day(cycle, trade, today):
    """
    Returns True if today is the correct day to SETTLE this trade.

    Daily   → any trading day after entry date
              (next trading day, could be Monday if entered Friday)
    Weekly  → exactly the next Friday after entry Friday
    Monthly → exactly the last trading day of next month after entry

    IMPORTANT:
        We do NOT settle based on digit reversal for Weekly/Monthly.
        We settle on the fixed next-bar date — this matches the strategy rule:
        "Enter bar N, exit bar N+1"
    """
    entry_date = trade.entry_date

    if cycle == 'Daily':
        # Any trading day after entry (handles Friday→Monday gap automatically)
        return today > entry_date and is_trading_day(today)

    elif cycle == 'Weekly':
        # Must be exactly the next Friday after entry Friday
        target_friday = get_next_friday(entry_date)
        return today == target_friday and is_trading_day(today)

    elif cycle == 'Monthly':
        # Must be exactly the last trading day of next month
        target_month_end = get_next_month_end(entry_date)
        if target_month_end is None:
            return False
        return today == target_month_end

    return False


# ══════════════════════════════════════════════════════════════════════════════
# THE COMMAND CLASS
# ══════════════════════════════════════════════════════════════════════════════

class Command(BaseCommand):
    help = 'Cycle-aware archive engine — captures triggers and settles trades for Daily, Weekly, Monthly.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--phase',
            type=str,
            required=True,              # must always specify
            choices=['capture', 'settle'],
            help=(
                'Which phase to run:\n'
                '  capture → record new triggered signals (run ~3:50 PM ET)\n'
                '  settle  → record trade results        (run ~4:15 PM ET)\n'
                'Example: python manage.py archive_engine --phase capture'
            )
        )

    def handle(self, *args, **options):

        now_ny = datetime.datetime.now(NY_TZ)
        today  = now_ny.date()
        phase  = options['phase']   # 'capture' or 'settle'

        self.stdout.write(f"\n{'='*60}")
        self.stdout.write(f"Archive Engine — {today}  {now_ny.strftime('%H:%M')} ET")
        self.stdout.write(f"Phase: {phase.upper()}")
        self.stdout.write(f"{'='*60}")

        if phase == 'capture':
            self._phase1_capture(today)
        elif phase == 'settle':
            self._phase2_settle(today)

        self.stdout.write(self.style.SUCCESS(f"\n--- Archive Engine ({phase}) Complete ---"))
        # Task 1 name: Archive Capture
        # Time:        3:50 PM ET  (change anytime — no code change needed)
        # Command:     python /home/chpfeng2000gmail/mysite/manage.py archive_engine --phase capture

        # Task 2 name: Archive Settle
        # Time:        4:15 PM ET  (change anytime — no code change needed)
        # Command:     python /home/chpfeng2000gmail/mysite/manage.py archive_engine --phase settle

    # ──────────────────────────────────────────────────────────────────────────
    # PHASE 1: CAPTURE
    # ──────────────────────────────────────────────────────────────────────────

    def _phase1_capture(self, today):
        """
        Capture new triggered signals into sys_StrategyArchive.

        Three checks before capturing:
          1. Is today the right capture day for this cycle?
          2. Is the trigger still confirmed at 3:50 PM?
          3. Have we already captured this ticker+cycle today?

        If all three pass → create ACTIVE record.
        """

        self.stdout.write(f"\n--- PHASE 1: CAPTURE ---")

        waiting_signals = SignalMonitor.objects.filter(status='Waiting')
        self.stdout.write(f"  Found {waiting_signals.count()} waiting signals")

        captured  = 0
        skip_day  = 0
        skip_price= 0
        skip_dupe = 0
        skip_quality  = 0
        # ── NEW: Pre-filter then batch fetch ──────────────────────
        # We apply Check 1 and Check 1.5 BEFORE fetching prices.
        # This avoids fetching prices for tickers we will skip anyway.
        # Example: on a Tuesday, ALL Weekly signals fail Check 1 →
        # no point fetching their prices at all.

        eligible     = []   # signals that pass Check 1 + Check 1.5
        eligible_map = {}   # {ticker: sig} for dedup in batch

        for sig in waiting_signals:
            cycle = sig.cycle

            # Check 1: correct capture day?
            if not is_capture_day(cycle, today):
                skip_day += 1
                continue

            # Check 1.5: house quality floor?
            house = settings.HOUSE_FILTERS.get(cycle, settings.HOUSE_FILTERS['Daily'])
            if (float(sig.win_rate     or 0) < house['min_win_rate'] or
                float(sig.ev_pct       or 0) < house['min_ev']       or
                float(sig.sharpe_ratio or 0) < house['min_sharpe']   or
                int(sig.sample_count   or 0) < house['min_samples']):
                skip_quality += 1
                self.stdout.write(
                    f"  SKIP {sig.ticker} ({cycle}): below house quality floor"
                )
                continue

            eligible.append(sig)
            eligible_map[sig.ticker] = sig   # last_close for fallback

        self.stdout.write(
            f"  Pre-filter: {len(eligible)} eligible after "
            f"day/quality checks (skipped {skip_day} day, "
            f"{skip_quality} quality)"
        )

        # Batch fetch prices for eligible tickers only — ONE API call
        last_closes = {
            sig.ticker: float(sig.last_close_price)
            for sig in eligible
        }
        batch_prices = {}
        if eligible:
            batch_results = MarketDataService.get_live_prices_batch(
                symbols       = list(last_closes.keys()),
                last_closes   = last_closes,
                force_refresh = True,
                include_news  = False
            )
            for ticker, result in batch_results.items():
                if result is not None and result[0] is not None:
                    batch_prices[ticker] = result[0]
                else:
                    batch_prices[ticker] = last_closes.get(ticker, 0.0)

        self.stdout.write(
            f"  [BATCH] Fetched {len(batch_prices)} live prices."
        )
        # ── END NEW BLOCK ──────────────────────────────────────────
        for sig in eligible:

            cycle = sig.cycle

            # CHECK 1: Is today the correct capture day for this cycle?
            # Daily   → yes any trading day
            # Weekly  → only Friday
            # Monthly → only last trading day of month
            #if not is_capture_day(cycle, today):
             #   skip_day += 1
            #    continue
            # CHECK 1.5: Does this signal meet house quality floor?
            # Uses HOUSE_FILTERS from settings.py — same floor as public
            # history page. Signals below this floor are not captured.
           # house = settings.HOUSE_FILTERS.get(cycle, settings.HOUSE_FILTERS['Daily'])
           # if (float(sig.win_rate     or 0) < house['min_win_rate'] or
            #    float(sig.ev_pct       or 0) < house['min_ev']       or
             #   float(sig.sharpe_ratio or 0) < house['min_sharpe']   or
            #    int(sig.sample_count   or 0) < house['min_samples']):
             #   skip_quality += 1
             #   self.stdout.write(
             #       f"  SKIP {sig.ticker} ({cycle}): below house quality floor"
             #   )
             #   continue

            # CHECK 1 and CHECK 1.5 already done in pre-filter above ✅

            # CHECK 2: Is the trigger still confirmed at 3:50 PM?
            # Price already fetched in batch — just look up from dict
            live_price = batch_prices.get(
                sig.ticker,
                float(sig.last_close_price)   # fallback if missing
            )

            # Build the current digit: "1" if up, "0" if down
            current_digit = "1" if live_price > float(sig.last_close_price) else "0"

            if current_digit != str(sig.trigger_digit):
                # Price moved the wrong way — trigger not confirmed
                skip_price += 1
                self.stdout.write(
                    f"  SKIP {sig.ticker} ({cycle}): "
                    f"needed '{sig.trigger_digit}' got '{current_digit}'"
                )
                continue

            # CHECK 3: Already captured today? (prevents duplicates)
            already_saved = StrategyArchive.objects.filter(
                ticker     = sig.ticker,
                cycle      = cycle,
                entry_date = today,
            ).exists()

            if already_saved:
                skip_dupe += 1
                continue

            # ALL CHECKS PASSED — calculate expected exit date
            # This tells us exactly when to come back and settle this trade
            if cycle == 'Daily':
                expected_exit_date = None   # next trading day — found dynamically
            elif cycle == 'Weekly':
                expected_exit_date = get_next_friday(today)
            elif cycle == 'Monthly':
                expected_exit_date = get_next_month_end(today)
            else:
                expected_exit_date = None

            # Determine DNA type: continuation or reversal?
            is_cont = (
                (sig.recommendation == 'LONG'  and sig.run_direction == 'UpRun') or
                (sig.recommendation == 'SHORT' and sig.run_direction == 'DownRun')
            )
            # Map the run direction to readable text
            # Format the run direction for reading
            run_desc = "price goes up" if sig.run_direction == 'UpRun' else "price goes down"

            # Format the decimals into percentages (multiply by 100)
            win_rate_pct = float(sig.win_rate or 0) * 100
            ev_percentage = float(sig.ev_pct or 0) * 100

            # Get other values (handling None/0 gracefully)
            rr_ratio = float(sig.win_loss_ratio or 0)
            sharpe = float(sig.sharpe_ratio or 0)

            # Build the string exactly as requested
            entry_note = (
                f"{sig.ticker} in the past, if consecutive {run_desc} Level {sig.level} {cycle}, "
                f"then next {cycle} has {sig.recommendation} win rate is {win_rate_pct:.2f}%, "
                f"ev is {ev_percentage:.2f}%, risk reward is {rr_ratio:.2f}, sharpe is {sharpe:.2f}."
            )
            # Save permanent entry record
            StrategyArchive.objects.create(
                ticker             = sig.ticker,
                cycle              = cycle,
                institutional_edge = "Trend Continuation" if is_cont else "Market Pivot",
                run_direction      = sig.run_direction,
                level              = sig.level,
                recommendation     = sig.recommendation,
                entry_date         = today,
                entry_price        = live_price,
                expected_exit_date = expected_exit_date,
                status             = 'ACTIVE',
                notes              = entry_note
            )

            captured += 1
            self.stdout.write(
                self.style.SUCCESS(
                    f"  CAPTURED: {sig.ticker} ({cycle}) "
                    f"${live_price:.2f} | exit expected: {expected_exit_date}"
                )
            )


        self.stdout.write(
            f"\n  Capture summary: {captured} captured | "
            f"{skip_day} wrong day | {skip_quality} below quality | "
            f"{skip_price} not triggered | {skip_dupe} duplicate"
        )


    # ──────────────────────────────────────────────────────────────────────────
    # PHASE 2: SETTLE
    # ──────────────────────────────────────────────────────────────────────────

    def _phase2_settle(self, today):
        """
        Settle completed trades and record their results.

        KEY DIFFERENCE from original code:
            Original → settled whenever digit reversed direction (wrong for Weekly/Monthly)
            Now      → settled ONLY on the correct next-bar date for each cycle

            Daily:   next trading day after entry
            Weekly:  next Friday after entry Friday
            Monthly: last trading day of next month after entry month

        At 4:15 PM the live price ≈ official close — accurate enough for settlement.
        """

        self.stdout.write(f"\n--- PHASE 2: SETTLE ---")

        active_trades = StrategyArchive.objects.filter(status='ACTIVE')
        self.stdout.write(f"  Found {active_trades.count()} active trades")

        # ── NEW: Batch fetch exit prices for all active trades ────
        # Active trades are few (only confirmed triggers held open).
        # Fetching all at once is safe and saves N individual API calls.
        settle_last_closes = {}
        for trade in active_trades:
            mon = SignalMonitor.objects.filter(
                ticker=trade.ticker,
                cycle=trade.cycle
            ).first()
            fallback = float(mon.last_close_price) if mon else float(trade.entry_price)
            settle_last_closes[trade.ticker] = fallback

        batch_exit_prices = {}
        if settle_last_closes:
            batch_exit_results = MarketDataService.get_live_prices_batch(
                symbols       = list(settle_last_closes.keys()),
                last_closes   = settle_last_closes,
                force_refresh = True,
                include_news  = False
            )
            for ticker, result in batch_exit_results.items():
                if result is not None and result[0] is not None:
                    batch_exit_prices[ticker] = result[0]
                else:
                    batch_exit_prices[ticker] = settle_last_closes.get(ticker, 0.0)

        self.stdout.write(
            f"  [BATCH] Fetched {len(batch_exit_prices)} exit prices."
        )
        # ── END NEW BLOCK ──────────────────────────────────────────

        settled = 0
        holding = 0
        errors  = 0

        for trade in active_trades:

            cycle = trade.cycle

            # Guard: never settle on same day as entry
            # (no next bar has closed yet)
            if trade.entry_date == today:
                holding += 1
                continue

            # Is today the correct settlement day for this cycle?
            if not is_settle_day(cycle, trade, today):
                holding += 1
                self.stdout.write(
                    f"  HOLD: {trade.ticker} ({cycle}) "
                    f"entered {trade.entry_date} — waiting for settlement day"
                )
                continue

            # TODAY IS SETTLEMENT DAY — get exit price and record result

            try:
                # ── NEW: Look up from batch dict — no API call needed ──
                exit_price = batch_exit_prices.get(
                    trade.ticker,
                    float(trade.entry_price)   # fallback if missing
                )
                # ── END REPLACEMENT ────────────────────────────────────

                # Calculate profit/loss
                # LONG:  profit = exit - entry  (win if price went up)
                # SHORT: profit = entry - exit  (win if price went down)
                if trade.recommendation == 'LONG':
                    diff = float(exit_price) - float(trade.entry_price)
                else:
                    diff = float(trade.entry_price) - float(exit_price)

                profit_pct = round((diff / float(trade.entry_price)) * 100, 2)
                is_win     = profit_pct > 0

                # Save all changes to DB in one .save() call
                trade.exit_price  = exit_price
                trade.exit_date   = today
                trade.profit_pct  = profit_pct
                trade.is_win      = is_win
                trade.status      = 'SETTLED'
                trade.save()

                settled += 1
                label = "WIN  ✅" if is_win else "LOSE ❌"
                self.stdout.write(
                    self.style.SUCCESS(
                        f"  SETTLED: {trade.ticker} ({cycle}) "
                        f"entry=${trade.entry_price:.2f} "
                        f"exit=${exit_price:.2f} "
                        f"→ {profit_pct:+.2f}%  {label}"
                    )
                )

            except Exception as e:
                errors += 1
                self.stdout.write(
                    self.style.ERROR(f"  ERROR: {trade.ticker} ({cycle}) → {str(e)}")
                )
                continue

        self.stdout.write(
            f"\n  Settle summary: {settled} settled | "
            f"{holding} still holding | {errors} errors"
        )


# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# ARCHIVE ENGINE — COMPLETE LOGIC DOCUMENTATION
# ══════════════════════════════════════════════════════════════════════════════
#
# ── THE CORE RULE (same for all cycles) ──────────────────────────────────────
#
#   This engine follows the SimplyUpDown trade rule exactly:
#       Enter at bar N close   (the trigger bar)
#       Exit  at bar N+1 close (the very next bar of the SAME cycle)
#
#   What "bar N+1" means depends on the cycle:
#       Daily   → tomorrow's close
#       Weekly  → next Friday's close
#       Monthly → last trading day of next month's close
#
#   We never exit early. We never exit late.
#   We exit at exactly the next bar — no matter which direction it moves.
#
# ── THE TWO PHASES ────────────────────────────────────────────────────────────
#
#   PHASE 1 — CAPTURE  (runs at 3:50 PM ET)
#   ─────────────────────────────────────────
#   PURPOSE: Take a permanent snapshot of any signal that triggered today.
#            Without this, the evidence would be lost when midnight_scan
#            wipes and rebuilds sys_SignalMonitor every night.
#
#   THREE CHECKS before capturing — ALL must pass:
#
#     Check 1 — Is today the right day for this cycle?
#       Daily   → any NYSE trading day ✅
#       Weekly  → ONLY Friday (and must be an NYSE trading day — some Fridays
#                 are holidays e.g. Good Friday)
#       Monthly → ONLY last NYSE trading day of the month
#                 (not always the 30th or 31st — weekends and holidays
#                  shift it earlier e.g. May 2026 last trading day = May 29)
#
#     Check 2 — Is the trigger STILL confirmed at 3:50 PM?
#       The midnight scan found the pattern last night.
#       But by 3:50 PM today, the price may have moved the wrong way.
#       We re-check: is live price still going in the trigger direction?
#
#       Example (Weekly):
#         Pattern confirmed Sunday night — needs UP week (trigger="1")
#         Friday 3:50 PM: price is UP vs last Friday close → digit="1" ✅ CAPTURE
#         Friday 3:50 PM: price is DOWN vs last Friday close → digit="0" ❌ SKIP
#
#       This is conservative and correct — you only enter if the bar
#       is still going your way at the moment of entry.
#
#     Check 3 — Already captured today?
#       Prevents duplicate records if the script runs more than once.
#       Uses .exists() which stops as soon as one match is found — fast.
#
#   PHASE 2 — SETTLE  (runs at 4:15 PM ET)
#   ─────────────────────────────────────────
#   PURPOSE: Record the final result of each open trade.
#            At 4:15 PM the live price ≈ official close price — accurate
#            enough for settlement purposes.
#
#   WHEN TO SETTLE — depends on cycle:
#       Daily   → next NYSE trading day after entry
#                 (automatically handles Friday→Monday gap,
#                  holiday gaps, etc.)
#       Weekly  → exactly the next Friday after entry Friday
#                 (not the day after, not whenever digit reverses —
#                  specifically the next Friday)
#       Monthly → exactly the last NYSE trading day of next month
#                 (found dynamically — never hardcoded)
#
#   IMPORTANT: we do NOT settle based on digit reversal for Weekly/Monthly.
#   The original code settled whenever the digit reversed direction.
#   This was wrong — a monthly trade could settle the very next morning
#   if price ticked the wrong way.
#   Now we settle on the FIXED next bar date only. This matches the rule:
#   "Enter bar N, exit bar N+1"
#
# ── QQQ DAILY EXAMPLE ────────────────────────────────────────────────────────
#
#   Monday midnight — midnight_scan runs:
#     QQQ daily binary string ends with "011"
#     Level 2 UpRun pattern confirmed
#     sys_SignalMonitor: QQQ Daily status=Waiting, trigger_digit="1"
#     last_close_price = $472 (Monday close)
#
#   Tuesday 3:50 PM — CAPTURE phase:
#     Check 1: is_capture_day('Daily', Tuesday)  → True (any trading day) ✅
#     Check 2: live_price = $480
#              current_digit = "1" (480 > 472) ✅ matches trigger_digit "1"
#     Check 3: not already captured today ✅
#     → sys_StrategyArchive: entry_date=Tuesday, entry_price=$480, status=ACTIVE
#
#   Wednesday 4:15 PM — SETTLE phase:
#     is_settle_day('Daily', trade, Wednesday):
#       Wednesday > Tuesday AND is_trading_day → True ✅
#     exit_price = $474 (Wednesday close)
#     recommendation = LONG
#     diff = 474 - 480 = -6
#     profit_pct = (-6 / 480) × 100 = -1.25%
#     is_win = False
#     → SETTLED ❌  status=SETTLED, profit=-1.25%
#
#   Total hold: 1 trading day ✅ (exactly as designed)
#
# ── QQQ WEEKLY EXAMPLE ───────────────────────────────────────────────────────
#
#   Sunday midnight — midnight_scan runs weekly scan:
#     QQQ weekly binary string ends with "011"
#     Level 2 UpRun pattern confirmed on weekly bars
#     sys_SignalMonitor: QQQ Weekly status=Waiting, trigger_digit="1"
#     last_close_price = $475 (last Friday March 14 close)
#
#   Monday March 17 3:50 PM — CAPTURE phase:
#     Check 1: is_capture_day('Weekly', Monday) → False (not Friday) → SKIP ❌
#
#   Tuesday/Wednesday/Thursday 3:50 PM:
#     Check 1: not Friday → SKIP ❌ (same reason, every day until Friday)
#
#   Friday March 21 3:50 PM — CAPTURE phase:
#     Check 1: is_capture_day('Weekly', Friday) → True ✅
#     Check 2: live_price = $482
#              current_digit = "1" (482 > 475) ✅ matches trigger_digit "1"
#              (the whole week closed UP — trigger still valid)
#     Check 3: not already captured ✅
#     expected_exit_date = get_next_friday(March 21) = March 28
#     → sys_StrategyArchive: entry_date=Mar 21, entry_price=$482,
#                            expected_exit_date=Mar 28, status=ACTIVE
#
#   Friday March 21 4:15 PM — SETTLE phase:
#     is_settle_day: entry_date == today → SKIP (same day guard) ✅
#
#   Monday–Thursday March 24–27 4:15 PM — SETTLE phase:
#     is_settle_day: target_friday = March 28, today ≠ March 28 → HOLD ✅
#
#   Friday March 28 4:15 PM — SETTLE phase:
#     is_settle_day: today == March 28 AND is_trading_day → True ✅
#     exit_price = $490 (Friday close)
#     recommendation = LONG
#     diff = 490 - 482 = +8
#     profit_pct = (+8 / 482) × 100 = +1.66%
#     is_win = True
#     → SETTLED ✅  status=SETTLED, profit=+1.66%
#
#   Total hold: exactly 1 week (Friday to Friday) ✅
#
# ── QQQ MONTHLY EXAMPLE ──────────────────────────────────────────────────────
#
#   March 1 — midnight_scan runs monthly scan:
#     QQQ monthly binary string ends with "10"
#     Level 1 DownRun pattern confirmed on monthly bars
#     sys_SignalMonitor: QQQ Monthly status=Waiting, trigger_digit="0"
#     last_close_price = $460 (February 28 close — last trading day of Feb)
#
#   March 3–30 3:50 PM — CAPTURE phase (every day):
#     Check 1: is_capture_day('Monthly', March X)
#              is_last_trading_day_of_month? → False for all mid-month days
#              → SKIP ❌ (wait for month-end)
#
#   March 31 3:50 PM — last NYSE trading day of March:
#     Check 1: is_last_trading_day_of_month(March 31) → True ✅
#     Check 2: live_price = $448
#              current_digit = "0" (448 < 460) ✅ matches trigger_digit "0"
#              (the whole month closed DOWN — trigger still valid)
#     Check 3: not already captured ✅
#     expected_exit_date = get_next_month_end(March 31) = April 30
#     → sys_StrategyArchive: entry_date=Mar 31, entry_price=$448,
#                            expected_exit_date=Apr 30, status=ACTIVE
#
#   March 31 4:15 PM — SETTLE phase:
#     entry_date == today → SKIP (same day guard) ✅
#
#   April 1–29 4:15 PM — SETTLE phase (every day):
#     is_settle_day: target = April 30, today ≠ April 30 → HOLD ✅
#     (trade held for the ENTIRE month of April — correct!)
#
#   April 30 4:15 PM — last NYSE trading day of April:
#     is_settle_day: today == April 30 → True ✅
#     exit_price = $435 (April 30 close)
#     recommendation = SHORT
#     diff = 448 - 435 = +13   (SHORT: profit = entry - exit)
#     profit_pct = (+13 / 448) × 100 = +2.90%
#     is_win = True
#     → SETTLED ✅  status=SETTLED, profit=+2.90%
#
#   Total hold: exactly 1 month (March 31 to April 30) ✅
#
# ── WHY last_trading_day IS NOT ALWAYS THE 30TH OR 31ST ─────────────────────
#
#   We never hardcode the last day of a month.
#   Instead we ask pandas_market_calendars:
#       "of all NYSE trading days in this month, which is the last?"
#
#   May 2026 example:
#     May 30 = Saturday → NYSE closed
#     May 31 = Sunday   → NYSE closed
#     May 25 = Memorial Day → NYSE holiday
#     → last trading day of May 2026 = Friday May 29
#
#   get_next_month_end() finds this automatically:
#     get_nyse_schedule(May 1, May 31) → returns only actual trading days
#     schedule.index[-1].date() → May 29 ✅
#
# ── SUMMARY TABLE ─────────────────────────────────────────────────────────────
#
#   Cycle    Capture day              Settle day
#   ──────   ───────────────────────  ──────────────────────────────────
#   Daily    Any NYSE trading day     Next NYSE trading day after entry
#   Weekly   Friday (NYSE open)       Next Friday after entry Friday
#   Monthly  Last NYSE day of month   Last NYSE day of next month
#
# ══════════════════════════════════════════════════════════════════════════════
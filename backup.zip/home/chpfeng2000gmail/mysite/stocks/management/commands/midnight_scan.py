import datetime
import time
import pandas as pd
from django.utils import timezone
from django.core.management.base import BaseCommand
from stocks.models import SysSymbolcandidate, SignalMonitor, UpDownHistPerf
from stocks.views.services import MarketDataService

# ==========================================================
# ==========================================================
# INSTITUTIONAL PARAMETERS
# Imported from settings.py — single source of truth
# ==========================================================
from django.conf import settings
CYCLE_PARAMS = settings.HOUSE_FILTERS


class Command(BaseCommand):
    help = 'Midnight Scan: Finalized Schema with Granular Debugging'
    def add_arguments(self, parser):
        # Allow user to specify cycle. Default is 'Daily'.
        parser.add_argument(
            '--cycle',
            type=str,
            default='Daily',
            help='Specify cycle: "Daily", "Weekly", "Monthly", or "All" (case-insensitive).\n'
         'Example: python manage.py midnight_scan --cycle all'
        )

    def handle(self, *args, **options):
        # Capture and format the input (e.g., 'weekly' -> 'Weekly')
        raw_cycle = options.get('cycle', 'Daily').capitalize()

        # Determine which cycles to process
        if raw_cycle == 'All':
            cycles_to_run = ['Daily', 'Weekly', 'Monthly']
        else:
            cycles_to_run = [raw_cycle]

        for current_cycle in cycles_to_run:
            if current_cycle not in CYCLE_PARAMS:
                self.stdout.write(self.style.WARNING(f"Skipping invalid cycle: {current_cycle}"))
                continue

            self.stdout.write(self.style.SUCCESS(f"Starting Scan for Cycle: {current_cycle}"))

            p = CYCLE_PARAMS[current_cycle]

            self.stdout.write(self.style.MIGRATE_LABEL("--- Wiping Old Radar Data ---"))
            SignalMonitor.objects.filter(status='Waiting', cycle=current_cycle).delete()

            self.stdout.write(self.style.SUCCESS(f"--- STARTING {current_cycle} SCAN ---"))

            self.stdout.write(self.style.SUCCESS("--- DEEP TRACE START ---"))

            candidates = SysSymbolcandidate.objects.all()

            p = CYCLE_PARAMS[current_cycle]

            # ── Determine correct end_date based on market hours ──────
            #
            # WHY THIS MATTERS:
            #   If someone runs the scan at 11 AM (market open),
            #   yfinance returns today's INCOMPLETE bar —
            #   the price at 11 AM, not the final 4 PM close.
            #   This gives wrong digits and wrong patterns.
            #
            # THE RULE:
            #   Before 4:15 PM ET → today's bar is not final yet
            #                     → use yesterday as last bar
            #   After  4:15 PM ET → today's bar is complete and settled
            #                     → use today as last bar
            #
            # PYTHON LEARNING — how we check current NY time:
            #   pytz.timezone('America/New_York') handles EST/EDT
            #   automatically — we don't need to worry about
            #   summer/winter clock changes.
            #
            # PYTHON LEARNING — replace() on a datetime:
            #   now_ny.replace(hour=16, minute=15, second=0)
            #   keeps the same date but changes the time to 4:15 PM.
            #   It is like saying "same day, but at exactly 4:15 PM".

            last_trading_day, now_ny = self.last_completed_trading_day()
            end_date = last_trading_day + datetime.timedelta(days=1)
            self.stdout.write(
                f"  [TIME] {now_ny.strftime('%H:%M')} ET — "
                f"Last completed trading day: {last_trading_day} "
                f"(end_date={end_date}, exclusive)"
            )

            start_date = end_date - datetime.timedelta(days=p['backdays'])

            self.stdout.write(f"[INIT] Processing {candidates.count()} symbols. Cycle: {current_cycle}")


            # ── NEW: Batch fetch ALL historical data in ONE API call ──────
            # Instead of calling get_historical_data() once per ticker inside
            # the loop (100 calls), we fetch everything here in one shot (1 call).
            all_symbols = [c.symbol.strip().upper() for c in candidates]

            self.stdout.write(f"[BATCH] Fetching historical data for {len(all_symbols)} symbols...")

            batch_historical = MarketDataService.get_historical_data_batch(
                symbols    = all_symbols,
                cycle      = current_cycle.lower(),
                start_date = start_date.strftime('%Y-%m-%d'),
                end_date   = end_date.strftime('%Y-%m-%d')
            )

            self.stdout.write(f"[BATCH] Done. {len(batch_historical)} symbols returned.")
            # ── END NEW BLOCK ─────────────────────────────────────────────

            for cand in candidates:
                ticker = cand.symbol.strip().upper()
                self.stdout.write(f"\n[SCAN] {ticker}")

                try:
                    # ── NEW: Look up pre-fetched data from batch dict ──
                    # No API call here — result already in memory from
                    # the batch fetch we did before this loop started.
                    df = batch_historical.get(ticker)

                    if df is None or len(df) < 2:
                        self.stdout.write(f"  [!] Insufficient data for {ticker}")
                        continue
                    # ── END REPLACEMENT ───────────────────────────────


                    # Generate digit list based on Close-over-Close and make dates timezone-aware
                    data_list = []
                    for i in range(1, len(df)):
                        c_price = float(df.iloc[i]['Close'])
                        p_price = float(df.iloc[i-1]['Close'])

                        # Fix for Naive Datetime Warning
                        raw_dt = df.index[i]
                        if isinstance(raw_dt, pd.Timestamp):
                            raw_dt = raw_dt.to_pydatetime()
                        if timezone.is_naive(raw_dt):
                            aware_dt = timezone.make_aware(raw_dt)
                        else:
                            aware_dt = raw_dt

                        data_list.append({
                            'digit': "1" if c_price > p_price else "0",
                            'price': c_price,
                            'date': aware_dt
                        })

                    full_pos_string = "".join([d['digit'] for d in data_list])
                    last_digit = full_pos_string[-1]

                    # 1. Identify the 'Opposite' digit to find where the current streak started.
                    # If the last digit is '1' (UP), we look for the last '0' to see when the run began.
                    # If the last digit is '0' (DOWN), we look for the last '1'.
                    # ==================================================================
                    # PASS 1: STANDARD RUN LOGIC (LEVEL 2-5)
                    # ==================================================================
                    pivot_digit = '0' if last_digit == '1' else '1'
                    # 2. Search backward (Right-to-Left) to find the position of that "Break".
                    # EXAMPLE: In "111011", .rfind('0') finds the '0' at index 3.
                    pivot_idx = full_pos_string.rfind(pivot_digit)
                    # 3. If there is no break (the whole string is the same digit), skip this stock.
                    if pivot_idx == -1: continue
                    # 4. Grab the pattern from the "Break" to the end.
                    # EXAMPLE: From "111011", we slice from the '0' forward to get "011".
                    current_watch_pattern = full_pos_string[pivot_idx:]
                    level = len(current_watch_pattern)

                    self.stdout.write(f"  [STEP 3] Watch Pattern Found: '{current_watch_pattern}' (L{level})")
                    # Check if the level is within your required range (e.g., Level 2 to 5)
                    # If it's too low (Level 1) or too high (Level 6), we skip it immediately.
                    if not (p['min_level'] <= level <= p['max_level']):
                        self.stdout.write(self.style.WARNING(f"  [X] SKIP: {ticker} is Level {level} (Outside {p['min_level']}-{p['max_level']})"))
                        continue

                    # DATABASE VALIDATION
                    hist_matches = UpDownHistPerf.objects.filter(
                        ticker=ticker,
                        cycle=current_cycle,
                        watch_pattern=current_watch_pattern,
                        level=level
                    )

                    if not hist_matches.exists():
                        continue

                    for strat in hist_matches:
                        # Explicit Debugging variables
                        #passed_wr = strat.win_rate >= p['min_win_rate']
                        #passed_ev = strat.ev_pct >= p['min_ev']
                        #passed_samples = strat.sample_count >= p['min_samples']

                        #if passed_wr and passed_ev and passed_samples:
                        if True:
                            outcome_str, m_count = self.calculate_recent_outcomes(
                                data_list,
                                strat.target_pattern,
                                strat.trade_direction
                            )

                            # SYNCED SAVE
                            SignalMonitor.objects.update_or_create(
                                ticker=ticker,
                                cycle=current_cycle,
                                level=level,
                                recommendation=strat.trade_direction,
                                run_direction=strat.run_direction,
                                defaults={
                                    'company_name': getattr(cand, 'company_name', ticker),
                                    'last_close_price': data_list[-1]['price'],
                                    'last_close_date': data_list[-1]['date'],
                                    'recent_pos_string': full_pos_string[-30:],
                                    'trigger_digit': strat.target_pattern[-1],
                                    'win_rate': strat.win_rate,
                                    'ev_pct': strat.ev_pct,
                                    'sharpe_ratio': strat.sharpe_ratio if strat.sharpe_ratio else 0.0,
                                    'annual_return': strat.annual_compound_pct if strat.annual_compound_pct else 0.0,
                                    'sample_count': strat.sample_count if strat.sample_count else 0,
                                    'win_loss_ratio': getattr(strat, 'win_loss_ratio', 0.0),
                                    'max_consec_losses': getattr(strat, 'max_consec_losses', 0),
                                    'recent_outcome': outcome_str,
                                    'missing_count': m_count,
                                    'status': 'Waiting'
                                }
                            )
                            self.stdout.write(self.style.SUCCESS(f"  [+] SIGNAL UPDATED: {ticker} {strat.trade_direction}"))
                        else:
                            # Build specific rejection reason
                            reasons = []
                            if not passed_wr: reasons.append(f"WR: {strat.win_rate} < {p['min_win_rate']}")
                            if not passed_ev: reasons.append(f"EV: {strat.ev_pct} < {p['min_ev']}")
                            if not passed_samples: reasons.append(f"Samples: {strat.sample_count} < {p['min_samples']}")

                            self.stdout.write(self.style.WARNING(f"  [X] REJECT: {ticker} ID:{strat.id} -> " + " | ".join(reasons)))
                    # ==================================================================
                    # PASS 2: LEVEL 1 STATE LOGIC (MONTHLY TURNAROUNDS)
                    # ==================================================================
                    if p.get('min_level') == 1:
                        l1_pattern = full_pos_string[-1]  # Just the state (0 or 1)
                        l1_matches = UpDownHistPerf.objects.filter(
                            ticker=ticker, cycle=current_cycle, watch_pattern=l1_pattern, level=1
                        )
                        for strat in l1_matches:
                           # if strat.win_rate >= p['min_win_rate'] and strat.ev_pct >= p['min_ev'] and strat.sample_count >= p['min_samples']:
                            if True:  # no filter at scan time
                                outcome_str, m_count = self.calculate_recent_outcomes(data_list, strat.target_pattern, strat.trade_direction)
                                SignalMonitor.objects.update_or_create(
                                    ticker=ticker, cycle=current_cycle, level=1,
                                    recommendation=strat.trade_direction, run_direction=strat.run_direction,
                                    defaults={
                                        'company_name': getattr(cand, 'company_name', ticker),
                                        'last_close_price': data_list[-1]['price'],
                                        'last_close_date': data_list[-1]['date'],
                                        'recent_pos_string': full_pos_string[-30:],
                                        'trigger_digit': strat.target_pattern[-1],
                                        'win_rate': strat.win_rate,
                                        'ev_pct': strat.ev_pct,
                                        'sharpe_ratio': strat.sharpe_ratio if strat.sharpe_ratio else 0.0,
                                        'annual_return': strat.annual_compound_pct if strat.annual_compound_pct else 0.0,
                                        'sample_count': strat.sample_count if strat.sample_count else 0,
                                        'win_loss_ratio': getattr(strat, 'win_loss_ratio', 0.0),
                                        'max_consec_losses': getattr(strat, 'max_consec_losses', 0),
                                        'recent_outcome': outcome_str,
                                        'missing_count': m_count,
                                        'status': 'Waiting'
                                    }
                                )

                    time.sleep(0.3)

                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"  [!] ERROR {ticker}: {str(e)}"))
    def last_completed_trading_day(self):
            import pytz
            NY_TZ = pytz.timezone('America/New_York')
            now_ny = datetime.datetime.now(NY_TZ)
            cutoff = now_ny.replace(hour=16, minute=15, second=0, microsecond=0)

            candidate = now_ny.date() if now_ny >= cutoff else now_ny.date() - datetime.timedelta(days=1)

            while candidate.weekday() >= 5:
                candidate -= datetime.timedelta(days=1)

            return candidate, now_ny  # return both so we can use now_ny for logging


    def calculate_recent_outcomes(self, data_list, target_pattern, trade_direction):
        outcomes = []
        t_len = len(target_pattern)
        for i in range(0, len(data_list) - t_len):
            segment = "".join([data_list[j]['digit'] for j in range(i, i + t_len)])
            if segment == target_pattern:
                next_digit = data_list[i + t_len]['digit']
                is_win = (trade_direction == "LONG" and next_digit == "1") or \
                         (trade_direction == "SHORT" and next_digit == "0")
                outcomes.append('s' if is_win else 'f')

        res_str = "".join(outcomes[-15:])
        missing = 0
        for char in reversed(res_str):
            if char == 'f': missing += 1
            else: break
        return res_str, missing

        # ==============================================================================
#LEVEL 1 "STATE CHANGE" LOGIC BLUEPRINT
# ==============================================================================
# The following logic is NOT yet enforced in the active code.
# It serves as a reference for implementing "Level 1" Monthly or Turnaround trades.
#
# DEFINITION:
# A "Level 1" is a State Change Trigger where the DNA flips (e.g., from Red to Green).
# It requires exactly one "Pivot" digit and one "Current" digit.
#
# 1. TRIGGER PATTERNS (The "Action" setups):
#    - Pattern '01': Up-Run Trigger (Stock was Down, now it's Up).
#    - Pattern '10': Down-Run Trigger (Stock was Up, now it's Down).
#
# 2. HISTORICAL OUTCOMES (The 4 Logic Paths):
#    Once a Level 1 Trigger (01 or 10) is detected, the system evaluates:
#
#    A. CONTINUATION PATHS (Trend Following):
#       - (01 -> 1) Result DNA: '011' | Logic: Bullish Momentum Continuation.
#       - (10 -> 0) Result DNA: '100' | Logic: Bearish Momentum Continuation.
#
#    B. REVERSAL PATHS (Mean Reversion):
#       - (01 -> 0) Result DNA: '010' | Logic: Up-Run Failure / Bull-Trap.
#       - (10 -> 1) Result DNA: '101' | Logic: Down-Run Failure / Bear-Trap.
#
# 3. WHY LEVEL 1 IS POWERFUL FOR MONTHLY:
#    - On a Monthly timeframe, a '01' represents 60+ days of information.
#    - Waiting for Level 3 (0111) means 4 months of upward movement;
#      trading Level 1 (01) allows entry at the "Institutional Floor."
#
# 4. IMPLEMENTATION NOTES:
#    To activate this, the CYCLE_PARAMS for 'Monthly' must set:
#    - 'min_level': 1
#    - 'min_win_rate': 0.70 (Higher threshold required for early entries)
# ==============================================================================
#Here is a clear, structured example you can paste into the comments at the end of your midnight_scan (8).py module. It explains exactly how a single stock can generate two separate monitoring records.

#Logic Documentation Example
#Save this to the end of your module to document how the two-pass logic works:

#Python
# ==============================================================================
# LOGIC EXAMPLE: HOW TWO RECORDS ARE GENERATED FOR ONE TICKER
# ==============================================================================
# Assume Cycle = 'Monthly' (where min_level=1)
# Assume Ticker = 'AAPL'
# Assume DNA String = '1110100000' (Ends in 5 zeros)
#
# --- PASS 1: RUN DETECTION (Level 2-5) ---
# 1. Logic finds the pivot: the last '1' before the zeros.
# 2. DNA: 1 1 1 0 1 [0 0 0 0 0] -> Level = 5.
# 3. DB Check: Looks for (Ticker='AAPL', Cycle='Monthly', Level=5, Pattern='100000').
# 4. Result: If found and meets params, it creates/updates record:
#    -> ID: AAPL | Cycle: Monthly | Level: 5 | Rec: SHORT | Status: Waiting
#
# --- PASS 2: STATE DETECTION (Level 1) ---
# 1. Logic looks ONLY at the very last digit.
# 2. DNA: ...0 -> Pattern = '0'.
# 3. DB Check: Looks for (Ticker='AAPL', Cycle='Monthly', Level=1, Pattern='0').
# 4. Result: If found and meets params (e.g., 70% chance '0' flips to '1'),
#    it creates/updates record:
#    -> ID: AAPL | Cycle: Monthly | Level: 1 | Rec: LONG | Status: Waiting
#
# --- FINAL MONITORING TABLE STATE ---
# Because 'level' is a unique identifier in our update_or_create logic,
# you will now see TWO entries for AAPL:
# 1. AAPL | Monthly | Level 5 | SHORT (Trading the Down-Run continuation)
# 2. AAPL | Monthly | Level 1 | LONG  (Watching for the State-Change floor)
# =============================================================================
# PATTERN LOGIC:
# The 'Level' determines the count of the trailing digits.
#
# UpRun Type:   Starts with 0, followed by 'Level' number of 1s.
#               Level 2 -> 011
#               Level 6 -> 0111111
#
# DownRun Type: Starts with 1, followed by 'Level' number of 0s.
#               Level 3 -> 1000






# ── PRODUCTION STATUS ─────────────────────────────────────────
#
#   ACTIVE (called by run_hist_scan.py and run_hist_scanbk.py):
#     ✅ calculate_metrics()
#          The only function writing to the DB.
#          Called by the nightly hist scan to produce all
#          UpDownHistPerf rows (win_rate, sharpe, EV, etc.)
#
# ── UNUSED FUNCTIONS (not called anywhere in the project) ─────
#
#   These were built as part of an alternative "segment" approach
#   to calculating win rates. They are NOT used in production.
#   Kept here for reference only — do not delete without review.
#
#   ❌ scan_ticker_performance()
#          Newer approach using _find_simple_runs() internally.
#          Designed to replace calculate_metrics() but never
#          deployed. Uses a different annual compound formula
#          (bars_per_year method vs trades/annual_factor method).
#
#   ❌ _calculate_run_stats()
#          Helper for scan_ticker_performance() only.
#          Uses statistics.stdev() — note: NO risk-free rate
#          in Sharpe calculation (unlike calculate_metrics).
#
#   ❌ _find_simple_runs()
#          Helper for scan_ticker_performance() only.
#          Finds consecutive runs without LVP overlap logic.
#
#   ❌ segment_binary_string()
#          Original segment approach using LVP (Longest Valid
#          Pattern) with 1-char overlap. Supports level 1/2/3+
#          and alternating patterns. Not used in scan pipeline.
#
#   ❌ pattern_repeat_not_repeat()
#          Counts short/long streaks from segment list.
#          Returns 'L'/'s' sequences for last 80 segments.
#          Not used in scan pipeline.
#
#   ❌ generate_streak_recommendation()
#          Generates LONG/SHORT recommendation from streak
#          probabilities. Not used in scan pipeline.
#
#   ❌ print_segmentation_results()
#          Debug/display helper for segmentation output.
#          Not used in scan pipeline.
#
# ── KEY FORMULA NOTES (for calculate_metrics) ─────────────────
#
#   Annual Compound — rotating capital model:
#     years_equivalent = total_trades / annual_factor
#     annual = (total_mult ^ (1/years_equivalent)) - 1
#     Assumption: capital is always redeployed (never idle).
#     Answers: "what does this ticker contribute to a rotation?"
#     NOT: "what if $100 sits waiting for this ticker only?"
#
#   Sharpe Ratio — annualized, risk-free rate adjusted:
#     risk_free_per_period = 0.05 / annual_factor
#     sharpe = ((mean - risk_free) / stdev) * sqrt(annual_factor)
#     Uses sample stdev (n-1 denominator) via variance formula.
#
#   EV (Expected Value):
#     ev = (win_rate * avg_win) + ((1 - win_rate) * avg_lose)
#     Stored as decimal e.g. 0.0202 = 2.02% per trade.
#
# ── CYCLE → annual_factor MAPPING ─────────────────────────────
#
#   'daily'   → 252   (trading days per year)
#   'weekly'  → 52    (weeks per year)
#   'monthly' → 12    (months per year)
#
# ==============================================================
"""
Module: utility_string_segment_and_group_casinoStyle.py
Version: 2.18
Description: Segments a binary string into continuous (UpRun, DownRun) and alternating (Alternating) patterns, and counts streaks of short and long patterns. Supports a 'level' parameter to define short/long streak thresholds. For level=1, segments are bare runs of 1s (UpRun) or 0s (DownRun) with length as the number of consecutive identical characters. For level!=2, alternating patterns are ignored and return 'NA'. For level=2, includes continuous (length>=2) and alternating (length>=3) patterns. For level>=3, only continuous patterns (length>=level). Returns sequences of short ('s') and long ('L') streaks for the last 80 segments as strings (e.g., 'LLsLs'), ordered from oldest to newest. Streak counts for UpRun and DownRun are mutually exclusive: if Short_Streak>0, Longer=0, and vice versa. Used for trading pattern analysis. Added probabilities for 'L' and 's', and a new recommendation function.
Dependencies: None
Last Updated: 2026-02-22
"""

def is_continuous(s: str) -> bool:
    """Checks if a sequence is purely continuous (all '0's or all '1's)."""
    if not s:
        return False
    if len(s) == 1:
        return True
    return all(c == s[0] for c in s)

def is_alternating(s: str) -> bool:
    """Checks if a sequence is purely alternating (e.g., '010', '1010')."""
    if len(s) < 2:
        return False
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            return False
    return True

def is_significant_pattern(s: str, level: int) -> bool:
    """
    Checks if a pattern is significant for segmentation based on the level parameter.
    - For level=1: Any continuous run of 1s or 0s (length>=1).
    - For level=2: Continuous >= level, Alternating >= level+1.
    - For level>=3: Continuous >= level, no alternating patterns.

    Args:
        s (str): The substring to check.
        level (int): The threshold level for short streaks.

    Returns:
        bool: True if the pattern is significant, False otherwise.
    """
    if len(s) < (1 if level == 1 else level):
        return False

    if level == 1:
        return is_continuous(s)  # Any run of 1s or 0s

    if is_continuous(s):
        return len(s) >= level  # Continuous patterns significant if length >= level

    if level == 2 and is_alternating(s) and len(s) >= level + 1:
        return True  # Alternating patterns only for level=2, length >= 3

    return False

def classify_segment(s: str, level: int) -> str:
    """
    Classifies a valid segment into UpRun, DownRun, Alternating_A0, or Alternating_A1.
    For level=1: UpRun (all 1s), DownRun (all 0s).
    For level!=2: No alternating patterns.
    """
    if level == 1:
        if all(c == '1' for c in s):
            return "UpRun"
        if all(c == '0' for c in s):
            return "DownRun"
        return "Mixed"

    if is_continuous(s):
        return "UpRun" if s[0] == '1' else "DownRun"
    if level == 2 and is_alternating(s):
        return "Alternating_A1" if s[0] == '1' else "Alternating_A0"
    return "Mixed"

def segment_binary_string(input_str: str, suffix: str | None = None, level: int = 2) -> list[tuple[str, str, int]]:
    """
    Segments a binary string into runs of 1s or 0s for level=1, or using Longest Valid Pattern (LVP) with 1-char overlap for level!=1.
    For level=1, segments are bare runs of 1s (UpRun) or 0s (DownRun) with length as the number of consecutive identical characters.

    Args:
        input_str (str): Binary string to segment (e.g., "0101001")
        suffix (str | None): Optional suffix to append ('0' or '1'). Default: None
        level (int): Threshold for short streaks (default: 2). For level=1, uses bare runs of 1s or 0s.

    Returns:
        list[tuple[str, str, int]]: List of (segment, group_id, length) tuples.

    Rules:
    - For level=1: UpRun (1s, short=1, long>=2), DownRun (0s, short=1, long>=2), non-overlapping.
    - For level=2: Continuous >=2, Alternating >=3, 1-char overlap.
    - For level>=3: Continuous >=level, no alternating patterns, 1-char overlap.
    - Adds suffix to input string before segmentation if provided.
    """
    # Validate level
    if not isinstance(level, int) or level < 1:
        raise ValueError("Level must be a positive integer")

    # Validate and apply suffix
    if suffix is not None:
        if suffix not in ['0', '1']:
            raise ValueError("Suffix must be '0' or '1' if provided")
        processed_str = input_str + suffix
        print(f"Applied suffix '{suffix}': '{input_str}' → '{processed_str}'")
    else:
        processed_str = input_str

    n = len(processed_str)
    if n == 0:
        return []

    segments = []

    if level == 1:
        # Segment into bare runs of 1s (UpRun) or 0s (DownRun)
        i = 0
        while i < n:
            start = i
            current_char = processed_str[i]
            # Count consecutive identical characters
            while i < n and processed_str[i] == current_char:
                i += 1
            segment = processed_str[start:i]
            group_id = "UpRun" if current_char == '1' else "DownRun"
            length = len(segment)
            segments.append((segment, group_id, length))
            print(f"Selected segment: '{segment}' | {group_id} | Length: {length} | Start: {start} | End: {i}")

        return segments

    # LVP approach for level != 1
    L_pointer = 0
    iteration_count = 0
    max_iterations = n * 2

    while L_pointer < n and iteration_count < max_iterations:
        iteration_count += 1
        max_length = n - L_pointer
        longest_valid_segment = ""
        found_valid_segment = False

        # Try longest SIGNIFICANT patterns first
        for length in range(max_length, level - 1, -1):
            current_substring = processed_str[L_pointer:L_pointer + length]

            if is_significant_pattern(current_substring, level):
                longest_valid_segment = current_substring
                found_valid_segment = True
                break

        if not found_valid_segment:
            L_pointer += 1
            continue

        segment_length = len(longest_valid_segment)
        group_id = classify_segment(longest_valid_segment, level)
        segments.append((longest_valid_segment, group_id, segment_length))

        # Advance with 1-char overlap
        L_pointer += max(1, segment_length - 1)

    # Final cleanup: remove trailing segments shorter than minimum length
    min_length = level
    while segments and len(segments[-1][0]) < min_length:
        segments = segments[:-1]

    if iteration_count >= max_iterations:
        raise ValueError("Max iterations reached. Possible infinite loop.")

    return segments

def pattern_repeat_not_repeat(input_str: str, segments: list[tuple[str, str, int]], repeat_threshold: int = 3, not_repeat_threshold: int = 3, level: int = 2) -> dict:
    """
    Counts streaks of short and long patterns from newest to oldest.
    Returns sequences of short ('s') and long ('L') streaks for the last 80 segments as strings.
    - For level=1: UpRun/DownRun (short=1, long>=2), Alternating='NA'.
    - For level=2: UpRun/DownRun (length=2 short, >=3 long), Alternating (length=3 short, >3 long).
    - For level>=3: UpRun/DownRun (length=level short, >level long), Alternating='NA'.
    Streak counts are mutually exclusive: if Short_Streak>0, Longer=0, and vice versa.

    Args:
        input_str (str): Original binary string.
        segments (list[tuple[str, str, int]]): List of (segment, group_id, length) tuples.
        repeat_threshold (int): Threshold for streak counts (default: 3).
        not_repeat_threshold (int): Threshold for longer counts (default: 3).
        level (int): Threshold for short streaks (default: 2).

    Returns:
        dict: Counts and sequences for UpRun, DownRun, and Alternating patterns.
    """
    # Validate level
    if not isinstance(level, int) or level < 1:
        raise ValueError("Level must be a positive integer")

    counts = {
        "UpRun_Short_Streak": 0,
        "UpRun_Longer": 0,
        "UpRun Short Long List (last 80)": "",
        "DownRun_Short_Streak": 0,
        "DownRun_Longer": 0,
        "DownRun Short Long List (last 80)": "",
        "Alternating_Short_Streak": "NA" if level != 2 else 0,
        "Alternating_Longer": "NA" if level != 2 else 0,
        "Alternating Short Long List (last 80)": "NA" if level != 2 else ""
    }

    # Lists to store short/long sequences for each group type
    uprun_list = []
    downrun_list = []
    alternating_list = [] if level == 2 else None

    # Reverse segments to scan from newest to oldest
    segments = segments[::-1]

    # Build sequence lists based on level
    for i, (seq, group_id, length) in enumerate(segments):
        if level == 1:
            if group_id == "UpRun":
                label = "s" if length == 1 else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == 1 else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")
        elif level == 2:
            if group_id == "UpRun":
                label = "s" if length == 2 else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == 2 else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")
            elif group_id in ("Alternating_A0", "Alternating_A1"):
                label = "s" if length == 3 else "L"
                alternating_list.append(label)
                print(f"Alternating segment {i} ({seq}, length={length}): {label}")
        else:  # level >= 3
            if group_id == "UpRun":
                label = "s" if length == level else "L"
                uprun_list.append(label)
                print(f"UpRun segment {i} ({seq}, length={length}): {label}")
            elif group_id == "DownRun":
                label = "s" if length == level else "L"
                downrun_list.append(label)
                print(f"DownRun segment {i} ({seq}, length={length}): {label}")

    # Reverse lists to order from oldest to newest
    uprun_list = uprun_list[::-1]
    downrun_list = downrun_list[::-1]
    if level == 2:
        alternating_list = alternating_list[::-1]

    # Join the last 80 elements (or fewer) into strings
    counts["UpRun Short Long List (last 80)"] = "".join(uprun_list[-80:])
    counts["DownRun Short Long List (last 80)"] = "".join(downrun_list[-80:])
    if level == 2:
        counts["Alternating Short Long List (last 80)"] = "".join(alternating_list[-80:])

    print(f"UpRun sequence (oldest to newest): {counts['UpRun Short Long List (last 80)']}")
    print(f"DownRun sequence (oldest to newest): {counts['DownRun Short Long List (last 80)']}")
    print(f"Alternating sequence (oldest to newest): {counts['Alternating Short Long List (last 80)']}")

    # Add probabilities for 'L' and 's'
    min_samples = 10
    # UpRun
    uprun_total = len(uprun_list)
    if uprun_total >= min_samples:
        counts["UpRun_Prob_L"] = uprun_list.count('L') / uprun_total
        counts["UpRun_Prob_s"] = 1 - counts["UpRun_Prob_L"]
    else:
        counts["UpRun_Prob_L"] = "Insufficient Data"
        counts["UpRun_Prob_s"] = "Insufficient Data"
    # DownRun
    downrun_total = len(downrun_list)
    if downrun_total >= min_samples:
        counts["DownRun_Prob_L"] = downrun_list.count('L') / downrun_total
        counts["DownRun_Prob_s"] = 1 - counts["DownRun_Prob_L"]
    else:
        counts["DownRun_Prob_L"] = "Insufficient Data"
        counts["DownRun_Prob_s"] = "Insufficient Data"
    # Alternating
    if level == 2:
        alternating_total = len(alternating_list)
        if alternating_total >= min_samples:
            counts["Alternating_Prob_L"] = alternating_list.count('L') / alternating_total
            counts["Alternating_Prob_s"] = 1 - counts["Alternating_Prob_L"]
        else:
            counts["Alternating_Prob_L"] = "Insufficient Data"
            counts["Alternating_Prob_s"] = "Insufficient Data"
    else:
        counts["Alternating_Prob_L"] = "NA"
        counts["Alternating_Prob_s"] = "NA"

    # Streak counting by level
    if level == 1:
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == 1:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == 1:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length >= 2
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] >= 2:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break

        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == 1:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == 1:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length >= 2
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] >= 2:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break

    elif level == 2:
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == 2:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == 2:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length >= 3
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] >= 3:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break

        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == 2:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == 2:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length >= 3
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] >= 3:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break

        # Alternating streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id not in ("Alternating_A0", "Alternating_A1"):
                continue
            if length == 3:
                counts["Alternating_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] not in ("Alternating_A0", "Alternating_A1"):
                        continue
                    if segments[j][2] == 3:
                        counts["Alternating_Short_Streak"] += 1
                    else:
                        break
                counts["Alternating_Longer"] = 0
                break
            else:  # length > 3
                counts["Alternating_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] not in ("Alternating_A0", "Alternating_A1"):
                        continue
                    if segments[j][2] > 3:
                        counts["Alternating_Longer"] += 1
                    else:
                        break
                counts["Alternating_Short_Streak"] = 0
                break

    else:  # level >= 3
        # UpRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "UpRun":
                continue
            if length == level:
                counts["UpRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] == level:
                        counts["UpRun_Short_Streak"] += 1
                    else:
                        break
                counts["UpRun_Longer"] = 0
                break
            else:  # length > level
                counts["UpRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "UpRun":
                        continue
                    if segments[j][2] > level:
                        counts["UpRun_Longer"] += 1
                    else:
                        break
                counts["UpRun_Short_Streak"] = 0
                break

        # DownRun streaks
        for i, (_, group_id, length) in enumerate(segments):
            if group_id != "DownRun":
                continue
            if length == level:
                counts["DownRun_Short_Streak"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] == level:
                        counts["DownRun_Short_Streak"] += 1
                    else:
                        break
                counts["DownRun_Longer"] = 0
                break
            else:  # length > level
                counts["DownRun_Longer"] = 1
                for j in range(i + 1, len(segments)):
                    if segments[j][1] != "DownRun":
                        continue
                    if segments[j][2] > level:
                        counts["DownRun_Longer"] += 1
                    else:
                        break
                counts["DownRun_Short_Streak"] = 0
                break

    return counts

def generate_streak_recommendation(segments: list[tuple[str, str, int]], counts: dict, level: int, rec_threshold: float = 0.6, strong_threshold: float = 0.7) -> str:
    """
    Generates a recommendation based on the most recent segment and historical probabilities.
    Ignores alternating patterns. Only considers UpRun and DownRun.
    Recommends chasing continuation ('L') or reversal ('s') if probabilities meet thresholds.

    Args:
        segments (list[tuple[str, str, int]]): List of segments from segment_binary_string.
        counts (dict): Dictionary from pattern_repeat_not_repeat, including probs.
        level (int): The level used for segmentation.
        rec_threshold (float): Threshold for 'recommend' (default: 0.6).
        strong_threshold (float): Threshold for 'strong recommend' (default: 0.7).

    Returns:
        str: Recommendation string or "No recommendation."
    """
    if not segments:
        return "No segments available - No recommendation."

    last_segment, last_group, last_length = segments[-1]

    if last_group in ("Alternating_A0", "Alternating_A1", "Mixed"):
        return "Current pattern is alternating or mixed - No recommendation."

    # Determine short length threshold
    if level == 1:
        short_len = 1
    elif level == 2:
        short_len = 2
    else:
        short_len = level

    if last_length != short_len:
        return "Current segment not at short length - No recommendation."

    rec = []

    if last_group == "UpRun":
        prob_L = counts.get("UpRun_Prob_L")
        prob_s = counts.get("UpRun_Prob_s")
        if isinstance(prob_L, str):  # Insufficient Data
            return "Insufficient data for UpRun - No recommendation."

        if prob_L >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 1 (extend UpRun, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        elif prob_L >= rec_threshold:
            rec.append(f"Recommend: Chase 1 (extend UpRun, {prob_L*100:.1f}% historical Prob_L at level={level}).")

        if prob_s >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 0 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
        elif prob_s >= rec_threshold:
            rec.append(f"Recommend: Chase 0 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")

    elif last_group == "DownRun":
        prob_L = counts.get("DownRun_Prob_L")
        prob_s = counts.get("DownRun_Prob_s")
        if isinstance(prob_L, str):  # Insufficient Data
            return "Insufficient data for DownRun - No recommendation."

        if prob_L >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 0 (extend DownRun/short, {prob_L*100:.1f}% historical Prob_L at level={level}).")
        elif prob_L >= rec_threshold:
            rec.append(f"Recommend: Chase 0 (extend DownRun/short, {prob_L*100:.1f}% historical Prob_L at level={level}).")

        if prob_s >= strong_threshold:
            rec.append(f"Strong Recommend: Chase 1 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")
        elif prob_s >= rec_threshold:
            rec.append(f"Recommend: Chase 1 (reverse, {prob_s*100:.1f}% historical Prob_s at level={level}).")

    if rec:
        return "\n".join(rec)
    else:
        return "No clear recommendation - probabilities below threshold."

def print_segmentation_results(input_str: str, segments: list[tuple[str, str, int]], suffix: str | None = None):
    """Utility function to print segmentation results."""
    original_input = input_str if suffix is None else f"{input_str}+{suffix}"
    print(f"\n--- Segmentation Results ---")
    print(f"Original Input: '{original_input}'")
    if suffix:
        print(f"Processed Input: '{input_str + suffix}'")
    print(f"Total segments: {len(segments)}")

    for i, (seq, group, length) in enumerate(segments):
        print(f"Segment {i+1}: '{seq}' | Group ID: {group} | Length: {length}")

    if segments:
        print(f"\nResulting List of Tuples: {segments}")
    else:
        print("No significant segments found.")

# ==============================================================
# NEW FUNCTIONS — VERSION 3.00
# Added: scan_ticker_performance() and its helper functions
# All original functions above are completely unchanged.
# ==============================================================

# We need 'statistics' for mean and standard deviation calculation.
# This is a built-in Python module — no pip install needed.
import statistics


def _find_simple_runs(binary_string: str) -> list[tuple[str, int, int]]:
    """
    HELPER FUNCTION (private, used only inside this module).
    The underscore _ at the start means "internal use only".

    Finds all consecutive runs of identical digits in the binary string.
    This is simpler than segment_binary_string() — no overlap, no LVP.
    We just group consecutive identical characters together.

    Why a separate function?
        The existing segment_binary_string() uses LVP (Longest Valid Pattern)
        with overlap, which is designed for the original streak analysis.
        For the trade performance scan, we need simple consecutive runs
        so we can apply the trade rule:
            "enter at the level-th bar of each run"
        Simple runs give us clean start/end indices for each run.

    Example:
        binary_string = "110011101"
        Returns:
          [
            ("11",  "UpRun",   start=0, end=1),   ← 2 consecutive 1s
            ("00",  "DownRun", start=2, end=3),   ← 2 consecutive 0s
            ("111", "UpRun",   start=4, end=6),   ← 3 consecutive 1s
            ("0",   "DownRun", start=7, end=7),   ← 1 zero
            ("1",   "UpRun",   start=8, end=8),   ← 1 one
          ]

    Args:
        binary_string (str): The 1/0 string, oldest to newest.
                             NOTE: This is the 1/0 string ONLY (no index 0).
                             Index 0 in binary_string = index 1 in close_prices.

    Returns:
        list of tuples: (segment_str, direction, start_index, end_index)
            segment_str  : the actual characters e.g. "111"
            direction    : "UpRun" (all 1s) or "DownRun" (all 0s)
            start_index  : position in binary_string where run starts
            end_index    : position in binary_string where run ends (inclusive)
    """
    runs = []       # we will build this list and return it
    n    = len(binary_string)

    if n == 0:
        return runs     # empty string → return empty list

    i = 0
    while i < n:
        # Remember where this run starts
        start      = i
        current    = binary_string[i]   # '1' or '0'

        # Keep moving forward while the character stays the same
        while i < n and binary_string[i] == current:
            i += 1

        # i has now moved past the end of this run
        end          = i - 1            # last index of this run (inclusive)
        segment_str  = binary_string[start:i]
        direction    = "UpRun" if current == '1' else "DownRun"

        runs.append((segment_str, direction, start, end))

    return runs


def _calculate_run_stats(
    returns_all  : list[float],
    win_rate     : float,
    cycle_days   : int,
    total_bars   : int,
) -> dict:
    """
    HELPER FUNCTION (private).

    Given a list of trade returns and a win rate, calculates all
    performance statistics needed for one DB row.

    Args:
        returns_all (list[float]):
            All trade returns as decimals (not %).
            e.g. [0.037, -0.077, 0.035, -0.069]
            Positive = profit, negative = loss.
            Already adjusted for trade_direction
            (LONG: positive when price up,
             SHORT: positive when price down).

        win_rate (float):
            The historical win rate as a decimal.
            e.g. 0.70 means 70% of trades were profitable.
            This is cont_prob or rev_prob depending on combination.

        cycle_days (int):
            Length of one bar in trading days.
            1  = daily,  5 = weekly,  20 = 20-day cycle.
            Used to calculate annual compound return.

        total_bars (int):
            Total number of bars in the binary string.
            Used to estimate years of history.

    Returns:
        dict with all performance metrics, or error dict if insufficient data.
    """

    # ── Minimum sample check ─────────────────────────────────────────
    # With fewer than 10 trades, statistics are not meaningful.
    # Like flipping a coin 3 times — tells you nothing reliable.
    min_samples = 10
    if len(returns_all) < min_samples:
        return {
            "error"        : f"Insufficient data: {len(returns_all)} trades, need {min_samples}+",
            "sample_count" : len(returns_all),
        }

    # ── Separate wins and losses ──────────────────────────────────────
    # WIN  = positive return (trade was profitable)
    # LOSE = negative or zero return
    win_returns  = [r for r in returns_all if r > 0]
    lose_returns = [r for r in returns_all if r <= 0]

    # ── Average returns ───────────────────────────────────────────────
    # statistics.mean() = sum / count
    # If no wins or no losses, use 0.0 to avoid errors
    avg_return   = statistics.mean(returns_all)
    avg_win      = statistics.mean(win_returns)  if win_returns  else 0.0
    avg_lose     = statistics.mean(lose_returns) if lose_returns else 0.0

    # ── Win / Loss ratio ─────────────────────────────────────────────
    # How big are wins vs losses?
    # abs() makes both positive before dividing
    # Example: avg_win=3.64%, avg_lose=-7.28% → ratio = 3.64/7.28 = 0.50
    # Ratio > 1.0 means wins are bigger than losses (good)
    # Ratio < 1.0 means losses are bigger than wins (need high win rate)
    win_loss_ratio = (
        abs(avg_win) / abs(avg_lose)
        if avg_lose != 0
        else 0.0
    )

    # ── Expected Value (EV) ──────────────────────────────────────────
    # The average profit we expect per trade over many trades.
    # Formula: (win_rate × avg_win) + ((1 - win_rate) × avg_lose)
    # Positive EV = profitable edge  ✅
    # Negative EV = losing strategy  ❌
    ev = (win_rate * avg_win) + ((1 - win_rate) * avg_lose)

    # ── Standard Deviation ───────────────────────────────────────────
    # Measures how consistent the returns are.
    # Low std_dev = consistent returns (good, predictable)
    # High std_dev = returns vary wildly (risky)
    # Need at least 2 data points for std_dev
    std_dev = (
        statistics.stdev(returns_all)
        if len(returns_all) > 1
        else 0.0
    )

    # ── Sharpe Ratio ─────────────────────────────────────────────────
    # EV divided by standard deviation.
    # Measures the QUALITY of the edge — not just size but consistency.
    # > 1.0  = very consistent, reliable edge  ✅
    # 0.5-1.0 = moderate, some variance        ⚠️
    # < 0.5  = too volatile, risky             ❌
    sharpe = ev / std_dev if std_dev > 0 else 0.0

    # ── Max Loss ─────────────────────────────────────────────────────
    # The single worst trade in history.
    # Important for risk management — know the worst case scenario.
    max_loss = min(returns_all)     # min() finds the most negative value

    # ── Annual Compound Return ────────────────────────────────────────
    # How much would $1 grow to in one year if we traded this system?
    #
    # Step 1: How many bars = 1 year?
    #   daily  (cycle_days=1):  252 trading days = 1 year
    #   weekly (cycle_days=5):  52  weeks         = 1 year
    #   20-day (cycle_days=20): 252/20 = 12.6 periods = 1 year
    bars_per_year = 252 / cycle_days

    # Step 2: How many years of history do we have?
    #   total_bars = length of binary_string
    #   e.g. 500 daily bars / 252 = ~2 years
    years_of_history = total_bars / bars_per_year

    # Step 3: How many trades per year on average?
    #   sample_count / years_of_history
    #   e.g. 47 trades / 2 years = 23.5 trades per year
    trades_per_year = (
        len(returns_all) / years_of_history
        if years_of_history > 0
        else 0
    )

    # Step 4: Compound the average return over trades_per_year
    #   Formula: (1 + avg_return) ^ trades_per_year - 1
    #   e.g. (1 + 0.018) ^ 23.5 - 1 = 0.530 = +53% per year
    #
    # Special case: if avg_return <= -1 (lost everything), return -100%
    if avg_return <= -1:
        annual_compound = -1.0
    else:
        annual_compound = ((1 + avg_return) ** trades_per_year) - 1

    # ── Return all metrics as a dict ──────────────────────────────────
    # All % values multiplied by 100 for readability:
    #   0.018 → 1.80  (easier to read as percentage)
    return {
        "win_rate"            : round(win_rate,                    4),  # e.g. 0.7000
        "avg_return_pct"      : round(avg_return    * 100,         4),  # e.g. 1.80
        "avg_win_pct"         : round(avg_win       * 100,         4),  # e.g. 3.64
        "avg_lose_pct"        : round(avg_lose      * 100,         4),  # e.g. -7.28
        "win_loss_ratio"      : round(win_loss_ratio,              4),  # e.g. 0.50
        "ev_pct"              : round(ev             * 100,        4),  # e.g. 0.75
        "sharpe_ratio"        : round(sharpe,                      4),  # e.g. 1.20
        "max_loss_pct"        : round(max_loss       * 100,        4),  # e.g. -17.24
        "annual_compound_pct" : round(annual_compound * 100,       4),  # e.g. 15.30
        "sample_count"        : len(returns_all),                       # e.g. 47
        "error"               : None,   # None means success
    }


def scan_ticker_performance(
    binary_string  : str,
    close_prices   : list,
    change_pcts    : list,
    dates          : list,
    level_set      : list,
    cycle_days     : int,
) -> list:
    """
    MAIN NEW FUNCTION — Version 3.00

    Scans a ticker's full price history and calculates performance statistics
    for every combination of level × run_direction × trade_direction.

    This is the function the nightly/weekly scan module will call.
    It returns a list of dicts — one per combination — ready to save to DB.

    ── HOW IT WORKS ────────────────────────────────────────────────────

    Step 1: Find all simple consecutive runs in the binary string.
            e.g. "110011101" → [("11","UpRun",0,1), ("00","DownRun",2,3), ...]

    Step 2: For each level in level_set [2,3,4,5]:
              For each run (UpRun or DownRun):
                If run length >= level → QUALIFIED SEGMENT
                  Entry index N = run_start + level - 1
                  Exit  index   = N + 1
                  Collect: entry_price, exit_price, change_pct, date

    Step 3: For each (level × run_direction) pair,
            build TWO rows — one LONG, one SHORT:
              LONG:  win  when exit > entry  (bet on continuation for UpRun)
              SHORT: win  when exit < entry  (bet on reversal  for UpRun)

    Step 4: Calculate all statistics for each row using _calculate_run_stats()

    Step 5: Return list of dicts ready for DB saving.

    ── INPUT PARAMETERS ────────────────────────────────────────────────

    Args:
        binary_string (str):
            1/0 string, oldest to newest, starting from index 1.
            e.g. "110011101111001110011"
            Length = len(close_prices) - 1
            (because index 0 has no digit — no previous price to compare)

        close_prices (list[float]):
            Close price for every bar, oldest to newest.
            Index 0 = first bar (no digit).
            Index 1 = second bar (first digit in binary_string).
            MUST be same length as binary_string + 1.
            e.g. [90.0, 100.0, 102.0, 95.0, ...]

        change_pcts (list[float or None]):
            % change for every bar, oldest to newest.
            Index 0 = None (no previous price).
            Index 1 onward = (close[i] - close[i-1]) / close[i-1] * 100
            e.g. [None, 11.11, 2.00, -6.86, ...]

        dates (list[str or None]):
            Date string for every bar, oldest to newest.
            Optional — pass None or empty list if not available.
            Used only in trade_position_detail for human verification.
            e.g. ["2026-01-02", "2026-01-03", ...]

        level_set (list[int]):
            Which levels to scan.
            e.g. [2, 3, 4, 5]
            For each level, 4 rows are produced (2 directions × 2 trades).

        cycle_days (int):
            Length of one bar in calendar trading days.
            1  = daily bars
            5  = weekly bars
            20 = 20-day bars
            Used to calculate annual compound return.

    ── RETURN VALUE ────────────────────────────────────────────────────

    Returns:
        list[dict]: One dict per (level × run_direction × trade_direction).
        Total rows = len(level_set) × 2 × 2 = 16 rows for level_set=[2,3,4,5].

        Each dict contains:
        {
            # Identity (what combination this row represents)
            "level"               : 2,
            "run_direction"       : "UpRun",
            "trade_direction"     : "LONG",

            # Performance metrics (None if insufficient data)
            "win_rate"            : 0.70,
            "avg_return_pct"      : 1.80,
            "avg_win_pct"         : 3.64,
            "avg_lose_pct"        : -7.28,
            "win_loss_ratio"      : 0.50,
            "ev_pct"              : 0.75,
            "sharpe_ratio"        : 1.20,
            "max_loss_pct"        : -17.24,
            "annual_compound_pct" : 15.30,
            "sample_count"        : 47,
            "error"               : None,   # or error message string

            # Full trade history for DB verification
            "trade_position_detail": [
                {
                    "entry_index"   : 2,
                    "exit_index"    : 3,
                    "entry_date"    : "2026-01-04",
                    "exit_date"     : "2026-01-05",
                    "entry_price"   : 102.0,
                    "exit_price"    : 95.0,
                    "change_pct"    : -6.86,
                    "segment_label" : "rev",
                    "win_lose"      : "LOSE",
                },
                ...
            ],
        }

    ── IMPORTANT NOTES ─────────────────────────────────────────────────
    - Index alignment:
        binary_string[0] corresponds to close_prices[1]
        binary_string[i] corresponds to close_prices[i+1]
        This offset of 1 exists because index 0 has no digit.

    - Most recent signal:
        The last qualified segment may have no N+1 bar yet.
        This is skipped from statistics but IS noted in results
        as the current live signal.

    - Cycle agnostic:
        Uses index N and N+1 only. Never hardcodes "next day".
        Works for daily, weekly, 20-day, or any other cycle.
    """

    # ── Validate inputs ───────────────────────────────────────────────
    if not binary_string:
        print("WARNING: empty binary_string passed to scan_ticker_performance")
        return []

    # close_prices has one extra element (index 0, no digit)
    # so its length should be len(binary_string) + 1
    expected_close_len = len(binary_string) + 1
    if len(close_prices) != expected_close_len:
        print(f"WARNING: close_prices length {len(close_prices)} "
              f"expected {expected_close_len} "
              f"(binary_string length {len(binary_string)} + 1)")
        return []

    # ── Step 1: Find all simple consecutive runs ──────────────────────
    # This gives us every UpRun and DownRun segment with start/end indices.
    # These indices are positions in the BINARY STRING (0-based).
    # To convert to close_prices index: add 1 (because of the offset).
    #
    # Example:
    #   binary_string = "110011"
    #   runs[0] = ("11", "UpRun", start=0, end=1)
    #   close_prices index for entry = 0 + 1 + 1 = 2  (binary index + offset + 0-based)
    runs = _find_simple_runs(binary_string)

    # Total number of bars = length of close_prices
    # Used for annual compound return calculation
    total_bars = len(close_prices)

    # If dates array is empty or None, create a None array of same length
    # so we don't need to check "if dates" everywhere below
    if not dates:
        dates = [None] * len(close_prices)

    # ── Step 2: For each level, collect trade positions ───────────────
    # We scan each level separately.
    # For each level, we collect positions for UpRun and DownRun separately.
    #
    # Data structure for collecting positions:
    #   positions_by_combo[(level, run_direction)] = list of position dicts
    #
    # We store RAW position data here (prices, dates, segment_label).
    # We calculate LONG/SHORT returns later in Step 3.
    positions_by_combo = {}     # key=(level, run_direction), value=list of dicts

    for level in level_set:

        # Validate level
        if not isinstance(level, int) or level < 2:
            print(f"WARNING: invalid level {level}, skipping")
            continue

        # Initialize empty lists for this level
        for run_dir in ["UpRun", "DownRun"]:
            positions_by_combo[(level, run_dir)] = []

        # Walk through every run found in Step 1
        for (seg_str, run_dir, bs_start, bs_end) in runs:

            run_length = len(seg_str)

            # ── Qualification check ───────────────────────────────────
            # Only process if this run reached the required level length.
            # e.g. level=3: "11" (length 2) is NOT qualified
            #               "111" (length 3) IS qualified
            #               "1111" (length 4) IS qualified
            if run_length < level:
                continue    # skip this run, never reached level

            # ── Calculate entry index ─────────────────────────────────
            # Entry is at the level-th bar of this run.
            # Formula: entry in binary_string = bs_start + level - 1
            # Formula: entry in close_prices  = bs_start + level - 1 + 1
            #                                 = bs_start + level
            #
            # Why +1 offset?
            #   binary_string[0] = close_prices[1]
            #   binary_string[i] = close_prices[i + 1]
            #
            # Example:
            #   Run "1111" starts at bs_start=10, level=2
            #   Entry in binary_string = 10 + 2 - 1 = 11
            #   Entry in close_prices  = 11 + 1     = 12
            entry_bs_idx     = bs_start + level - 1    # index in binary_string
            entry_price_idx  = entry_bs_idx + 1        # index in close_prices
            exit_price_idx   = entry_price_idx + 1     # next bar in close_prices

            # ── Check if exit bar exists ──────────────────────────────
            # If entry is the last bar in close_prices, there is no exit.
            # This is the MOST RECENT signal — no N+1 data yet.
            # We skip it from statistics (noted separately as live signal).
            if exit_price_idx >= len(close_prices):
                print(f"  Level {level} {run_dir}: most recent signal at "
                      f"entry_price_idx={entry_price_idx} — no exit bar yet, "
                      f"this is the current live signal")
                continue

            # ── Get prices and dates ──────────────────────────────────
            entry_price = close_prices[entry_price_idx]
            exit_price  = close_prices[exit_price_idx]

            # Safety check — entry price must be positive for return calc
            if not entry_price or entry_price <= 0:
                print(f"  WARNING: invalid entry_price {entry_price} "
                      f"at index {entry_price_idx}, skipping")
                continue

            # Get change_pct at EXIT bar (what the market actually did)
            # This is the raw market move, always positive=up, negative=down
            exit_change_pct = change_pcts[exit_price_idx] if change_pcts else None

            # Get dates if available
            entry_date = dates[entry_price_idx] if dates else None
            exit_date  = dates[exit_price_idx]  if dates else None

            # ── Segment label: "cont" or "rev" ────────────────────────
            # "cont" = continuation = run length > level
            #          the run CONTINUED past the level length
            # "rev"  = reversal     = run length == level
            #          the run STOPPED at exactly the level length
            # Note: This is a PATTERN label, NOT the trade outcome.
            #       A "cont" segment can still produce a losing trade!
            segment_label = "cont" if run_length > level else "rev"

            # ── Build the raw position record ─────────────────────────
            # This stores the FACTS of what happened.
            # win_lose is added later (Step 3) when we know trade_direction.
            position = {
                "entry_index"    : entry_price_idx,     # index in close_prices
                "exit_index"     : exit_price_idx,      # index in close_prices
                "entry_date"     : str(entry_date) if entry_date else None,
                "exit_date"      : str(exit_date)  if exit_date  else None,
                "entry_price"    : round(float(entry_price), 4),
                "exit_price"     : round(float(exit_price),  4),
                "change_pct"     : round(float(exit_change_pct), 4) if exit_change_pct is not None else None,
                "segment_label"  : segment_label,
                # win_lose added in Step 3 below
            }

            # Store in our collector
            positions_by_combo[(level, run_dir)].append(position)

    # ── Step 3: Build results for each combination ────────────────────
    # For each (level × run_direction), produce TWO rows:
    #   Row 1: trade_direction = LONG
    #   Row 2: trade_direction = SHORT
    #
    # LONG and SHORT use the SAME trade positions but different return calcs:
    #   LONG  return = (exit - entry) / entry  (positive when price goes up)
    #   SHORT return = (entry - exit) / entry  (positive when price goes down)

    results = []    # final list to return

    for level in level_set:

        if not isinstance(level, int) or level < 2:
            continue

        for run_dir in ["UpRun", "DownRun"]:

            raw_positions = positions_by_combo.get((level, run_dir), [])

            if not raw_positions:
                # No qualified segments found for this combo
                # Still add a row so the DB has a record
                for trade_dir in ["LONG", "SHORT"]:
                    results.append({
                        "level"                : level,
                        "run_direction"        : run_dir,
                        "trade_direction"      : trade_dir,
                        "win_rate"             : None,
                        "avg_return_pct"       : None,
                        "avg_win_pct"          : None,
                        "avg_lose_pct"         : None,
                        "win_loss_ratio"       : None,
                        "ev_pct"               : None,
                        "sharpe_ratio"         : None,
                        "max_loss_pct"         : None,
                        "annual_compound_pct"  : None,
                        "sample_count"         : 0,
                        "error"                : "No qualified segments found",
                        "trade_position_detail": [],
                    })
                continue

            # ── Calculate cont_prob and rev_prob ──────────────────────
            # These are the RAW pattern probabilities from segment lengths.
            # cont_prob = how often run continued past level
            # rev_prob  = how often run stopped at level = 1 - cont_prob
            total_segs = len(raw_positions)
            cont_count = sum(1 for p in raw_positions if p["segment_label"] == "cont")
            rev_count  = total_segs - cont_count

            cont_prob  = cont_count / total_segs    # e.g. 0.70
            rev_prob   = rev_count  / total_segs    # e.g. 0.30 = 1 - cont_prob

            # ── Process each trade direction ──────────────────────────
            for trade_dir in ["LONG", "SHORT"]:

                # ── Determine win_rate for this combination ───────────
                # win_rate IS cont_prob or rev_prob depending on combo:
                #
                #   UpRun   + LONG  → betting continuation → win_rate = cont_prob
                #   UpRun   + SHORT → betting reversal     → win_rate = rev_prob
                #   DownRun + SHORT → betting continuation → win_rate = cont_prob
                #   DownRun + LONG  → betting reversal     → win_rate = rev_prob
                #
                # Logic: LONG on UpRun = betting it goes UP again = continuation
                #        SHORT on UpRun = betting it reverses DOWN = reversal
                #        SHORT on DownRun = betting it goes DOWN again = continuation
                #        LONG on DownRun = betting it reverses UP = reversal
                if (run_dir == "UpRun"   and trade_dir == "LONG") or \
                   (run_dir == "DownRun" and trade_dir == "SHORT"):
                    win_rate = cont_prob    # betting on continuation
                else:
                    win_rate = rev_prob     # betting on reversal

                # ── Calculate return for each position ────────────────
                # Build the trade_position_detail list for this row.
                # Each position gets a win_lose field based on trade_direction.
                trade_positions = []    # positions with win_lose added
                returns_all     = []    # list of returns for statistics

                for pos in raw_positions:

                    ep = pos["entry_price"]
                    xp = pos["exit_price"]

                    # Calculate return based on trade direction:
                    #
                    # LONG:  profit when price goes UP
                    #   return = (exit - entry) / entry
                    #   positive → price went up   → WIN
                    #   negative → price went down → LOSE
                    #
                    # SHORT: profit when price goes DOWN
                    #   return = (entry - exit) / entry  ← inverted
                    #   positive → price went down → WIN
                    #   negative → price went up   → LOSE
                    if trade_dir == "LONG":
                        trade_return = (xp - ep) / ep
                    else:   # SHORT
                        trade_return = (ep - xp) / ep

                    # WIN or LOSE for this trade
                    win_lose = "WIN" if trade_return > 0 else "LOSE"

                    # Build the complete position record for DB
                    pos_record = {
                        "entry_index"   : pos["entry_index"],
                        "exit_index"    : pos["exit_index"],
                        "entry_date"    : pos["entry_date"],
                        "exit_date"     : pos["exit_date"],
                        "entry_price"   : pos["entry_price"],
                        "exit_price"    : pos["exit_price"],
                        "change_pct"    : pos["change_pct"],
                        "segment_label" : pos["segment_label"],
                        "win_lose"      : win_lose,
                        "return_pct"    : round(trade_return * 100, 4),
                    }

                    trade_positions.append(pos_record)
                    returns_all.append(trade_return)

                # ── Calculate statistics ──────────────────────────────
                stats = _calculate_run_stats(
                    returns_all  = returns_all,
                    win_rate     = win_rate,
                    cycle_days   = cycle_days,
                    total_bars   = total_bars,
                )

                # ── Build the final result dict for this row ──────────
                # This is one row in sys_UpDownPerf table.
                # The caller (scan module) will add "ticker" and "cycle"
                # before saving to DB.
                row = {
                    # ── Identity ──────────────────────────────────────
                    "level"                : level,
                    "run_direction"        : run_dir,
                    "trade_direction"      : trade_dir,

                    # ── Win rate ──────────────────────────────────────
                    # One value only — fully determined by the 3 keys above.
                    # cont_prob and rev_prob are NOT stored separately.
                    "win_rate"             : round(win_rate, 4),

                    # ── Performance metrics ───────────────────────────
                    # None if insufficient data (stats["error"] is not None)
                    "avg_return_pct"       : stats.get("avg_return_pct"),
                    "avg_win_pct"          : stats.get("avg_win_pct"),
                    "avg_lose_pct"         : stats.get("avg_lose_pct"),
                    "win_loss_ratio"       : stats.get("win_loss_ratio"),
                    "ev_pct"               : stats.get("ev_pct"),
                    "sharpe_ratio"         : stats.get("sharpe_ratio"),
                    "max_loss_pct"         : stats.get("max_loss_pct"),
                    "annual_compound_pct"  : stats.get("annual_compound_pct"),
                    "sample_count"         : stats.get("sample_count", len(returns_all)),
                    "error"                : stats.get("error"),

                    # ── Trade positions for DB verification ───────────
                    # Full list of every simulated historical trade.
                    # Stored as JSON in DB field: trade_position_detail
                    "trade_position_detail": trade_positions,
                }

                results.append(row)

                print(f"  Level {level} {run_dir:7s} {trade_dir:5s}: "
                      f"win_rate={win_rate:.1%}, "
                      f"sample={stats.get('sample_count','N/A')}, "
                      f"sharpe={stats.get('sharpe_ratio','N/A')}, "
                      f"annual={stats.get('annual_compound_pct','N/A')}%")

    return results

import math



def calculate_metrics(data_list, level, run_type, trade_type, cycle='daily'):
    # 1. INITIALIZE EVERYTHING AT THE TOP (Prevents NameError)
    char = "1" if run_type == "UpRun" else "0"
    prefix = "0" if run_type == "UpRun" else "1"
    target_pattern = char * level

    trade_position_detail = []
    wins = 0

    # 2. VALIDATE CYCLE (Error protection for beginners)
    cycle_periods = {
        'weekly': 52,
        'daily': 252,
        'monthly': 12,
    }
    if cycle.lower() not in cycle_periods:
        raise ValueError(f"Cycle '{cycle}' not found! Add it to the utility dictionary.")

    annual_factor = cycle_periods[cycle.lower()]

    # 3. PATTERN MATCHING LOOP
    for i in range(1, len(data_list) - level):
        has_fresh_start = (data_list[i-1]['digit'] == prefix)

        if has_fresh_start:
            current_segment = "".join([data_list[j]['digit'] for j in range(i, i + level)])

            if current_segment == target_pattern:
                entry_node = data_list[i + level - 1]
                exit_node = data_list[i + level]

                entry_price = float(entry_node['price'])
                exit_price = float(exit_node['price'])

                # Calculate percentage change
                if entry_price > 0:
                    change_pct = (exit_price - entry_price) / entry_price
                else:
                    change_pct = 0.0

                # Reverse math for SHORT
                if trade_type == "SHORT":
                    change_pct = -change_pct

                is_win = change_pct > 0
                if is_win:
                    wins += 1

                trade_position_detail.append({
                    "entry_date": entry_node['date'],
                    "entry_price": entry_price,
                    "exit_date": exit_node['date'],
                    "exit_price": exit_price,
                    "result": "WIN" if is_win else "LOSE",
                    "pct_change": round(change_pct, 4),
                    "pattern_found": prefix + target_pattern
                })

    # 3. FINAL MATH (Safe from NameError because detail is initialized above)
    total_trades = len(trade_position_detail)
    win_rate = (wins / total_trades) if total_trades > 0 else 0.0

    all_returns = [t['pct_change'] for t in trade_position_detail]
    win_returns = [r for r in all_returns if r > 0]
    lose_returns = [r for r in all_returns if r <= 0]

    avg_win_pct = sum(win_returns) / len(win_returns) if win_returns else 0.0
    avg_lose_pct = sum(lose_returns) / len(lose_returns) if lose_returns else 0.0

    # Win/Loss Ratio
    win_loss_ratio = (avg_win_pct / abs(avg_lose_pct)) if avg_lose_pct != 0 else 0.0

    # Max Loss
    max_loss_pct = min(all_returns) if all_returns else 0.0
    # Max Consecutive Losses
    # Walk through all trades counting loss streaks
    # Keep track of the longest streak seen
    max_consec_losses = 0
    current_streak    = 0
    for t in trade_position_detail:
        if t['result'] == 'LOSE':
            current_streak    += 1                              # extend current streak
            max_consec_losses  = max(max_consec_losses,        # update record if longer
                                     current_streak)
        else:
            current_streak = 0                                  # reset on any win
    # Sharpe Ratio
    sharpe_ratio = 0.0
    if total_trades > 1:
        mean_ret = sum(all_returns) / total_trades
        variance = sum((r - mean_ret) ** 2 for r in all_returns) / (total_trades - 1)
        stdev = math.sqrt(variance)
        if stdev > 0:
            risk_free_per_period = 0.05 / annual_factor
            sharpe_ratio = round(
                ((mean_ret - risk_free_per_period) / stdev) * math.sqrt(annual_factor),
                4
            )

    # Annual Compound
    annual_compound_pct = 0.0
    if total_trades > 0:
        # 1. The Chain: Multiply all returns together
        total_mult = 1.0
        for r in all_returns:
            total_mult *= (1 + r)

        # 2. The Time: Use the annual_factor instead of calendar dates
        years_equivalent = total_trades / annual_factor

        # 3. The Result: Stretch the growth to a full year
        # Ensure total_mult is positive to avoid complex number errors
        if years_equivalent > 0 and total_mult > 0:
            annual_compound_pct = (total_mult ** (1 / years_equivalent)) - 1
        else:
            # If total_mult is 0 or negative, it means a 100% loss of capital
            annual_compound_pct = -1.0

    # EV calculation
    ev = (win_rate * avg_win_pct) + ((1 - win_rate) * avg_lose_pct)

    return {
        "win_rate": round(win_rate, 4),
        "ev": round(ev, 4),
        "sample_count": total_trades,
        "avg_win_pct": round(avg_win_pct, 4),
        "avg_lose_pct": round(avg_lose_pct, 4),
        "win_loss_ratio": round(win_loss_ratio, 4),
        "max_loss_pct": round(max_loss_pct, 4),
        "max_consec_losses": max_consec_losses,
        "sharpe_ratio": round(sharpe_ratio, 4),
        "annual_compound_pct": round(float(annual_compound_pct.real), 4),
        "trade_position_detail": trade_position_detail,
    }
if __name__ == "__main__":
    # Test input string
    TEST_INPUT = "0111100101001110101111100001010010100101101011100001100101011100011110101100110111111001010101110111010100011111101101100111101011110100101110110000001011100111111111001110001111101010010101100111111"

    # Test without suffix, default level=2
    print("=== TESTING WITHOUT SUFFIX, LEVEL=2 ===")
    segments = segment_binary_string(TEST_INPUT, level=2)
    print_segmentation_results(TEST_INPUT, segments)
    counts = pattern_repeat_not_repeat(TEST_INPUT, segments, level=2)
    print(f"\nPattern Counts: {counts}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments, counts, level=2)}")

    print("\n" + "="*60 + "\n")

    # Test with suffix '1', level=1
    print("=== TESTING WITH SUFFIX '1', LEVEL=1 ===")
    segments1 = segment_binary_string(TEST_INPUT, suffix='1', level=1)
    print_segmentation_results(TEST_INPUT, segments1, suffix='1')
    counts1 = pattern_repeat_not_repeat(TEST_INPUT, segments1, level=1)
    print(f"\nPattern Counts: {counts1}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments1, counts1, level=1)}")

    print("\n" + "="*60 + "\n")

    # Test with suffix '0', level=3
    print("=== TESTING WITH SUFFIX '0', LEVEL=3 ===")
    segments0 = segment_binary_string(TEST_INPUT, suffix='0', level=3)
    print_segmentation_results(TEST_INPUT, segments0, suffix='0')
    counts0 = pattern_repeat_not_repeat(TEST_INPUT, segments0, level=3)
    print(f"\nPattern Counts: {counts0}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments0, counts0, level=3)}")

    print("\n" + "="*60 + "\n")

    # Test with provided segment list, level=2
    print("=== TESTING WITH PROVIDED SEGMENT LIST, LEVEL=2 ===")
    provided_segments = [
        ('1010', 'Alternating_A1', 4), ('00000', 'DownRun', 5), ('11', 'UpRun', 2), ('00', 'DownRun', 2),
        ('0101', 'Alternating_A0', 4), ('11', 'UpRun', 2), ('00', 'DownRun', 2), ('010', 'Alternating_A0', 3),
        ('00', 'DownRun', 2), ('111', 'UpRun', 3), ('000', 'DownRun', 3), ('111', 'UpRun', 3),
        ('00', 'DownRun', 2), ('010101', 'Alternating_A0', 6), ('11', 'UpRun', 2), ('1010', 'Alternating_A1', 4),
        ('000', 'DownRun', 3), ('1111111', 'UpRun', 7), ('1010', 'Alternating_A1', 4), ('00', 'DownRun', 2),
        ('111', 'UpRun', 3), ('00', 'DownRun', 2)
    ]
    provided_segments.reverse()  # Reverse to match newest-to-oldest order
    counts_provided = pattern_repeat_not_repeat("", provided_segments, level=2)
    print(f"\nPattern Counts for Provided Segments: {counts_provided}")
    print(f"\nRecommendation: {generate_streak_recommendation(provided_segments, counts_provided, level=2)}")

    print("\n" + "="*60 + "\n")

    # Test for level=1 with example input
    print("=== TESTING EXAMPLE INPUT, LEVEL=1 ===")
    example_input = "100110001110111010"
    segments_example = segment_binary_string(example_input, level=1)
    print_segmentation_results(example_input, segments_example)
    counts_example = pattern_repeat_not_repeat(example_input, segments_example, level=1)
    print(f"\nPattern Counts: {counts_example}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_example, counts_example, level=1)}")

    print("\n" + "="*60 + "\n")

    # Test for level=1 with problematic input
    print("=== TESTING LEVEL=1 WITH PROBLEMATIC INPUT ===")
    problem_input = "111011001101011011111000001010101110000010111001101111010011100011111010100101011001111101101011110"
    segments_problem = segment_binary_string(problem_input, suffix='1', level=1)
    print_segmentation_results(problem_input, segments_problem, suffix='1')
    counts_problem = pattern_repeat_not_repeat(problem_input, segments_problem, level=1)
    print(f"\nPattern Counts: {counts_problem}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_problem, counts_problem, level=1)}")

    print("\n" + "="*60 + "\n")

    # Additional test for level=3 to verify length classification
    print("=== TESTING LEVEL=3 WITH EXAMPLE INPUT ===")
    example_input_3 = "1110000101011110001111"
    segments_3 = segment_binary_string(example_input_3, level=3)
    print_segmentation_results(example_input_3, segments_3)
    counts_3 = pattern_repeat_not_repeat(example_input_3, segments_3, level=3)
    print(f"\nPattern Counts: {counts_3}")
    print(f"\nRecommendation: {generate_streak_recommendation(segments_3, counts_3, level=3)}")

    # ==================================================================
    # NEW TEST — scan_ticker_performance()
    # Uses the exact same worked example from the blueprint (v4.0).
    # We know the expected answers from manual calculation in the blueprint,
    # so we can verify the function is correct by comparing outputs.
    # ==================================================================

    print("\n" + "="*60)
    print("=== TESTING scan_ticker_performance() — Blueprint Example ===")
    print("="*60)

    # ── Input data from blueprint Section 3 ───────────────────────────
    # This is the exact example used in blueprint v4.0.
    # Index 0 = first bar (no digit, no change%).
    # Index 1 onward = digits and change%.

    TEST_DATES = [
        "2026-01-02",  # index 0  — no digit
        "2026-01-03",  # index 1  — digit 1
        "2026-01-04",  # index 2  — digit 1
        "2026-01-05",  # index 3  — digit 0
        "2026-01-06",  # index 4  — digit 0
        "2026-01-07",  # index 5  — digit 1
        "2026-01-08",  # index 6  — digit 1
        "2026-01-09",  # index 7  — digit 0
        "2026-01-10",  # index 8  — digit 1
        "2026-01-11",  # index 9  — digit 0
        "2026-01-14",  # index 10 — digit 1
        "2026-01-15",  # index 11 — digit 1
        "2026-01-16",  # index 12 — digit 1
        "2026-01-17",  # index 13 — digit 1
        "2026-01-18",  # index 14 — digit 0
        "2026-01-21",  # index 15 — digit 0
        "2026-01-22",  # index 16 — digit 1
        "2026-01-23",  # index 17 — digit 1
        "2026-01-24",  # index 18 — digit 1
        "2026-01-25",  # index 19 — digit 0
        "2026-01-28",  # index 20 — digit 1
        "2026-01-29",  # index 21 — digit 1  ← most recent, no exit yet
    ]

    TEST_CLOSES = [
         90.0,   # index 0  — first bar, no previous price
        100.0,   # index 1
        102.0,   # index 2
         95.0,   # index 3
         90.0,   # index 4
        110.0,   # index 5
        130.0,   # index 6
        120.0,   # index 7
        125.0,   # index 8
        120.0,   # index 9
        130.0,   # index 10
        135.0,   # index 11
        140.0,   # index 12
        150.0,   # index 13
        140.0,   # index 14
        130.0,   # index 15
        135.0,   # index 16
        140.0,   # index 17
        145.0,   # index 18
        120.0,   # index 19
        125.0,   # index 20
        130.0,   # index 21  ← most recent bar
    ]

    TEST_CHANGE_PCTS = [
        None,       # index 0  — no previous price
        11.1111,    # index 1
         2.0000,    # index 2
        -6.8627,    # index 3
        -5.2632,    # index 4
        22.2222,    # index 5
        18.1818,    # index 6
        -7.6923,    # index 7
         4.1667,    # index 8
        -4.0000,    # index 9
         8.3333,    # index 10
         3.8462,    # index 11
         3.7037,    # index 12
         7.1429,    # index 13
        -6.6667,    # index 14
        -7.1429,    # index 15
         3.8462,    # index 16
         3.7037,    # index 17
         3.5714,    # index 18
       -17.2414,    # index 19
         4.1667,    # index 20
         4.0000,    # index 21
    ]

    # Binary string starts at index 1 (index 0 has no digit)
    # Digits: compare each close to previous close
    #   index 1: 100 > 90   → 1
    #   index 2: 102 > 100  → 1
    #   index 3:  95 < 102  → 0
    #   ... and so on
    TEST_BINARY = "110011010111100111011"
    #              ^ index 1           ^ index 21
    # Length = 21 = len(TEST_CLOSES) - 1  ✅

    # Verify alignment
    assert len(TEST_BINARY) == len(TEST_CLOSES) - 1, (
        f"Alignment error: binary length {len(TEST_BINARY)} "
        f"should be close_prices length {len(TEST_CLOSES)} - 1"
    )
    assert len(TEST_CHANGE_PCTS) == len(TEST_CLOSES), (
        f"Alignment error: change_pcts length {len(TEST_CHANGE_PCTS)} "
        f"should equal close_prices length {len(TEST_CLOSES)}"
    )

    print(f"\nInput summary:")
    print(f"  Binary string   : '{TEST_BINARY}'")
    print(f"  Length          : {len(TEST_BINARY)} digits")
    print(f"  Close prices    : {len(TEST_CLOSES)} bars (index 0 to {len(TEST_CLOSES)-1})")
    print(f"  Date range      : {TEST_DATES[0]} to {TEST_DATES[-1]}")
    print(f"  Cycle           : daily (cycle_days=1)")
    print(f"  Level set       : [2, 3]")
    print()

    # ── Run the scan ──────────────────────────────────────────────────
    print("--- Scan output (one line per combination) ---")
    scan_results = scan_ticker_performance(
        binary_string = TEST_BINARY,
        close_prices  = TEST_CLOSES,
        change_pcts   = TEST_CHANGE_PCTS,
        dates         = TEST_DATES,
        level_set     = [2, 3],          # just level 2 and 3 for this test
        cycle_days    = 1,               # daily bars
    )

    # ── Print detailed results ────────────────────────────────────────
    print(f"\n--- Detailed results ({len(scan_results)} rows total) ---")
    for row in scan_results:
        print()
        print(f"  {'─'*55}")
        print(f"  Level {row['level']} | {row['run_direction']:7s} | "
              f"trade_direction={row['trade_direction']}")
        print(f"  {'─'*55}")

        if row.get("error") and row['sample_count'] == 0:
            print(f"  ERROR: {row['error']}")
            print(f"  sample_count = {row['sample_count']}")
            continue

        # Always show win_rate and sample_count — these are valid
        # even when full statistics cannot be calculated (< 10 samples)
        print(f"  win_rate            = {row['win_rate']:.4f}  "
              f"({row['win_rate']*100:.1f}%)")
        print(f"  sample_count        = {row['sample_count']}")
        if row.get("error") and row['sample_count'] > 0:
            print(f"  NOTE: {row['error']} — showing trade positions only")
        elif not row.get("error"):
            print(f"  avg_return_pct      = {row['avg_return_pct']}")
            print(f"  avg_win_pct         = {row['avg_win_pct']}")
            print(f"  avg_lose_pct        = {row['avg_lose_pct']}")
            print(f"  win_loss_ratio      = {row['win_loss_ratio']}")
            print(f"  ev_pct              = {row['ev_pct']}")
            print(f"  sharpe_ratio        = {row['sharpe_ratio']}")
            print(f"  max_loss_pct        = {row['max_loss_pct']}")
            print(f"  annual_compound_pct = {row['annual_compound_pct']}")

        print(f"\n  Trade positions ({len(row['trade_position_detail'])} trades):")
        print(f"  {'entry_date':<12} {'exit_date':<12} "
              f"{'entry':>8} {'exit':>8} "
              f"{'return%':>8} {'seg':>5} {'W/L':<5}")
        print(f"  {'-'*65}")
        for p in row['trade_position_detail']:
            print(f"  {str(p['entry_date']):<12} {str(p['exit_date']):<12} "
                  f"{p['entry_price']:>8.2f} {p['exit_price']:>8.2f} "
                  f"{p['return_pct']:>8.2f} {p['segment_label']:>5} "
                  f"{p['win_lose']:<5}")

    # ── Verification against blueprint ────────────────────────────────
    # From blueprint Section 8 (Level 2, UpRun, LONG):
    # Trade 1: entry=102, exit=95,  return=-6.86%  LOSE
    # Trade 2: entry=130, exit=120, return=-7.69%  LOSE
    # Trade 3: entry=135, exit=140, return=+3.70%  WIN
    # Trade 4: entry=140, exit=145, return=+3.57%  WIN
    # Trade 5: entry=130 (index 21) → no exit yet → SKIPPED
    # Expected win_rate = 2/4 = 0.50

    print("\n" + "="*60)
    print("=== VERIFICATION vs Blueprint (Level 2, UpRun, LONG) ===")
    print("="*60)

    # Find the Level 2 UpRun LONG row
    target = next(
        (r for r in scan_results
         if r["level"] == 2
         and r["run_direction"] == "UpRun"
         and r["trade_direction"] == "LONG"),
        None
    )

    if target:
        # Note: error="Insufficient data" is expected for this small 22-bar test.
        # In production with 2 years of daily data (~500 bars), sample_count
        # will be 30-80+ and stats will calculate normally.
        # For the verification test we only check win_rate and trade positions
        # since those are always calculated regardless of sample size.

        expected_win_rate     = 0.50     # 2 wins out of 4 trades
        expected_sample       = 4        # Trade 5 skipped (no exit bar)
        expected_trade1_entry = 102.0
        expected_trade2_entry = 130.0
        expected_trade3_entry = 135.0
        expected_trade4_entry = 140.0

        actual_entries = [p["entry_price"]
                          for p in target["trade_position_detail"]]

        print(f"\n  Expected win_rate : {expected_win_rate}")
        print(f"  Actual   win_rate : {target['win_rate']}")
        print(f"  Match             : "
              f"{'✅ PASS' if abs(target['win_rate'] - expected_win_rate) < 0.001 else '❌ FAIL'}")

        print(f"\n  Expected sample   : {expected_sample}")
        print(f"  Actual   sample   : {target['sample_count']}")
        print(f"  Match             : "
              f"{'✅ PASS' if target['sample_count'] == expected_sample else '❌ FAIL'}")

        expected_entries = [expected_trade1_entry, expected_trade2_entry,
                            expected_trade3_entry, expected_trade4_entry]
        print(f"\n  Expected entries  : {expected_entries}")
        print(f"  Actual   entries  : {actual_entries}")
        print(f"  Match             : "
              f"{'✅ PASS' if actual_entries == expected_entries else '❌ FAIL'}")

        # Verify trade outcomes match blueprint
        # Trade 1: LOSE, Trade 2: LOSE, Trade 3: WIN, Trade 4: WIN
        expected_outcomes = ["LOSE", "LOSE", "WIN", "WIN"]
        actual_outcomes   = [p["win_lose"] for p in target["trade_position_detail"]]
        print(f"\n  Expected outcomes : {expected_outcomes}")
        print(f"  Actual   outcomes : {actual_outcomes}")
        print(f"  Match             : "
              f"{'✅ PASS' if actual_outcomes == expected_outcomes else '❌ FAIL'}")

        print(f"\n  NOTE: 'Insufficient data' error is EXPECTED for this 22-bar test.")
        print(f"        In production with ~500 bars, all stats will be calculated.")
        print(f"        The important thing: win_rate ✅  entries ✅  outcomes ✅")